/**
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
**/
if ('undefined' === typeof Config || null === Config) {
	Config={
	};
}

Config.Manage={};

Config.Device={};
Config.Device.GetLastOne='/device/getlastone';
Config.Device.GetRecent='/device/getrecent';
Config.Device.GetCurrentHour='/device/getcurrenthour';
Config.Device.GetLastHour='/device/getlasthour';
Config.Device.GetCurrentDay='/device/getcurrentday';
Config.Device.GetLastDay='/device/getlastday';
Config.Device.GetByDate='/device/getbydate';

Config.Dashboard={};
Config.Dashboard.IntervalDuration=30000;
Config.Dashboard.MapZoomDefaultSize=4;
Config.Dashboard.MapZoomSize=12;
Config.Dashboard.HoverMapZoomSize=18;
Config.Dashboard.Host='/getdashboarddata';
Config.Dashboard.OrgSummary='/dashboard/getorgsummary';

Config.Charts={};

Config.LayoutTemplate={};
Config.LayoutTemplate.Admin='/template/admin';
Config.LayoutTemplate.Organization='/template/organization';
Config.LayoutTemplate.Site='/template/site';
Config.LayoutTemplate.DeviceCluster='/template/devicecluster';
Config.LayoutTemplate.Device='/template/device';
Config.LayoutTemplate.Save='/dashboard/layoutsave';

Config.DeviceCluster={};
Config.DeviceCluster.Summary ='/kripya/device/getsummary';
Config.DeviceCluster.Admin ='/kripya/device/adminsummary';
Config.DeviceCluster.Site ='/kripya/device/customersummary';
Config.DeviceCluster.Site ='/kripya/device/sitesummary';
Config.DeviceCluster.System ='/kripya/device/clustersummary';
Config.DeviceCluster.Device ='/kripya/device/devicesummary';
Config.DeviceCluster.AggregateFetch='/kripya/aggregate/fetch';
Config.DeviceCluster.AggregateFetchRange='/kripya/aggregate/fetchrange';

Config.Organization={};
Config.Organization.GetRecent='/device/adminsummary';