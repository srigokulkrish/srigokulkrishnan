WidgetDeviceGauge = function() {
    var pm = {};
    pm.lastRecordIndex = 0;

    pm.gaugeTemplate = '<div class="gaugeWrapper">';
    pm.gaugeTemplate += '<span class="gaugeValueText"></span>&nbsp;<span class="gaugeUnit"></span>';
    pm.gaugeTemplate += '<canvas class="gaugeCanvas" style="width:100%;"></canvas>';
    pm.gaugeTemplate += '<div class="gaugeLabelWrapper">';
    pm.gaugeTemplate += '<span class="gaugeLabelText textValue"></span>';
    pm.gaugeTemplate += '</div>';
    pm.gaugeTemplate += '<div class="gaugeUpdatedDT"></div>';
    pm.gaugeTemplate += '</div>';

    pm.init = function(config) {
        //console.log('WidgetChart init called.');
        pm.lastRecordIndex = -1;
        pm.config = config;

        var content = pm.gaugeTemplate;
        config.container.html(content);

        var percentColors = [
            [0.0, "#00ff04"],
            [0.90, "#ff9603"],
            [1.0, "#ff2d03"]
        ];
        if (pm.config.dataset.percentColors) {
            var percentColors = pm.config.dataset.percentColors;
        }

        var staticZones = [];
        if (pm.config.dataset.staticZones) {
            var staticZones = pm.config.dataset.staticZones;
        }

        pm.config.opts = {
            angle: 0, // The span of the gauge arc
            lineWidth: 0.2, // The line thickness
            radiusScale: 0.96, // Relative radius
            pointer: {
                length: 0.6, // Relative to gauge radius
                strokeWidth: 0.035, // The thickness
                color: '#eeeecc' // Fill color
            },
            limitMax: false, // If false, max value increases automatically if value > maxValue
            limitMin: false, // If true, the min value of the gauge will be fixed
            colorStart: '#6FADCF', // Colors
            colorStop: '#8FC0DA', // just experiment with them
            strokeColor: '#E0E0E0', // to see which ones work best for you
            generateGradient: true,
            highDpiSupport: true, // High resolution support
            staticZones: staticZones
        };

        /*
        staticLabels: {
            font: "10px sans-serif",  // Specifies font
            labels: [0, 50, 240, 300],  // Print labels at these values
            color: "#000000",  // Optional: Label text color
            fractionDigits: 0  // Optional: Numerical precision. 0=round off.
        },
        staticZones: [
        {strokeStyle: "#FFDD00", min: 0, max: 60}, // Red from 100 to 130
        {strokeStyle: "#30B32D", min: 60, max: 250}, // Yellow
        {strokeStyle: "#F03E3E", min: 250, max: 300} // Green
        ]*/
    }

    pm.render = function(recent, summary) {
        //console.log('WidgetDeviceGauge render called.');

        var param = pm.dataPrep(recent, summary, pm.config);

        pm.config.container.find('.gaugeLabelText').html(pm.config.dataset.label);
        pm.config.container.find('.gaugeUnit').html(pm.config.dataset.unit);
        pm.config.container.find('.gaugeValueText').html(param.displayValue || '0.0');

        if (param.updatedDT) {
            pm.config.container.find('.gaugeUpdatedDT').html(param.updatedDT.format("dddd, MMMM Do YYYY, h:mm a") || '-');
        } else {
            pm.config.container.find('.gaugeUpdatedDT').html('');
        }

        //pm.config.container.find('.gaugeWrapper').css("backgroundColor", pm.config.dataset.backgroundColor);

        pm.config.container.find('.gaugeWrapper').css("color", pm.config.dataset.textColor);

        pm.gaugeHandle = new Gauge(pm.config.container.find('.gaugeCanvas').get(0)).setOptions(pm.config.opts);
        pm.gaugeHandle.maxValue = pm.config.dataset.maxValue; // set max gauge value
        pm.gaugeHandle.setMinValue(0); // Prefer setter over gauge.minValue = 0
        pm.gaugeHandle.animationSpeed = 10; // set animation speed (32 is default value)
        pm.gaugeHandle.setTextField(pm.config.container.find('.gaugeValueText').get(0), 1);
        pm.gaugeHandle.set(param.displayValue); // set actual value
    }

    pm.renderDirectly = function(data) {
        pm.config.container.find('.gaugeLabelText').html(pm.config.dataset.label);
        pm.config.container.find('.gaugeUnit').html(pm.config.dataset.unit);
        pm.config.container.find('.gaugeValueText').html(data || '0.0');

        //pm.config.container.find('.gaugeWrapper').css("backgroundColor", pm.config.dataset.backgroundColor);

        pm.config.container.find('.gaugeWrapper').css("color", pm.config.dataset.textColor);

        pm.gaugeHandle = new Gauge(pm.config.container.find('.gaugeCanvas').get(0)).setOptions(pm.config.opts);
        pm.gaugeHandle.maxValue = pm.config.dataset.maxValue; // set max gauge value
        pm.gaugeHandle.setMinValue(0); // Prefer setter over gauge.minValue = 0
        pm.gaugeHandle.animationSpeed = 10; // set animation speed (32 is default value)
        pm.gaugeHandle.setTextField(pm.config.container.find('.gaugeValueText').get(0), 1);
        pm.gaugeHandle.set(data); // set actual value
    }

    pm.dataPrep = function(recent, summary, config) {
        if (!recent && !summary) {
            return [];
        }

        if (!recent) {
            recent = summary;
        }
        var preparedData = {};

        var maxIdx = 0;
        var minVal = 0;
        var maxVal = 0;
        for (var idx in recent) {
            var record = recent[idx];
            for (var paramIdx in record.deviceStateTable) {
                var param = record.deviceStateTable[paramIdx];
                if (0 <= config.includeParams.indexOf(param.name)) {
                    if (0 == maxIdx) {
                        minVal = param.displayValue;
                    }
                    minVal = Math.min(param.displayValue, minVal);
                    maxVal = Math.max(param.displayValue, maxVal);
                }
            }
            maxIdx = Math.max(maxIdx, idx);
        }
        var instantaneousSet = recent[maxIdx];
        if (!instantaneousSet) {
            return preparedData;
        }

        var instantaneousParam = null;
        for (var paramIdx in instantaneousSet.deviceStateTable) {
            var param = instantaneousSet.deviceStateTable[paramIdx];
            if (0 <= config.includeParams.indexOf(param.name)) {
                instantaneousParam = param;
            }
        }

        preparedData = instantaneousParam;
        preparedData.minValue = minVal;
        preparedData.maxValue = maxVal;
        if (instantaneousSet.recordLabel) {
            preparedData.updatedDT = moment(instantaneousSet.recordLabel);
        }

        return preparedData;
    }

    return pm;
}