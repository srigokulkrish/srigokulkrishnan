WidgetHtmlRender = function(){
	console.log('Widget Table constructor called.');
	
	var pm = {};
	
	pm.render =  function(content, data, container,imagePath, type = 'digital', customHTML = false,dataCollection = false){
		console.log('WidgetTable render called.');
		pm.content 		= content;
		pm.data 		= data;
		pm.type 		= type;
		pm.imagePath 	= imagePath;
		pm.dataCollection = dataCollection;
		var outputContent = '';
		if(type == 'digital'){
			if(customHTML){
				outputContent = pm.syncCustomHTMLData();
			}else{
				outputContent = pm.syncDigitalData();
			}
		}
		//console.log("outputContent",outputContent);
		container.html(outputContent);
		// container.find('.sectionRecords .d-none').remove();
	}

	pm.setData = function(key,value,dataContent){
		//console.log('WidgetTable setData called. Must override this method.');
		dataContent.find('.key').html(key);
		dataContent.find('.value').html(value);
		return dataContent;
	}
	pm.syncCustomHTMLData = function(){
		var outputDesign 		= pm.content;
		var imagePath 			= pm.imagePath;
		var dataCollection 		= pm.dataCollection;
		_sections 				= pm.data;
		var keyValuePairs 		= {};
		var _secCount 			= 0;
		var _fieldCount 		= 0;
		_sections.forEach((section) => {
			keyValuePairs["Sec"+_secCount] = section.sectionDisplayName;
			section.formFields.forEach((field) => {
				keyValuePairs["imagePath"] = "../"+imagePath;
				if (field.displayName && field.fieldName) {
					keyValuePairs[field.fieldName + ".displayName"] = field.displayName;
					if(field.fieldType == "form_content_field"){
						keyValuePairs[field.fieldName + ".value"] = field.value ? atob(field.value) : "";
					}else{
						if(field.fieldType == 'input_dropdown' || field.fieldType == "input_dropdown_multi" || field.fieldType == "input_radio" || field.fieldType == "input_checkbox" || field.fieldType == "multi_checkbox"){
							if(dataCollection){
								var arrayIndex = dataCollection[field.fieldName].findIndex(x => x.name == field.value);
								if(arrayIndex >= 0){
									value = dataCollection[field.fieldName][arrayIndex].displayName;
								}else{
									value = field.value;
								}
								
								keyValuePairs[field.fieldName + ".value"] = value ? value : "";
							}else{
								keyValuePairs[field.fieldName + ".value"] = field.value ? field.value : "";
							}
						}else{
							keyValuePairs[field.fieldName + ".value"] = field.value ? field.value : "";
						}
					}					
				}else if(field.fieldType == "head_title"){
					keyValuePairs["title"+_secCount+_fieldCount] = field.title;

				}else if(field.fieldType == "form_content"){
					keyValuePairs["formContent"+_secCount+_fieldCount] = {"title" : field.title, 'formContent':atob(field.formContent)};
				}
				_fieldCount++;

			});
			_secCount++;
		});
		// console.log("keyValuePairs",keyValuePairs);
		for (const [key, value] of Object.entries(keyValuePairs)) {
			var regex = new RegExp("%%" + key + "%%", "g");
			outputDesign = outputDesign.replace(regex, value);
		}
		// console.log("outputDesign",outputDesign)
		return outputDesign;
	}
	pm.syncDigitalData = function(){
		console.log('WidgetTable syncDigitalData called.');
		var dataset = {};
		_sections 				= pm.data;
		var outputDesign 		= pm.content;
		var imagePath 			= pm.imagePath;
		var dataCollection 		= pm.dataCollection;
		let outputDesignClone 	= outputDesign.clone();
		let secDataContainer 	= outputDesign.find('.SectionDataContainer');
		let sectionData 		= secDataContainer.find('.SectionData');
		let secRecord 			= outputDesign.find('.SectionDataContainer .SectionData .sectionRecords').clone();
		//console.log("outputDesignsyncDigitalData",outputDesign.html());
		for (let i = 0; i < _sections.length; i++) {
			var secData = sectionData;					
			secData.find('.sectionTitle').html("<h4 class='p-1 text-capitalize'>"+_sections[i].sectionDisplayName.toLowerCase()+"</h4>");
			var _formFields = _sections[i].formFields;
			var sectionRecElement = secData.find('.sectionRecords');
			sectionRecElement.html('');
			//console.log('secRecord', secRecord.html());		
			for (let j = 0; j < _formFields.length; j++) {
				let sectionRecord = secRecord;
				let sectionRecordRow = '';
				//console.log("sectionRecord before",sectionRecord.html());
				sectionRecord.find('.key, .value').html('sss');
				if( _formFields[j].fieldType == "head_title" ||  _formFields[j].fieldType == "form_content"){
					sectionRecord.find('.normalValue').addClass('d-none');
					sectionRecord.find('.formTitle').removeClass('d-none');
					sectionRecord.find('.formTitle').html(_formFields[j].title);
					if( _formFields[j].fieldType == "form_content"){
						sectionRecord.find('.formContent').removeClass('d-none');
						var _formContent = _formFields[j].formContent;
						try{
							var _formContent = atob(_formFields[j].formContent);
						}catch(e){
							console.log("Base64 conversion failed");
						}		
						sectionRecord.find('.formContent').html(_formContent);
					}else{
						 sectionRecord.find('.normalValue').addClass('d-none');
					}
					sectionRecordRow = sectionRecord;
				}else{
					
					sectionRecord.find('.normalValue').removeClass('d-none');
					sectionRecord.find('.formTitle,.formContent').addClass('d-none');
					var value ='';
					var key ='';
					key = _formFields[j].displayName;
					if(_formFields[j].fieldType == "upload_image" || _formFields[j].fieldType == "camera_capture" || _formFields[j].fieldType == "signature"){
						if(_formFields[j].value == ''){
							value ='';
						}else{
							value +='<img src="../'+imagePath+''+_formFields[j].value+'" alt="'+_formFields[j].displayName+'" width="90px">';
						}
					}else if(_formFields[j].fieldType == "camera_capture_multi" || _formFields[j].fieldType == "upload_image_multi"){
						if(_formFields[j].value == ''){
							value ='';
						}else{
							var valueData = '';
							const dynamicValue = _formFields[j].value.split("|");
							if(dynamicValue.length > 1){
								valueData +='<table><tr>';
								for (let k = 0; k < dynamicValue.length; k++) {
									let number = k+1;
									valueData +='<td><img src="../'+imagePath+''+dynamicValue[k]+'" alt="'+_formFields[j].displayName+'" width="100px"></td>';
									if(number % 3==0){
										valueData +='</tr><tr>';
									}
								}
								valueData +='</tr></table>';
								value = valueData;
							}else{
								value ='<img src="../'+imagePath+''+_formFields[j].value.trim()+'" alt="'+_formFields[j].displayName+'" width="90px">';
							}
						}
					}else if(_formFields[j].fieldType == "upload_document"){
						if(_formFields[j].value == ''){
							value ='';
						}else{
							value ='<a href="../'+imagePath+''+_formFields[j].value+'" title="'+_formFields[j].displayName+'" target="_blank">'+_formFields[j].displayName+'</a>';
						}
					}else if(_formFields[j].fieldType == "upload_document_multi"){
						if(_formFields[j].value == ''){
							value ='';
						}else{
							var valueData = '';
							const dynamicValue = _formFields[j].value.split("|");
							if(dynamicValue.length > 1){
								valueData +='<table><tr>';
								for (let k = 0; k < dynamicValue.length; k++) {
									let number = k+1;
									valueData +='<td><a href="../'+imagePath+''+dynamicValue[k].trim()+'" title="'+_formFields[j].displayName+'" target="_blank">'+_formFields[j].displayName+'</a></td>';
									if(number % 3==0){
										valueData +='</tr><tr>';
									}
								}
								valueData +='</tr></table>';
								value = valueData;
							}else{
								value ='<a href="../'+imagePath+''+_formFields[j].value.trim()+'" title="'+_formFields[j].displayName+'" target="_blank">'+_formFields[j].displayName+'</a>';
							}
						}
					}else if(_formFields[j].fieldType == "capture_video"){
						if(_formFields[j].value == ''){
							value ='';
						}else{
							value ='<video width="250" height="150" controls><source src="../'+imagePath+''+_formFields[j].value+'" type="video/mp4">Your browser does not support the video tag.</video>';
						}
					}else if(_formFields[j].fieldType == "input_location"){
						if(_formFields[j].value == ''){
							value ='';
						}else{
							value ='<a href="https://www.google.com/maps/?q='+_formFields[j].value+'" title="'+_formFields[j].displayName+'" target="_blank">'+_formFields[j].displayName+'</a>';
						}
					}else if(_formFields[j].fieldType == "input_dynamic_text"){
						const dynamicValue = _formFields[j].value.split("|");
						var valueData = '';
						if(dynamicValue.length > 1){
							valueData +='<table><tr>';
							for (let k = 0; k < dynamicValue.length; k++) {
								let number = k+1;
								valueData +='<td>'+dynamicValue[k]+'</td>';
								if(number % 5==0){
									valueData +='</tr><tr>';
								}
							}
							valueData +='</tr></table>';
							value = valueData;
						}else{
							value =_formFields[j].value;
						}
						
					}else{
						if(_formFields[j].fieldType == "input_dropdown" || _formFields[j].fieldType == "input_dropdown_multi" || _formFields[j].fieldType == "input_radio" || _formFields[j].fieldType == "input_checkbox" || _formFields[j].fieldType == "multi_checkbox"){
							if(dataCollection){
								if(_formFields[j].fieldType == "input_dropdown_multi" || _formFields[j].fieldType == "multi_checkbox"){
									console.log("_formFields",_formFields[j]);
									const dynamicValue = _formFields[j].value;
									var valueArray = [];
									for (let k = 0; k < dynamicValue.length; k++) {
										console.log("_formFields",dataCollection[_formFields[j].fieldName]);
										var arrayIndex = dataCollection[_formFields[j].fieldName].findIndex(x => x.name == dynamicValue[k]);
										if(arrayIndex >= 0){
											valueArray[k] =dataCollection[_formFields[j].fieldName][arrayIndex].displayName;
										}else{
											value =_formFields[j].value;
										}
									}
								}else{
									var arrayIndex = dataCollection[_formFields[j].fieldName].findIndex(x => x.name == _formFields[j].value);
									if(arrayIndex >= 0){
										value =dataCollection[_formFields[j].fieldName][arrayIndex].displayName;
									}else{
										value =_formFields[j].value;
									}
								}
							}else{
								value =_formFields[j].value;
							}
						}else{
							value =_formFields[j].value;
						}
						
					}
					//console.log("sectionRecElement outerHTML",sectionRecord.prop('outerHTML'),sectionRecord);
					// sectionRecordRow = pm.setData(key,value,sectionRecord);
					sectionRecord.find('.normalValue .key').html(key);
					sectionRecord.find('.normalValue .value').html(value);

					sectionRecordRow = sectionRecord;
				}
				//sectionRecord = '';
				//console.log("sectionRecord after",sectionRecordRow.html());
				sectionRecElement.append(sectionRecordRow.html());
			}
			secDataContainer.append(sectionRecElement);
			//console.log("secDataContainer after",secDataContainer.prop('outerHTML'));
		}
		
		//console.log("outputDesign",outputDesign.html());
		// content.find('.SectionDataContainer').html(sectionDataElement.prop('outerHTML'));
		return outputDesign.html();
	}
	
	return pm;
};