WidgetSimpleCard = function() {
    var pm = {};
    pm.lastRecordIndex = 0;

    pm.cardTemplate = '<div class="cardWrapper">';

    pm.cardTemplate += '<div class="cardLabel"></div>';
    pm.cardTemplate += '<div class="cardIcon"></div>';

    pm.cardTemplate += '<div class="cardMainVal">';
    pm.cardTemplate += '<span class="textValue"></span>';
    pm.cardTemplate += '&nbsp;<span class="textUnit"></span>';
    pm.cardTemplate += '</div>';

    pm.cardTemplate += '<div class="cardUpdatedDT"></div>';
    pm.cardTemplate += '</div>';

    pm.init = function(config) {
        //console.log('WidgetChart init called.');
        pm.lastRecordIndex = -1;
        pm.config = config;

        var content = pm.cardTemplate;
        config.container.html(content);
    }

    pm.render = function(recent, summary) {
        //console.log('WidgetSimpleCards render called.');

        var param = pm.dataPrep(recent, summary, pm.config);
        console.log("PARAM",param);
        pm.config.container.find('.cardLabel').html(pm.config.dataset.label);
        pm.config.container.find('.cardIcon').html(pm.config.dataset.icon);
        pm.config.container.find('.cardMainVal .textUnit').html(pm.config.dataset.unit);
        if(typeof(param) !== undefined && typeof(param) !== NaN && typeof(param) !== null && param !== null)
        {  
            pm.config.container.find('.cardMainVal .textValue').html(param.displayValue || '0.0');
            if (param.updatedDT) {
                //pm.config.container.find('.cardUpdatedDT').html(param.updatedDT.format("YYYY-MM-DD h:mm:ss a") || '-');
                pm.config.container.find('.cardUpdatedDT').html(param.updatedDT.format("dddd, MMMM Do YYYY, h:mm a") || '-');
            } else {
                pm.config.container.find('.cardUpdatedDT').html('');
            }
        }

        

        pm.config.container.find('.cardWrapper').css("backgroundColor", pm.config.dataset.backgroundColor);

        pm.config.container.find('.cardWrapper').css("color", pm.config.dataset.textColor);
    }

    pm.dataPrep = function(recent, summary, config) {
        if (!recent && !summary) {
            return [];
        }

        if (!recent) {
            recent = summary;
        }
        var preparedData = {};

        var maxIdx = 0;
        var minVal = 0;
        var maxVal = 0;
        for (var idx in recent) {
            var record = recent[idx];
            for (var paramIdx in record.deviceStateTable) {
                var param = record.deviceStateTable[paramIdx];
                if (0 <= config.includeParams.indexOf(param.name)) {
                    if (0 == maxIdx) {
                        minVal = param.displayValue;
                    }
                    minVal = Math.min(param.displayValue, minVal);
                    maxVal = Math.max(param.displayValue, maxVal);
                }
            }
            maxIdx = Math.max(maxIdx, idx);
        }
        var instantaneousSet = recent[maxIdx];
        if (!instantaneousSet) {
            return preparedData;
        }

        var instantaneousParam = null;
        for (var paramIdx in instantaneousSet.deviceStateTable) {
            var param = instantaneousSet.deviceStateTable[paramIdx];
            if (0 <= config.includeParams.indexOf(param.name)) {
                instantaneousParam = param;
            }
        }

        preparedData = instantaneousParam;
        console.log("preparedData",preparedData);
        if(typeof(preparedData) !== undefined && typeof(preparedData) !== NaN && typeof(preparedData) !== null && preparedData !== null)
        {            
            preparedData.minValue = minVal;
            preparedData.maxValue = maxVal;
        }
        if (instantaneousSet.recordLabel) {
            if(typeof(preparedData) !== undefined && typeof(preparedData) !== NaN && typeof(preparedData) !== null && preparedData !== null)
            { 
                preparedData.updatedDT = moment(instantaneousSet.recordLabel);
            }
        }

        return preparedData;
    }

    return pm;
}