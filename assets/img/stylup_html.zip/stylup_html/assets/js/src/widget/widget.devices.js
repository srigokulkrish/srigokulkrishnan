/*
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/
 
/*
*
SAMPLE WIDGET CONFIG:
{
  "widgetType": "WidgetDevices",
  "settings":{
	  showMap:true
  }
  "dataChannels": [
    {
      "channelKey": "dashboard", 
      "sourceType": "orgSummary",
      "sourceId": "7",
      "label": "orgSummary",
      "interval": "lastOne",
      "mode": "overwrite",
      "syncFrequency": 5000,
      "recordsLimit": 50,
      "useLastIndex": true,
      "useGlobalManager": true
    }
  ]
}
*/

WidgetDevices = function(){
	console.log('WidgetDevices constructor called.');
	
	var pm = {};
	
	pm.getInstance = function(context, config, dataManager){
		pm.context = context;
		pm.config = config;
		pm.dataManager = dataManager;
		return pm;
	}
	
	pm.onInit = function(context, config){
		console.log('WidgetDevices onInit called.');
		pm.context = context;
		pm.config = config;
		pm.setData();
		
		var content = '<div class="tableContainer"></div>';
		pm.context.container.html(content);
	}
	
	pm.onUpdate = function(context, config){
		console.log('WidgetDevices onUpdate called.');
		pm.context = context;
		pm.config = config;
		pm.syncData();
	}
	
	pm.render =  function(dataPayload){
		console.log('WidgetDevices render called.');
		var presentedData 	= pm.presenter(dataPayload);
		var container 		= pm.context.container;
		
		var content = '<table  class="table">';		
		if(presentedData &&  presentedData.devices && 0 < presentedData.sites.length){
			content += '<thead>';
			content += '<tr>';
			content += '<th>' + 'Device Name' + '</th>';
			content += '<th>' + 'Device ID' + '</th>';
			content += '<th>' + 'Status' + '</th>';
			content += '<th>' + 'Action' + '</th>';
			content += '</tr>';
			content += '</thead>';
			content += '<tbody>';
			for(deviceIdx in presentedData.devices){
				var rowEl = presentedData.devices[deviceIdx];
				content += '<tr>';
				content += '<td>' + rowEl['deviceRef'] + '</td>';
				content += '<td>' + rowEl['deviceId'] + '</td>';
				content += '<td>' + rowEl['status'] + '</td>';
				content += '<td><a href="/?type=DEVICE&id=' + rowEl['deviceId'] + '">LINK</a></td>';
				content += '</tr>';
			}
			content += "</tbody>";
			content += "</table>";
			container.find('.tableContainer').html(content);
			
			$(document).ready(function(){
					container.find('.tableContainer .table').DataTable({});
				});
		}else{
		}
	}

	pm.setData = function(){
		console.log('WidgetDevices setData called.');
		for(var channelIdx in pm.config.dataChannels){
			if(0 == channelIdx){
				pm.config.dataChannels[channelIdx].status = "active";
			}
			pm.config.dataChannels[channelIdx].parser = pm.parser;
			pm.config.dataChannels[channelIdx].sourceId = ApplicationManager.getAppId();
			pm.dataManager.addChannel(pm.config.dataChannels[channelIdx]);
		}
	}
		
	pm.syncData = function(){
		console.log('WidgetDevices syncData called.');
		var dataset = {};
		for(var channelIdx in pm.config.dataChannels){
			var channel = pm.config.dataChannels[channelIdx];
			var newSet = pm.dataManager.fetch(channel);			
			dataset = Object.assign(dataset, newSet);
		}
		pm.render(dataset);
	}
	
	pm.presenter = function(dataset){
		console.log('WidgetDevices presenter called.');
		return dataset;
	}
	
	pm.parser = function(data){
		console.log('WidgetDevices parser called.');
		return data.data;
	};
	
	return pm;
};