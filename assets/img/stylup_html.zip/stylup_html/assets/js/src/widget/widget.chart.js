WidgetChart = function() {
    console.log('WidgetChart constructor called.');
    var pm = {};

    pm.getInstance = function(context, config, dataManager) {
        pm.context = context;
        pm.config = config;
        pm.dataManager = dataManager;
        return pm;
    }

    pm.onInit = function(context, config) {
        console.log('WidgetChart onInit called.');
        pm.context = context;
        pm.config = config;
        pm.setData();

        var content = '';
        content += '<div class="chart-container">';
        content += '<div class="chart-controls"></div>';
        content += '<canvas id="chart-area_' + context.elementId + '" style="height=95%" />';
        content += '</div>';
        context.container.html(content);

        var showTitle = pm.config.dataset.showTitle;
        var chartTitle = pm.config.dataset.title;
        var xAxisLabel = pm.config.dataset.xAxisLabel ? pm.config.dataset.xAxisLabel : '';
        var yAxisLabel = pm.config.dataset.yAxisLabel ? pm.config.dataset.yAxisLabel : '';

        pm.chartConfig = {
            type: 'line',
            options: {
                maintainAspectRatio: false,
                responsive: true,
                title: {
                    display: showTitle,
                    text: chartTitle
                },
                tooltips: {
                    mode: 'index',
                    intersect: false,
                },
                hover: {
                    mode: 'nearest',
                    intersect: true
                },
                scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: xAxisLabel,
                            color: '#cccccc'
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: yAxisLabel
                        },
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                },
                elements: {
                    point: {
                        radius: 4
                    },
                    line: {
                        borderWidth: 2
                    }
                }
            }
        };

        var ctx = document.getElementById("chart-area_" + context.elementId).getContext("2d");
        pm.chart = new Chart(ctx, pm.chartConfig);
    }

    pm.onUpdate = function(context, config) {
        console.log('WidgetChart onUpdate called.');
        pm.context = context;
        pm.config = config;
        pm.syncData();
    }

    pm.render = function(dataPayload) {
        console.log('WidgetChart render called.');
        var presentedData = pm.presenter(dataPayload);

        if (0 >= presentedData.length) {} else {
            if (!pm.chartConfig.data.labels) {
                pm.chartConfig.data.labels = [];
            }
            if (!pm.chartConfig.data.datasets || 0 >= pm.chartConfig.data.datasets) {
                var dataset = {
                    label: pm.config.dataset.includeParams[0].label,
                    backgroundColor: 'rgba(0, 111, 179,0.9)',
                    borderColor: 'rgba(0, 111, 179,0.9)',
                    fill: false
                };
                pm.chartConfig.data.datasets = [];
                pm.chartConfig.data.datasets.push(dataset);
            }

            if (!pm.chartConfig.data.datasets[0].data) {
                pm.chartConfig.data.datasets[0].data = [];
            }

            for (dataId in presentedData) {
                var rowEl = presentedData[dataId];
                pm.chartConfig.data.labels.push(rowEl["key"]);
                pm.chartConfig.data.datasets[0].data.push(rowEl["value"]);
            }
        }
        pm.chart.update();
    }

    pm.setData = function() {
        console.log('WidgetChart setData called. Must override this method.');
    }

    pm.syncData = function() {
        console.log('WidgetChart syncData called.');
        var dataset = {};
        for (var channelIdx in pm.config.dataChannels) {
            var channel = pm.config.dataChannels[channelIdx];
            var newSet = pm.dataManager.fetch(channel);
            dataset = Object.assign(dataset, newSet);
        }
        pm.render(dataset);
    }

    pm.presenter = function(dataset) {
        console.log('WidgetChart presenter called. Must override this method.');
        return dataset.data[dataset.lastIndex];
    }

    pm.parser = function(data) {
        console.log('WidgetChart parser called.');
        return data;
    };

    return pm;
};