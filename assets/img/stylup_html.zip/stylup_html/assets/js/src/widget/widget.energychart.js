WidgetEnergyChart = function() {
    var pm = {};
    pm.lastRecordIndex = 0;

    pm.init = function(config) {
        console.log('BarChart init called.');
        pm.lastRecordIndex = -1;
        pm.config = config;

        var containerClass = pm.config.containerClass ? pm.config.containerClass : 'dashCharts';
        var content = '';
        content += '<div class="chart-container">';
        content += '<div class="chart-controls"></div>';
        content += '<canvas class="' + containerClass + '" />';
        content += '</div>';
        config.container.html(content);

        var showTitle = pm.config.dataset.showTitle;
        var chartTitle = pm.config.dataset.title;
        var xAxisLabel = pm.config.dataset.xAxisLabel ? pm.config.dataset.xAxisLabel : '';
        var yAxisLabel = pm.config.dataset.yAxisLabel ? pm.config.dataset.yAxisLabel : '';
        var xAxisType = pm.config.dataset.xAxisType ? pm.config.dataset.xAxisType : 'time';
        var xAxisTimeUnit = pm.config.dataset.xAxisTimeUnit ? pm.config.dataset.xAxisTimeUnit : 'hour';
        pm.chartConfig = {
            type: 'bar',
            options: {
                maintainAspectRatio: false,
                responsive: true,
                title: {
                    display: showTitle,
                    text: chartTitle
                },
                hover: {
                    mode: 'nearest',
                    intersect: false
                },
                scales: {
                    xAxes: [{
                        scaleLabel: {
                            display: false,
                            labelString: xAxisLabel
                        },
                        type: xAxisType,
                        time: {
                            unit: xAxisTimeUnit
                        },
                        distribution: 'linear',
                        ticks: {
                            display: true,
                            source: 'data'
                        }
                    }],
                    yAxes: [{
                        scaleLabel: {
                            display: false,
                            labelString: yAxisLabel
                        },
                        ticks: {
                            display: true,
                            beginAtZero: true
                        }
                    }]
                },
                legend: {
                    display: false
                },
                tooltips: {
                    mode: "interpolate",
                    intersect: false
                },
                elements: {
                    point: {
                        radius: 1
                    },
                    line: {
                        borderWidth: 1
                    }
                },
                plugins: {
                    crosshair: {
                        line: {
                            color: '#F66', // crosshair line color
                            width: 1, // crosshair line width
                            dashPattern: [5, 5] // crosshair line dash pattern
                        },
                        sync: {
                            enabled: true, // enable trace line syncing with other charts
                            group: 1, // chart group
                            suppressTooltips: false // suppress tooltips when showing a synced tracer
                        },
                        zoom: {
                            enabled: false, // enable zooming
                            zoomboxBackgroundColor: 'rgba(66,133,244,0.2)', // background color of zoom box
                            zoomboxBorderColor: '#48F', // border color of zoom box
                            zoomButtonText: 'Reset Zoom', // reset zoom button text
                            zoomButtonClass: 'reset-zoom', // reset zoom button class
                        },
                        callbacks: {
                            beforeZoom: function(start, end) { // called before zoom, return false to prevent zoom
                                return true;
                            },
                            afterZoom: function(start, end) { // called after zoom
                            }
                        }
                    }
                }
            }
        };

        var ctx = config.container.find("canvas").get(0);
        ctx = ctx.getContext("2d");
        pm.chart = new Chart(ctx, pm.chartConfig);
    }

    pm.render = function(dataPayload) {
        var package = pm.dataPrep(dataPayload, pm.config);
        var preparedDatasets = package.preparedDatasets;
        var preparedLabels = package.preparedLabels;

        /** Remove last record so that it can be updated with more recent values */
        if (pm.chartConfig.data.labels) {
            pm.chartConfig.data.labels.pop();
        }

        /** Remove last record so that it can be updated with more recent values */
        if (pm.chartConfig.data.datasets) {
            for (setID in pm.chartConfig.data.datasets) {
                pm.chartConfig.data.datasets[setID].data.pop();
            }
        }

        if (0 >= preparedDatasets.length) {} else {
            if (!pm.chartConfig.data.labels) {
                pm.chartConfig.data.labels = [];
            }

            if (!pm.chartConfig.data.datasets || 0 >= pm.chartConfig.data.datasets) {
                pm.chartConfig.data.datasets = [];
            }

            for (var idx in preparedLabels) {
                var label = preparedLabels[idx];
                pm.chartConfig.data.labels.push(label);
            }

            for (var setID in preparedDatasets) {
                var dataset = preparedDatasets[setID];

                if (!pm.chartConfig.data.datasets[setID]) {
                    pm.chartConfig.data.datasets[setID] = dataset;
                } else {
                    for (idx in dataset.data) {
                        var dataItem = dataset.data[idx];
                        pm.chartConfig.data.datasets[setID].data.push(dataItem);
                    }
                }
            }
        }
        pm.chart.update();
    }

    pm.dataPrep = function(dataset, config) {
        if (!dataset) {
            return [];
        }

        var preparedLabels = [];
        var preparedDatasets = [];

        var isIncludeMode = (0 < config.includeParams.length);
        var isExcludeMode = (0 < config.excludeParams.length);

        for (var idx in dataset) {
            var data = dataset[idx];
            var dataID = data.dataID ? data.dataID : idx;
            if (dataID < pm.lastRecordIndex) {
                continue;
            }

            var mTime = moment(data.recordLabel);
            preparedLabels.push(mTime);

            var deviceStateTable = [];
            if (isIncludeMode) { /* Include only matching parameters */
                for (var paramIdx in data.deviceStateTable) {
                    var param = data.deviceStateTable[paramIdx];
                    var paramName = param.name;
                    if (0 <= config.includeParams.indexOf(paramName)) {
                        deviceStateTable.push(param);
                    }
                }
            } else if (isExcludeMode) { /* Exclude matching parameters */
                for (var paramIdx in data.deviceStateTable) {
                    var param = data.deviceStateTable[paramIdx];
                    var paramName = param.name;
                    if (-1 === config.includeParams.indexOf(paramName)) { /* Case when include parameters have been defined */
                        deviceStateTable.push(param);
                    }
                }
            } else { /* Include all parameters */
                for (var paramIdx in data.deviceStateTable) {
                    var param = data.deviceStateTable[paramIdx];
                    var paramName = param.name;
                    deviceStateTable.push(param);
                }
            }

            var idx = 0;
            for (var paramIdx in deviceStateTable) {
                var minIdx = idx + 1;
                var maxIdx = idx + 2;
                var param = deviceStateTable[paramIdx];
                var paramName = param.displayLabel || param.name;
                var paramVal = param.deltaValue;
                var minVal = param.minValue;
                var maxVal = param.maxValue;
                if (paramVal && typeof paramVal === 'number' && !Number.isInteger(paramVal)) {
                    paramVal = paramVal.toFixed(2);
                }

                if (minVal && typeof minVal === 'number' && !Number.isInteger(minVal)) {
                    minVal = minVal.toFixed(2);
                }

                if (maxVal && typeof maxVal === 'number' && !Number.isInteger(maxVal)) {
                    maxVal = maxVal.toFixed(2);
                }

                if (!preparedDatasets[idx]) {
                    preparedDatasets[idx] = {
                        label: paramName,
                        backgroundColor: pm.config.chartColorArray[idx],
                        borderColor: pm.config.chartColorArray[idx],
                        fill: pm.config.chartFill
                    };
                    preparedDatasets[idx].data = [];

                    if (config.showMinMax) {
                        preparedDatasets[minIdx] = {
                            label: paramName + '-MIN',
                            backgroundColor: pm.config.chartColorArray[minIdx],
                            borderColor: pm.config.chartColorArray[minIdx],
                            fill: pm.config.chartFill
                        };
                        preparedDatasets[minIdx].data = [];

                        preparedDatasets[maxIdx] = {
                            label: paramName + '-MAX',
                            backgroundColor: pm.config.chartColorArray[maxIdx],
                            borderColor: pm.config.chartColorArray[maxIdx],
                            fill: pm.config.chartFill
                        };
                        preparedDatasets[maxIdx].data = [];
                    }
                }
                preparedDatasets[idx].data.push(paramVal);
                if (config.showMinMax) {
                    preparedDatasets[minIdx].data.push(minVal);
                    preparedDatasets[maxIdx].data.push(maxVal);
                    idx = idx + 3;
                } else {
                    idx = idx + 1;
                }
            }
            pm.lastRecordIndex = Math.max(pm.lastRecordIndex, dataID);
        }
        var package = {};
        package.preparedDatasets = preparedDatasets;
        package.preparedLabels = preparedLabels;

        return package;
    }

    return pm;
}