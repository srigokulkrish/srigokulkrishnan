/*
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/
 
/*
*
SAMPLE WIDGET CONFIG:
{
  "widgetType": "WidgetOrgCards",
  "dataChannels": [
    {
      "channelKey": "dashboard", 
      "sourceType": "orgSummary",
      "sourceId": "7",
      "label": "orgSummary",
      "interval": "lastOne",
      "mode": "overwrite",
      "syncFrequency": 5000,
      "recordsLimit": 50,
      "useLastIndex": true,
      "useGlobalManager": true
    }
  ],
  "cards": [
    {
      "paramName": "sitesCount",
      "label": "Total Sites",
      "icon": "iconPower",
      "unit": "",
      "color": "rgba(255,255,102, 1.0)"
    },
    {
      "paramName": "devicesCount",
      "label": "Total Devices",
      "unit": "",
      "icon": "iconPower",
      "color": "rgba(51,204,153, 1.0)"
    }
  ]
}
*/
WidgetOrgCards = function(){
	var pm = WidgetTable();
	
	pm.setData = function(){
		console.log('WidgetOrgCards setData override called.');
		for(var channelIdx in pm.config.dataChannels){
			if(0 == channelIdx){
				pm.config.dataChannels[channelIdx].status = "active";
			}
			pm.config.dataChannels[channelIdx].parser = pm.parser;
			pm.dataManager.addChannel(pm.config.dataChannels[channelIdx]);
		}
	}
	
	pm.syncData = function(){
		console.log('WidgetOrgCards syncData override called.');
		var dataset = {};
		for(var channelIdx in pm.config.dataChannels){
			var channel = pm.config.dataChannels[channelIdx];
			if("active" != channel.status){
				continue;
			}
			var newSet = pm.dataManager.fetch(channel);			
			dataset = Object.assign(dataset, newSet);
		}
		pm.render(dataset);
	}
	
	pm.parser = function(data){
		return data.data;
	};

	pm.presenter = function(dataset){
		console.log('WidgetOrgCards presenter override called.');
		if(!dataset){
			return [];
		}
		var presentedData = {};
		var cards = pm.config.cards;
		
		var timeString = LYFENET.DateTime.fromUnixTimeStamp(dataset.timestamp);
		var currentTime = Math.floor((new Date).getTime()/1000);
		var diffTime = currentTime - dataset.timestamp;
		
		for(var cardsIdx in cards){
			if( dataset.hasOwnProperty(cards[cardsIdx].paramName) ){
				var paramName = cards[cardsIdx].paramName;
				var paramValue = dataset[paramName];
				presentedData[paramName] = {
					displayValue:paramValue,
					timestamp:timeString,
					timediff:diffTime
				};
				presentedData[paramName] = Object.assign(presentedData[paramName], cards[cardsIdx]);
			}
		}
		return presentedData;
	}
	
	pm.render =  function(dataPayload){
		console.log('WidgetOrgCards render called.');		
		
		var presentedData 	= pm.presenter(dataPayload);
		var container 		= pm.context.container;
		var content = '';
		content += '<div  class="cardContainer">';
		for(var dataIdx in presentedData){
			var card = presentedData[dataIdx];
			content += '<div class="deviceCards" style="border-bottom:8px solid '+ card.color +'">';
			content += '<div class="cardLabel">' + card.label + '</div>';
			content += '<div class="cardIcon"><img src="/images/icons/' + card.icon + '.png"></img></div>';
			content += '<div class="cardValueWrapper"><span class="cardValue">'+ card.displayValue +'</span><span class="cardUnit">'+ card.unit +'</span></div>';
			content += '<div class="cardTime "><span class="glyphicon glyphicon-time" title="Updated:' + card.timediff + ' seconds ago (' + card.timestamp + ')"></span></div>';
			//content += '<span class="glyphicon glyphicon-time" title="Updated:' + card.timediff + ' seconds ago (' + card.timestamp + ')">Updated:' + card.timediff + ' seconds ago (' + card.timestamp + ')</span>'
			content += '</div>';
		}
		content += "</div>";
		
		$('#fixedlayoutContainer').html(content);
	}
	
	return pm;
}