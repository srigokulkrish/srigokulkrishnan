Widget = function(context, config, dataManager){
	console.log('Widget constructor called.');
	var that = this;	
	that.context = context;
	that.config = config;
	that.dataManager = dataManager;
	
	var pm = {
		onInit:function(context, config){
			console.log('Widget onInit called.');
			widgetDelegate.onInit(context, config);
		},
		onUpdate:function(context, config){
			console.log('Widget onUpdate called.');
			widgetDelegate.onUpdate(context, config);
		},
		register:function(widgetName, className){
			console.log('Widget register called.');
		},
		unregister:function(widgetName){
			console.log('Widget unregister called.');
		}
	}
	
	var widgetDelegate = null;
	
	switch (config.widgetType) {
		case WidgetType.Table:
			widgetDelegate = WidgetTable().getInstance(context, config, dataManager);
		break;
		case WidgetType.Chart:
			widgetDelegate = WidgetChart().getInstance(context, config, dataManager);
		break;
		case WidgetType.WidgetDeviceTable:
			widgetDelegate = WidgetDeviceTable().getInstance(context, config, dataManager);
		break;
		case WidgetType.WidgetDeviceChart:
			widgetDelegate = WidgetDeviceChart().getInstance(context, config, dataManager);
		break;
		case WidgetType.WidgetDeviceCards:
			widgetDelegate = WidgetDeviceCards().getInstance(context, config, dataManager);
		break;
		case WidgetType.WidgetSites:
			widgetDelegate = WidgetSites().getInstance(context, config, dataManager);
		break;
		case WidgetType.WidgetDevices:
			widgetDelegate = WidgetDevices().getInstance(context, config, dataManager);
		break;
		case WidgetType.WidgetOrgCards:
			widgetDelegate = WidgetOrgCards().getInstance(context, config, dataManager);
		break;
		default:
		break;
	}	
	
	return widgetDelegate;
};

WidgetType = {
	Table:"Table",
	Chart:"Chart",
	WidgetDeviceTable:"WidgetDeviceTable",
	WidgetDeviceChart:"WidgetDeviceChart",
	WidgetDeviceCards:"WidgetDeviceCards",
	WidgetSites:"WidgetSites",
	WidgetDevices:"WidgetDevices",
	WidgetOrgCards:"WidgetOrgCards"
}