WidgetDeviceChart = function() {
    var pm = {};
    pm.lastRecordIndex = -1;
    pm.chart = null;

    pm.init = function(config) {
        pm.lastRecordIndex = -1;
        pm.config   = config;
        var containerClass = pm.config.containerClass ? pm.config.containerClass : 'dashCharts';
        var yheight = pm.config.yheight  ? pm.config.yheight : '';
        var content = '';
        var chartID = config.container.attr("id") + "_chart";
        var tooltip = pm.config.toolTip ? pm.config.toolTip : {};
       // content += '<div class="chart-container">';
        //content += '<div class="chart-controls"></div>';
        content += `<canvas id='${chartID}' class="'${containerClass}'"/>`;
        //content += '</div>';
        config.container.html(content);
        var plugins = pm.config.dataset.plugins ? pm.config.dataset.plugins : {};
        var scales  = pm.config.dataset.scales ? pm.config.dataset.scales : {
            x: {
                type: 'linear',
                position: 'bottom'
            },
            y: {
                beginAtZero: true,
            }
        };
        pm.chartConfig = {
            type: 'line',
            options: {
                responsive:true,
                maintainAspectRatio:false,
                tooltips:tooltip,
                elements: {
                    point: {
                        radius: 1
                    },
                    line: {
                        borderWidth: 1
                    }
                },
                legend:{
                    display:false,
                },
                scales:scales,
                plugins: plugins
            }
        };
        var ctx = config.container.find("canvas").get(0);
        ctx.height = yheight; 
        ctx = ctx.getContext("2d");
        pm.chart = new Chart(ctx, pm.chartConfig);
    }

    pm.render = function(dataPayload, minBar = "", maxBar = "", isLiveChart = false,defaultOperation = true, liveDuration='', pointerRadius) {
        var package = {};

        var liveDataDuration = liveDuration || 30;
        if (isLiveChart == false) {
            package = pm.dataPrep(dataPayload, pm.config, pointerRadius);
        } else {
            package = pm.processChartData(dataPayload, pointerRadius);
        }

        var preparedDatasets = package.preparedDatasets;
        var preparedLabels = package.preparedLabels;
        if(defaultOperation == true){
            if (pm.chartConfig.data.labels) {
                pm.chartConfig.data.labels.pop();
            }

            if (pm.chartConfig.data.datasets) {
                for (setID in pm.chartConfig.data.datasets) {
                    pm.chartConfig.data.datasets[setID].data.pop();
                }
            }
        }

        if (0 >= preparedDatasets.length) {} else {
            if (!pm.chartConfig.data.labels) {
                pm.chartConfig.data.labels = [];
            }

            if (!pm.chartConfig.data.datasets || 0 >= pm.chartConfig.data.datasets) {
                pm.chartConfig.data.datasets = [];
            }

            for (var idx in preparedLabels) {
                var label = preparedLabels[idx];
                pm.chartConfig.data.labels.push(label);
            }

            for (var setID in preparedDatasets) {
                var dataset = preparedDatasets[setID];

                if (!pm.chartConfig.data.datasets[setID]) {
                    pm.chartConfig.data.datasets[setID] = dataset;
                } else {
                    for (idx in dataset.data) {
                        var dataItem = dataset.data[idx];
                        pm.chartConfig.data.datasets[setID].data.push(dataItem);
                    }
                }
            }
        }
        if (isLiveChart == true) {
            var lastThirtyMinutesTimeString = moment().subtract(liveDataDuration, 'minutes').format('YYYY-MM-DD HH:mm:ss');
            var oldDataIndex = [];
            if (pm.chartConfig.data.labels.length > 0) {
                for (let index = 0; index < pm.chartConfig.data.labels.length; index++) {
                    const label = pm.chartConfig.data.labels[index];
                    var labelIndex = pm.chartConfig.data.labels.indexOf(label);
                    var convertedLabel = moment(label);
                    lastThirtyMinutesTimeString = moment(lastThirtyMinutesTimeString);
                    const isGreaterOrEqual = convertedLabel.isSameOrAfter(lastThirtyMinutesTimeString);
                    if (isGreaterOrEqual != true) {
                        oldDataIndex.push(labelIndex);
                    }
                }
            }
            if (oldDataIndex.length > 0) {
                if (pm.chartConfig.data.labels.length == pm.chartConfig.data.datasets[0].data.length) {
                    pm.chartConfig.data.labels.splice(oldDataIndex[0], oldDataIndex.length);
                    pm.chartConfig.data.datasets[0].data.splice(oldDataIndex[0], oldDataIndex.length);
                }
            }
        }
        pm.chart.update();
    }
    pm.dataPrep = function(dataset, config, pointerRadius) {
        if (!dataset) {
            return [];
        }

        var preparedLabels = [];
        var preparedDatasets = [];

        var isIncludeMode = (0 < config.includeParams.length);
        var isExcludeMode = (0 < config.excludeParams.length);
        var datasetArray = [];
        for (var idx in dataset) {
            datasetArray.push(dataset[idx]);
        }
        var datasetArray = datasetArray.sort(((a, b) => {
            var diff = moment(a.recordLabel).diff(moment(b.recordLabel));
            return diff;
        }));

        for (var idx in datasetArray) {
            var data = datasetArray[idx];
            var dataID = data.dataID ? data.dataID : idx;
            if (dataID < pm.lastRecordIndex) {
                continue;
            }

            var mTime = data.recordLabel; //moment(data.recordLabel);
            preparedLabels.push(mTime);

            var deviceStateTable = [];
            if (isIncludeMode) { /* Include only matching parameters */
                for (var paramIdx in data.deviceStateTable) {
                    var param = data.deviceStateTable[paramIdx];

                    var paramName = param.name;
                    if (0 <= config.includeParams.indexOf(paramName)) {
                        deviceStateTable.push(param);
                    }
                }
            } else if (isExcludeMode) { /* Exclude matching parameters */
                for (var paramIdx in data.deviceStateTable) {
                    var param = data.deviceStateTable[paramIdx];
                    var paramName = param.name;
                    if (-1 === config.includeParams.indexOf(paramName)) { /* Case when include parameters have been defined */
                        deviceStateTable.push(param);
                    }
                }
            } else { /* Include all parameters */
                for (var paramIdx in data.deviceStateTable) {
                    var param = data.deviceStateTable[paramIdx];
                    var paramName = param.name;
                    deviceStateTable.push(param);
                }
            }

            var idx = 0;
            for (var paramIdx in deviceStateTable) {
                var minIdx = idx + 1;
                var maxIdx = idx + 2;
                var param = deviceStateTable[paramIdx];
                var paramName = param.displayLabel || param.name;
                var paramVal = param.displayValue || param.value;
                var minVal = param.minValue;
                var maxVal = param.maxValue;
                if (paramVal && typeof paramVal === 'number' && !Number.isInteger(paramVal)) {
                    paramVal = paramVal.toFixed(2);
                }

                if (minVal && typeof minVal === 'number' && !Number.isInteger(minVal)) {
                    minVal = minVal.toFixed(2);
                }

                if (maxVal && typeof maxVal === 'number' && !Number.isInteger(maxVal)) {
                    maxVal = maxVal.toFixed(2);
                }
                if (!preparedDatasets[idx]) {
                    preparedDatasets[idx] = {
                        label: paramName,
                        backgroundColor: pm.config.chartColorArray[idx],
                        borderColor: pm.config.chartColorArray[idx],
                        fill: pm.config.chartFill,
                    };
                    preparedDatasets[idx].data = [];

                    if (config.showMinMax) {
                        preparedDatasets[minIdx] = {
                            label: paramName + '-MIN',
                            backgroundColor: pm.config.chartColorArray[minIdx],
                            borderColor: pm.config.chartColorArray[minIdx],
                            fill: pm.config.chartFill,

                        };
                        preparedDatasets[minIdx].data = [];

                        preparedDatasets[maxIdx] = {
                            label: paramName + '-MAX',
                            backgroundColor: pm.config.chartColorArray[maxIdx],
                            borderColor: pm.config.chartColorArray[maxIdx],
                            fill: pm.config.chartFill,
                        };
                        preparedDatasets[maxIdx].data = [];
                    }

                }
                preparedDatasets[idx].data.push(paramVal);
                if (config.hasOwnProperty('dataPoints')) {
                    if (config.dataPoints == false) {
                        var hiddenPointRadius = pointerRadius || Array(preparedDatasets[idx].data.length).fill(0);
                        preparedDatasets[idx].pointRadius = hiddenPointRadius;
                    }
                }
                if (config.showMinMax) {
                    preparedDatasets[minIdx].data.push(minVal);
                    preparedDatasets[maxIdx].data.push(maxVal);
                    if (config.hasOwnProperty('dataPoints')) {
                        if (config.dataPoints == false) {
                            var hiddenPointRadius = pointerRadius || Array(preparedDatasets[minIdx].data.length).fill(0);
                            preparedDatasets[minIdx].pointRadius = hiddenPointRadius;
                            var hiddenPointRadius = pointerRadius || Array(preparedDatasets[maxIdx].data.length).fill(0);
                            preparedDatasets[maxIdx].pointRadius = hiddenPointRadius;
                        }
                    }
                    idx = idx + 3;
                } else {
                    idx = idx + 1;
                }

            }
            pm.lastRecordIndex = Math.max(pm.lastRecordIndex, dataID);
        }
        var package = {};
        package.preparedDatasets = preparedDatasets;
        package.preparedLabels = preparedLabels;

        return package;
    }
    pm.processChartData = function(dataPayload, pointerRadius) {
        var includeParam = pm.config.includeParams[0];
        var dataLabel = [];
        var dataValue = [];
        var lastRecordLabel = 0;

        if (pm.chartConfig.data.labels != undefined && pm.chartConfig.data.labels.length > 0) {
            lastRecordLabel = pm.chartConfig.data.labels[pm.chartConfig.data.labels.length - 1];
        }

        if (dataPayload != null) {
            var datasetArray = [];
            for (var idx in dataPayload) {
                datasetArray.push(dataPayload[idx]);
            }
            var datasetArray = datasetArray.sort(((a, b) => {
                var diff = moment(a.recordLabel).diff(moment(b.recordLabel));
                return diff;
            }));

            for (var data in datasetArray) {
                if (datasetArray[data].hasOwnProperty('deviceStateTable')) {
                    servoTempValue = datasetArray[data].deviceStateTable.find(item => item.name === includeParam)
                    if (servoTempValue != null) {
                        if (lastRecordLabel != 0) {
                            lastRecordLabel = moment(lastRecordLabel);
                            const currentLabel = moment(datasetArray[data].recordLabel);
                            const isGreaterOrEqual = currentLabel.isSameOrAfter(lastRecordLabel);
                            if (isGreaterOrEqual) {
                                dataLabel.push(datasetArray[data].recordLabel);
                                dataValue.push(servoTempValue.value);
                            }
                        } else {
                            dataLabel.push(datasetArray[data].recordLabel);
                            dataValue.push(servoTempValue.value);
                        }
                    }
                }
            }
        }

        var preparedDatasets = [];
        preparedDatasets[0] = {
            label: includeParam,
            backgroundColor: pm.config.chartColorArray[0],
            borderColor: pm.config.chartColorArray[0],
            fill: pm.config.chartFill,
            data: dataValue,
            pointRadius: pointerRadius || Array(dataValue.length).fill(0)
        };
        var package = {};
        package.preparedDatasets = preparedDatasets;
        package.preparedLabels = dataLabel;
        return package;
    }

    return pm;
}
