WidgetDeviceTable = function(){
	var pm = WidgetTable();
	pm.setData = function(){
		console.log('WidgetDeviceTable setData override called.');
		
		for(var channelIdx in pm.config.dataChannels){
			pm.config.dataChannels[channelIdx].parser = pm.parser;
			pm.dataManager.addChannel(pm.config.dataChannels[channelIdx]);
		}
	}
	
	pm.parser = function(data){
		return data.data;
	};

	pm.presenter = function(dataset){
		console.log('WidgetDeviceTable presenter override called.');
		if(!dataset){
			return [];
		}
		var presentedData = [];
		var lastIndex = dataset.lastIndex;
		var targetRecordSet = dataset.data[lastIndex];
		var deviceStateTable = targetRecordSet.deviceStateTable;
		
		for(var idx in deviceStateTable){
			var row = deviceStateTable[idx];
			presentedData.push({
				key:row.name,
				value : row.displayValue
			});		
		}
		return presentedData;
	}
	return pm;
}