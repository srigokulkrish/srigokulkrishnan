/*
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
*/
 
/*
*
SAMPLE WIDGET CONFIG:
{
  "widgetType": "WidgetSites",
  "settings":{
	  showMap:true
  }
  "dataChannels": [
    {
      "channelKey": "dashboard", 
      "sourceType": "orgSummary",
      "sourceId": "7",
      "label": "orgSummary",
      "interval": "lastOne",
      "mode": "overwrite",
      "syncFrequency": 5000,
      "recordsLimit": 50,
      "useLastIndex": true,
      "useGlobalManager": true
    }
  ]
}
*/

var map;
function initMap() {
	if(!google){
		return false;
	}
	var chennai = {lat: 13.0827, lng: 80.2707};
	map = new google.maps.Map(document.getElementById("map"), {
	center: chennai,
	zoom: 8
	});
}


WidgetSites = function(){
	console.log('WidgetSites constructor called.');
	
	var pm = {};
	
	pm.getInstance = function(context, config, dataManager){
		pm.context = context;
		pm.config = config;
		pm.dataManager = dataManager;
		return pm;
	}
	
	pm.onInit = function(context, config){
		console.log('WidgetSites onInit called.');
		pm.context = context;
		pm.config = config;
		pm.setData();
		
		var content = '<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCHtqGqAlqPU7_mFpv2SDt_zd86jvxS3Z8&callback=initMap" async defer></script>';
		content += '<div id="map" style="width=300px; height:200px;"></div>';
		content += '<div class="tableContainer"></div>';
		pm.context.container.html(content);
	}
	
	pm.onUpdate = function(context, config){
		console.log('WidgetSites onUpdate called.');
		pm.context = context;
		pm.config = config;
		pm.syncData();
	}
	
	pm.render =  function(dataPayload){
		console.log('WidgetSites render called.');
		var presentedData 	= pm.presenter(dataPayload);
		var container 		= pm.context.container;
		
		var content = '<table  class="table">';		
		if(presentedData &&  presentedData.sites && 0 < presentedData.sites.length){
			content += '<thead>';
			content += '<tr>';
			content += '<th>' + 'Site Name' + '</th>';
			content += '<th>' + 'Site Location' + '</th>';
			content += '<th>' + 'Lat' + '</th>';
			content += '<th>' + 'Long' + '</th>';
			content += '<th>' + 'Action' + '</th>';
			content += '</tr>';
			content += '</thead>';
			content += '<tbody>';
			for(siteIdx in presentedData.sites){
				var rowEl = presentedData.sites[siteIdx];
				content += '<tr>';
				content += '<td>' + rowEl['siteName'] + '</td>';
				content += '<td>' + rowEl['siteLocation'] + '</td>';
				content += '<td>' + rowEl['latitude'] + '</td>';
				content += '<td>' + rowEl['longitude'] + '</td>';
				content += '<td><a href="/?type=SITE&id=' + rowEl['siteId'] + '">LINK</a></td>';
				content += '</tr>';
				
				if(google && google.maps && google.maps.Marker){
					var marker = new google.maps.Marker({position: {lat: Number.parseFloat(rowEl['latitude']), lng: Number.parseFloat(rowEl['longitude'])}, map: map});
				}				
			}
			content += "</tbody>";
			content += "</table>";
			container.find('.tableContainer').html(content);
			
			$(document).ready(function(){
					container.find('.tableContainer .table').DataTable({});
				});
		}else{
		}
	}

	pm.setData = function(){
		console.log('WidgetSites setData called.');
		for(var channelIdx in pm.config.dataChannels){
			if(0 == channelIdx){
				pm.config.dataChannels[channelIdx].status = "active";
			}
			pm.config.dataChannels[channelIdx].parser = pm.parser;
			pm.config.dataChannels[channelIdx].sourceId = ApplicationManager.getAppId();
			pm.dataManager.addChannel(pm.config.dataChannels[channelIdx]);
		}
	}
		
	pm.syncData = function(){
		console.log('WidgetSites syncData called.');
		var dataset = {};
		for(var channelIdx in pm.config.dataChannels){
			var channel = pm.config.dataChannels[channelIdx];
			var newSet = pm.dataManager.fetch(channel);			
			dataset = Object.assign(dataset, newSet);
		}
		pm.render(dataset);
	}
	
	pm.presenter = function(dataset){
		console.log('WidgetSites presenter called.');
		return dataset;
	}
	
	pm.parser = function(data){
		console.log('WidgetSites parser called.');
		return data.data;
	};
	
	return pm;
};