WidgetTable = function(){
	console.log('Widget Table constructor called.');
	
	var pm = {};
	
	pm.getInstance = function(context, config, dataManager){
		pm.context = context;
		pm.config = config;
		pm.dataManager = dataManager;
		return pm;
	}
	
	pm.onInit = function(context, config){
		console.log('WidgetTable onInit called.');
		pm.context = context;
		pm.config = config;
		pm.setData();
	}
	
	pm.onUpdate = function(context, config){
		console.log('WidgetTable onUpdate called.');
		pm.context = context;
		pm.config = config;
		pm.syncData();
	}
	
	pm.render =  function(dataPayload){
		console.log('WidgetTable render called.');
		var presentedData 	= pm.presenter(dataPayload);
		var container 		= pm.context.container;
		
		var content = "<table  class='table'>";	
		content += "<tbody>";
		if(0 >= presentedData.length){
				content += "<tr><td>No data to be displayed</td></tr>";
		}else{				
			for(dataId in presentedData){
				content += "<tr>";
				var rowEl = presentedData[dataId];
				content += "<td>" + rowEl["key"] + "</td>";
				content += "<td>" + rowEl["value"] + "</td>";
				content += "</tr>";
			}
		}
		content += "</tbody></table>";
		container.html(content);
	}

	pm.setData = function(){
		console.log('WidgetTable setData called. Must override this method.');
	}
		
	pm.syncData = function(){
		console.log('WidgetTable syncData called.');
		var dataset = {};
		for(var channelIdx in pm.config.dataChannels){
			var channel = pm.config.dataChannels[channelIdx];
			var newSet = pm.dataManager.fetch(channel);			
			dataset = Object.assign(dataset, newSet);
		}
		pm.render(dataset);
	}
	
	pm.presenter = function(dataset){
		console.log('WidgetTable presenter called. Must override this method.');
		return dataset.data[dataset.lastIndex];
		
	}
	
	pm.parser = function(data){
		console.log('WidgetTable parser called.');
		return data;
	};
	
	return pm;
};