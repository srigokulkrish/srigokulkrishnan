var CurrentDeviceIndex;
var dataTimer;
var editor, congigEditor;
var editFlag = 0;
var jsonEditor, contentHtml;
var paramTemplateString = '<div class="dState"><div class="dStateValue">{stateValue}</div><div class="dStateName">{stateName}</div></div>';

$(document).ready(function () {	
	var flag =0;
	$('#showmenu').click(function () {
		if(0 != editFlag) return false;
		$("#addDeviceFormContainer,#addButton").hide();
		$("#deviceListTableContainer").show();
		resetDeviceSelected();
		resetFormValidation('addDeviceForm');
		$("#addDeviceModal").modal("show");
		siteId = $('#siteSelector').val();
		setSourceOptionbyValue('#siteId',siteId);
		addSourceAttribute('#addButton','disabled',true);
		if(flag == 0){
			$('#addDeviceListTable').DataTable({
				drawCallback: function () {
					$('.dataTables_paginate > .pagination').addClass('pagination-sm');
				}
			});
			flag=1;
		}
	});
	
	
	$('#addDevice').click(function () {
		siteId = $('#siteSelector').val();
		var url = '/addvirtualdevice?siteID='+siteId;
		window.location.href =url;
	});
	/*  $('#addDeviceModal').on('hidden.bs.modal', function () {
		$("#addDeviceForm").trigger("reset");
	}); */
	getSiteDetails();
	var messages;
	var rules  = {
		siteId: "required",
		deviceName: "required",
		deviceId: "required",
		deviceClass: "required",
		deviceStatus: "required",
	} ; 
	defineFormValidation('addDeviceForm',rules,messages,addDeviceDetails);
});

function deviceSelected(deviceId){
	setSourceOptionbyValue('#deviceId',deviceId);
	var backBtnHtml ='<div class="pull-left"><button type="button" id="backButton" class="btn btn-primary" onclick="resetDeviceSelected();">Back</button></div>';
	backBtnHtml+=$('#addDeviceModal .modal-footer').html();
	$('#addDeviceModal .modal-footer').html(backBtnHtml);
	$("#backButton").hide();
	$("#deviceListTableContainer").hide("slide", { direction: "left" }, 300,function(){
		$("#addButton,#backButton,#addDeviceFormContainer").fadeIn('slow');
	});
	$("#addButton").click(addDeviceDetails);
	removeSourceAttribute('#addButton','disabled');
}

function resetDeviceSelected(){
	addSourceAttribute('#addButton','disabled',true);
	$("#addDeviceFormContainer").hide("slide", { direction: "right" }, 300,function(){
		$("#deviceListTableContainer").fadeIn('slow');
	});
	$("#addButton,#backButton").fadeOut(400);
	$('#addDeviceModal .modal-footer').find('div').remove();
}

function updateDeviceData() {
    if (0 < CurrentDeviceIndex) {
        var data = {
            siteId: CurrentDeviceIndex
        };
		LYFENET.Core.Ajax.request(Config.Dashboard.sitedetails, data, onUpdateDeviceData);
    } else {
        $('#table').empty();
        $("#deviceLoadingIndicator").addClass("hide");
    }
}

function onUpdateDeviceData(data) {
    displayStateTable(data, '.deviceDetails', paramTemplateString);
}

function updatesiteSelector() {
    removeHideClass("#deviceLoadingIndicator");
    CurrentDeviceIndex = getSourceOption("#siteSelector",'value');
	var sitetext = getSourceOption('#siteSelector');
	$('#siteDeviceHeader').html('Site Devices :: '+sitetext.content);
    updateDeviceData();
}

function displayStateTable(stateTable, targetContainer, templateString) {
    var contextvalue = "";
    $("#deviceLoadingIndicator").addClass("hide");
	if(groupID == 1){
		 contextvalue = "<table title='Double Click to Edit'  id='device_table' class='table table-bordered table-condensed table-hover table-striped'><thead><th>Device ID</th><th>Device Name</th><th>Device Reference Name</th><th>Device Class</th><th>Description</th><th>Config</th><th>Data Frequency</th><th>Status</th><th>Action</th></thead><tbody>";
		
	}else{
		 contextvalue = "<table title='Double Click to Edit'  id='device_table' class='table table-bordered table-condensed table-hover table-striped'><thead><th>Device ID</th><th>Device Name</th><th>Device Reference Name</th><th>Device Class</th><th>Data Frequency</th><th>Status</th><th>Action</th></thead><tbody>";	
	}
	
    console.log(stateTable);
    var value = stateTable;
    for (var i = 0; i < value.length; i++) {
        /* var siteId = value[i].siteId;
         var siteName = value[i].siteName */;
        var deviceId = value[i].deviceId;
        var deviceName = value[i].deviceName;
        var deviceClass = value[i].className;
        var deviceRef = value[i].deviceRef;
        var dataFrequency = value[i].dataFrequency;
        var deviceDescription = value[i].deviceDescription;
        var deviceConfig = value[i].deviceConfig;
        var deviceStatus = value[i].deviceStatus;
        contextvalue += "<tr id='" + deviceId + "' ondblclick='edit_row(" + i + ")'>";
        /*contextvalue+="<td id='siteid_row" + i + "'>"+siteId+"</td><td id='siteName_row"+i+"'>"+siteName+"</td>";*/
		contextvalue+="<td id='deviceId_row" + i + "'>"+deviceId +"</td>";
		contextvalue+="<td id='deviceName_row" + i + "'><div id='deviceNameExist" + i + "'>" + deviceName + "</div><input type='text' class='form-control hidden' id='deviceName_text" + i + "' value='" + deviceName + "'/></td>";
		contextvalue+="<td id='deviceRef_row" + i + "'><div id='deviceRefExist" + i + "'>" + deviceRef + "</div><input type='text' class='form-control hidden' id='deviceRef_text" + i + "' value='" + deviceRef + "'/></td>";
        var deviceClassOptions = getOptions(deviceClassDetails, i, deviceClass, 'deviceClassId', 'className', 'classOptionsContainer', 'classOptionsSelect', 'className');
        contextvalue += "<td id='deviceClass_row" + i + "'><div id='deviceClassText" + i + "'>" + deviceClass + "</div>" + deviceClassOptions + "</td>";
		if(groupID == 1){
			contextvalue+="<td id='deviceDesc_row" + i + "'><div id='jsonContainer" + i + "'class='hide'>"+ deviceDescription + "</div><button type='button' title='Edit Description' id='deviceDescriptionBtn"+i+"' class='btn btn-default btn-sm' onclick='descriptionjsonEditor(" + i + ",\"" + deviceId + "\")'><span class='glyphicon glyphicon-edit'></span> Edit Json</button></td>";
			contextvalue+="<td id='deviceStatus_row" + i + "'><div id='configJsonContainer" + i + "'class='hide'>"+deviceConfig + "</div> <button type='button' id='config_edit_button" + i + "'  title='Edit Config' class='btn btn-default btn-sm' onclick='configJsonEditor(" + i + ",\"" + deviceId + "\")'><span class='glyphicon glyphicon-edit'></span> Edit Json</button></td>";
		}
		contextvalue+="<td id='dataFrequency_row" + i + "'><div id='dataFrequencyExist" + i + "'>" + dataFrequency + "</div><input type='text' class='form-control hidden' id='dataFrequency_text" + i + "' value='" + dataFrequency + "'/></td>";
        var deviceStatusOptions = getOptions(deviceStatusDetails, i, deviceStatus, 'statusID', 'status', 'statusOptionsContainer', 'statusOptionsSelect', 'status')
		contextvalue += "<td><div id='deviceStatusText" + i + "'>" + deviceStatus + "</div>" + deviceStatusOptions + "</td>";
        contextvalue += "<td><div class='btn-group'><button type='button' title='Edit' id='edit_button" + i + "' class='btn btn-default btn-sm' onclick='edit_row(" + i + ")'><span class='glyphicon glyphicon-edit'></span></button><div  title='Click to save' id='save_button" + i + "' class='field-icon btn btn-sm btn-success glyphicon glyphicon-ok hide rowSaveBtn' onclick='save_row(" + i + ",\"" + deviceId + "\")'></div><div id='cancel_button" + i + "' title='Click to cancel' class='field-icon btn btn-sm btn-warning glyphicon glyphicon-remove hide rowCancelBtn' onclick='cancelAction(" + i + ")'></div>" + "&nbsp;&nbsp;<button type='button' id='remove_button" + i + "'  title='Deactive' class='btn btn-default btn-sm' onclick='removeDeviceData(\"" + deviceId + "\")'><span class='glyphicon glyphicon-trash'> </span></button>" + "</div></td></tr>";
    }
    contextvalue += "</tbody></table>";
    $('#table').empty();
    $('#table').append(contextvalue);
    $('#device_table').DataTable({
		 stateSave: true,
		 drawCallback: function() {
			$('.dataTables_paginate > .pagination').addClass('pagination-sm');
		},
	});
}

function updateDeviceDetails(deviceId, deviceName, deviceRef, dataFrequency, deviceClass, deviceStatus) {
    var path = "updatedevicedetails";
    var data = {
        deviceId: deviceId,
        deviceClass: deviceClass,
        deviceName: deviceName,
        deviceRef: deviceRef,
        dataFrequency: dataFrequency,
        deviceStatus: deviceStatus
    };
    LYFENET.Core.Ajax.request(path, data, updateDeviceDetailsResponse);
	var undefinedVar;
	alertMessage('process','Processing...',undefinedVar,undefinedVar,true);
}

function removeDeviceData(deviceId) {
	 if ((0 != editFlag) || ('' == deviceId)){
        return false;
	 }
	$('#confirmModal').modal().one('click', '#confirmYesBtn', function(e) {
		var path = "deactivedevicedetails";
		var data = {
			deviceId: deviceId
		};
		LYFENET.Core.Ajax.request(path, data, onResponseAjax);
		var undefinedVar;
		alertMessage('process','Processing...',undefinedVar,undefinedVar,true);
		$('#table').empty();
		$('#siteSelector').prop('selectedIndex', 0);
		$("#deviceLoadingIndicator").removeClass("hide");
	});
}

function edit_row(rowid) {
    if (!(editFlag == 0)) {
		return false;
	}
	var hideIds = "#deviceClassText" + rowid+','+"#deviceStatusText" + rowid+','+"#deviceNameExist" + rowid+','+"#deviceRefExist" + rowid+','+"#dataFrequencyExist" + rowid+','+"#edit_button" + rowid+','+"#remove_button" + rowid;
	var showIds = "#classOptionsContainer" + rowid+','+"#statusOptionsContainer" + rowid+','+"#deviceName_text" + rowid+','+"#deviceRef_text" + rowid+','+"#dataFrequency_text" + rowid+','+"#save_button" + rowid+','+"#cancel_button" + rowid;
	addHideClass(hideIds);
	removeHideClass(showIds);
	var disableIds ="#deviceDescriptionBtn"+ rowid +",#config_edit_button"+ rowid;
	addSourceAttribute(disableIds,'disabled',true);
	editFlag = 1;
}

function cancelAction(rowid) {
	var showIds = "#deviceClassText" + rowid+','+"#deviceStatusText" + rowid+','+"#deviceNameExist" + rowid+','+"#deviceRefExist" + rowid+','+"#dataFrequencyExist" + rowid+','+"#edit_button" + rowid+','+"#remove_button" + rowid;
	var hideIds = "#classOptionsContainer" + rowid+','+"#statusOptionsContainer" + rowid+','+"#deviceName_text" + rowid+','+"#deviceRef_text" + rowid+','+"#dataFrequency_text" + rowid+','+"#save_button" + rowid+','+"#cancel_button" + rowid;
	addHideClass(hideIds);
	removeHideClass(showIds);
	var disableIds ="#deviceDescriptionBtn"+ rowid +",#config_edit_button"+ rowid;
	removeSourceAttribute(disableIds,'disabled');
    editFlag = 0;
}

function save_row(rowid, deviceId) {
    var deviceName =getSourceValue("#deviceName_text" + rowid);
    var deviceRef =getSourceValue("#deviceRef_text" + rowid);
    var dataFrequency =getSourceValue("#dataFrequency_text" + rowid);
    var deviceClass = getSourceValue("#classOptionsSelect" + rowid);
    var deviceClassText =  getSourceOption("#classOptionsSelect" + rowid,'text'); 
    var deviceStatus = getSourceValue("#statusOptionsSelect" + rowid);
    var deviceStatusText =getSourceOption("#statusOptionsSelect" + rowid,'text'); 
    var deviceNameExist = getSourceText("#deviceNameExist" + rowid);
    var deviceRefExist = getSourceText("#deviceRefExist" + rowid);
    var dataFrequencyExist = getSourceText("#dataFrequencyExist" + rowid);
    var deviceClassTextExist = getSourceText("#deviceClassText" + rowid);
    var deviceStatusTextExist = getSourceText("#deviceStatusText" + rowid);
    if (deviceName != '') {
        if ((deviceName != deviceNameExist) || (deviceRef != deviceRefExist) || (dataFrequency != dataFrequencyExist) || (deviceClassText != deviceClassTextExist) || (deviceStatusText != deviceStatusTextExist)) {
            updateDeviceDetails(deviceId, deviceName, deviceRef, dataFrequency, deviceClass, deviceStatus);
            editFlag = 0;
        } else {
            cancelAction(rowid);
            editFlag = 0;
            alertMessage('info', "No Changes in a Row!");
        }
    } else {
        alertMessage('error', "Please Enter Device Name !");
    }
}

function getSiteDetails(){
	var currentSiteId = LYFENET.Core.getUrlParam('siteId');
	var selectedSiteId =  $('#siteSelector').val();
	var siteId = (typeof(currentSiteId) != "undefined" && currentSiteId != null &&  currentSiteId != "" && typeof(currentSiteId) != "object") ? currentSiteId :selectedSiteId; 
	optionValue = $('#siteSelector'+' option[value="'+currentSiteId+'"]');
	siteId = (0 < optionValue.length) ? currentSiteId : selectedSiteId; 
	$('#siteSelector').val(siteId);
	updatesiteSelector();
}

function updateDescriptionJson() {
    hideModalContent("#jsonModal");
    var updatedJson = jsonEditor.getText();
    var deviceId =getSourceValue("#deviceIdx");
    var containerIdx = getSourceValue("#containerIdx");
    var existingJson = getSourceContent(containerIdx);
    var path = "updatedevicedescription";
    if (existingJson != updatedJson) {
        if ((updatedJson != '') && (deviceId != '')) {
            var data = {
                device: deviceId,
                desc: updatedJson
            };
            $(containerIdx).html(updatedJson);
            LYFENET.Core.Ajax.customrequest(path, data, onResponseAjax);
			var undefinedVar;
			alertMessage('process','Processing...',undefinedVar,undefinedVar,true);
        }
    } else {
        alertMessage('info', "No changes in Json!");
    }
}

function updateConfigJson() {
    $("#configJsonModal").modal("hide");
    var updatedJson = jsonEditor.getText();
    var deviceConfigId = getSourceValue("#deviceConfigIdx");
    var containerConfigIdx = getSourceValue("#containerConfigIdx");
    var existingJson = getSourceContent(containerConfigIdx);
    var path = "updatedeviceConfig";
    if (existingJson != updatedJson){
        if ((updatedJson != '')&&(deviceConfigId != '')){
            var data ={
                device: deviceConfigId,
                desc: updatedJson
            };
            $(containerConfigIdx).html(updatedJson);
            LYFENET.Core.Ajax.customrequest(path, data, onResponseAjax);
			var undefinedVar;
			alertMessage('process','Processing...',undefinedVar,undefinedVar,true);
        }
    } else {
        alertMessage('info', "No changes in Json!");
    }
}

function addDeviceDetails(){
	var siteId = getSourceValue("#siteSelector");
    var siteName = getSourceOption('#siteSelector','text');
    var deviceId = getSourceValue("#deviceId");
    var deviceName = getSourceValue("#deviceName");
    var deviceRef = getSourceValue("#deviceRef");
    var deviceClass = getSourceValue("#deviceClass");
    var deviceClassText =getSourceOption('#deviceClass','text');
    var deviceStatus = getSourceValue("#deviceStatus");
    var deviceStatusText = getSourceOption('#deviceStatus','text');
	$('#addDeviceModal').modal('hide');
	$('#table').empty();
	$("#deviceLoadingIndicator").removeClass("hide");
    var path = "insertdevicedetails";
	var data = {
		deviceId: deviceId,
		deviceName: deviceName,
		deviceRef: deviceRef,
		deviceClass: deviceClass,
		siteId: siteId,
		deviceStatus: deviceStatus
	};
	LYFENET.Core.Ajax.customrequest(path, data, onCustomResponseAjax);
	var undefinedVar;
	alertMessage('process','Processing...',undefinedVar,undefinedVar,true);
}

function onCustomResponseAjax(response){
	if(response.data){
		alertMessage('success',response.data);
		if(response.reload){
			var siteId = $('#siteSelector').val();
			location.href = 'managesitedevices?siteId='+siteId;
		}
	}
	if(response.error){
		alertMessage('error',response.error);
	}
}
	
function updateDeviceDetailsResponse(response) {
    onResponseAjax(response);
    updatesiteSelector();
}

function descriptionjsonEditor(jsonContainerId, deviceId) {
    if (0 != editFlag){
        return false;
	}
    var modelContainer = document.getElementById('modalJsonContainer');
    $(modelContainer).empty();
    var json = JSON.parse($('#jsonContainer' + jsonContainerId).html());
    json = (typeof (json) == 'string') ? JSON.parse(json) : json;
    jsonEditor = editJsonContents(json, modelContainer);
    showModalContent('jsonModal');
    $("#deviceIdx").val(deviceId);
    containerIndex = "#jsonContainer" + jsonContainerId;
    $("#containerIdx").val(containerIndex);
}

function configJsonEditor(jsonContainerId, deviceId) {
    if (0 != editFlag){
        return false;
	}
    var modelContainer = document.getElementById('configModalJsonContainer');
    $(modelContainer).empty();
    var json = JSON.parse($('#configJsonContainer' + jsonContainerId).html());
    json = (typeof (json) == 'string') ? JSON.parse(json) : json;
    jsonEditor = editJsonContents(json, modelContainer);
    showModalContent('configJsonModal');
    $("#deviceConfigIdx").val(deviceId);
    containerIndex = "#configJsonContainer" + jsonContainerId;
    $("#containerConfigIdx").val(containerIndex);
}