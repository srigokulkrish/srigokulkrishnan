$(document).ready(function(){
		//var title=$('.navbar-text').html();
		var title=$(document).prop('title');
		title=(title==undefined)? 'Home' : title;
	if(isAndroid()){
		$('.menuTop').css('display','none');
		$('#mainMenuContainer').css('display','none');
		$('.navbar-custom').css('margin-top','0');
		$('.pageContainer').css('margin-top','0');
		if(title!='Home'){
			var path=Config.Dashboard.getmenuitems;
			var data={};
			menuserviceAjaxProcess(path,data);
			$('#viewform').attr("href","viewformdata");
		}
		var appVersion=Android.getAppVersion();
		try{
			Android.pageTitle(title);
		}catch(err){
			console.log(err.message);
		}
	}else{
		$('#viewform').attr("href","viewdata");
	}
});
function isAndroid(){	
	return !('undefined' === typeof Android || null === Android);
}
function menuserviceAjaxProcess(path,data) {
	data = (data == '') ? {} : data;
	if (path == '') {
		console.log('Path is empty!');
	} else {
		$.ajax({
			async: true,
			url: path,
			data: data,
			crossDomain: true,
			success: function(response) {
				if (!response) {
					console.log("Empty response when making AJAX request");
				}else {
					response = (typeof(response) === "string")?JSON.parse(response):response;
					formMenuItems(response);
				}
			},
			error: function(jqXHR, textStatus, errorThrown) {

				console.log("Error occured when making AJAX request: " + errorThrown);
			}
		});
	}
}
function formMenuItems(menuData){
	var formattedJson=[];
	var lengthOfArray=menuData.menu.length;
	for(var i=0;i<lengthOfArray;i++){
		var menuItemsLength=menuData.menu[i].menuItems.length;
		var menuitem={};

		menuitem["linkKey"]=menuData.menu[i].menuHeading;
		menuitem["displayName"]=menuData.menu[i].menuHeading;
		menuitem["actionURL"]="#";
		menuitem["actionFunction"]="";
		menuitem["image"]="link";
		menuitem["children"]=[];
		var eachmenuitem={};
		for(var j=0;j<menuItemsLength;j++){
			var displayName=menuData.menu[i].menuItems[j].menuDisplayName;
			var linkKey=menuData.menu[i].menuItems[j].menuDisplayUrl;
			var linkKey=menuData.menu[i].menuItems[j].menuDisplayUrl;
			eachmenuitem["displayName"]=displayName;
			eachmenuitem["linkKey"]=linkKey;
			eachmenuitem["actionURL"]=Config.FosController.actionURL+linkKey;
			eachmenuitem["image"]="link";
			if(linkKey=='viewtemplates'){
				eachmenuitem["actionFunction"]="createMyForm";
			}else if(linkKey=='viewformdata'){
				eachmenuitem["actionFunction"]="editSavedForm";
			}
			else{
				eachmenuitem["actionFunction"]="";
			}
			menuitem.children.push(eachmenuitem);
			eachmenuitem={};
		}
		if((menuitem!=undefined)&&(menuitem!=null)&&(menuitem!='')){
			formattedJson.push(menuitem);
		}else{
			var menuitem={};
			formattedJson.push(menuitem);
		}

	}
	
	var jsonString=JSON.stringify(formattedJson);
	if(Config.FosController.menuData ==""){
		Config.FosController.menuData=jsonString;
		loginSuccess();
	}
}

function loginSuccess(){	
	var jsonString=Config.FosController.menuData;
	Android.loginSuccess(jsonString);
}