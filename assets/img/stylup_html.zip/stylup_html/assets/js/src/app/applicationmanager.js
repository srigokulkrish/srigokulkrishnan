ApplicationManager = (function(){
	var pm = {};
	
	pm.dataManager = DataManager();
	
	pm.getDataManager = function(){
		return pm.dataManager;
	};
	pm.getSiteId = function(){
		return LYFENET.Core.getUrlParam('siteId');
	};
	pm.getDeviceId = function(){
		return LYFENET.Core.getUrlParam('deviceId');
	};
	pm.getAppType = function(){
		return LYFENET.Core.getUrlParam('type');
	};
	pm.getAppId = function(){
		return LYFENET.Core.getUrlParam('id');
	};
	return pm;
})();
