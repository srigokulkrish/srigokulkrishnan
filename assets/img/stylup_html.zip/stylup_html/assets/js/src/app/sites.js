$(document).ready(function() {
	init();
});
var markers = new Array();
var map;
var statusDiv = '';
var siterunningdiv='';
var sitesArray = '';
var sensorAlert= {};
var sensorAlertCount= {};
var	Alaramcount=0;	
var	Normalcount=0;
var	Idlecount=0;
function init() {
	updateDeviceData();
}

function updateDeviceData() {
	var requestData = {};
	LYFENET.Core.Ajax.request(Config.Dashboard.allsitedetails, requestData, siteDetails);
	showLoadingIndicator();
}
function resetZoomMap(){
	infoWindow.close();
	map.setZoom(Config.Dashboard.MapZoomDefaultSize);
}
function onUpdateDeviceData(sitesArray) {
	hideLoadingIndicator();
	displaySiteTable(sitesArray, '.deviceDetails');
	var defaultSite = sitesArray[0];
	var mapOptions = {
		center: new google.maps.LatLng(defaultSite.latitude, defaultSite.longitude),
		zoom: 5,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	map = new google.maps.Map(document.getElementById('dvMap'), mapOptions);
	infoWindow = new google.maps.InfoWindow();
	var lat_lng = new Array();
	
	var icons="images/mappins/map-pointer-red-gif 30.gif";
	var latlngbounds = new google.maps.LatLngBounds();
	for (i = 0; i < sitesArray.length; i++) {
		var site = sitesArray[i];
		//alert(sensorAlert[site.siteName]);
		var siteNametemp  = site.siteName.replace(" ","_");
		if(0==sensorAlert[siteNametemp])
			icons="images/mappins/map-pointer-green-30.png";
		var myLatlng = new google.maps.LatLng(site.latitude, site.longitude);
		lat_lng.push(myLatlng);
		var marker = new google.maps.Marker({
			position: myLatlng,
			map: map,
			 icon: icons,
			 optimized:false,
			title: site.title
		});
		latlngbounds.extend(marker.position);
		(function(marker, site) {
			google.maps.event.addListener(marker, "click", function(e) {
				
				var val = displaySiteDetailsInMap(JSON.parse(site.config),site.siteName);
				val += "<br/><div id='sensorContainer'> </div>" ;
				getSensorValues(site.siteId);
				//var val = "Site Id : " + site.siteName + "<br>";
				infoWindow.setContent(val);
				infoWindow.open(map, marker);
				map.setZoom(Config.Dashboard.MapZoomSize);
				map.setCenter(marker.getPosition());
			});
			markers[site.siteId] = marker;
		})(marker, site);
	}
	map.setCenter(latlngbounds.getCenter());
	//map.fitBounds(latlngbounds);//commented out to show a zoomed out map.
}

function displaySiteTable(stateTable, targetContainer) {
	var contextvalue = "<table  id='device_table' class='table table-striped table-hover table-condensed'><thead>";
	contextvalue += "<th>Site Id</th>";
	contextvalue += "<th>Site Name</th>";
	contextvalue += "<th>Site Address</th>";	
	contextvalue += "<th>Status</th>";
	contextvalue += "<th>Action</th>";
	contextvalue += "<th><div type='button' class='btn btn-sm btn-info' onclick='resetZoomMap()'>Reset Zoom</div> " + "</th>";
	contextvalue += "</thead><tbody>";
	var value = stateTable;
	for (var i = 0; i < value.length; i++) {
		var config = value[i].config;
		configJson = JSON.parse(config);
		var siteId = value[i].siteId;
		var siteName = value[i].siteName;
		var siteDisplayName = configJson["Site Name"];
		var siteLocation = configJson["Location"];
		contextvalue += "<tr id='" + siteId + "'>";
		contextvalue += "<td>" + siteName + "</td>";
		contextvalue += "<td>" + siteDisplayName + "</td>";
		contextvalue += "<td>" + siteLocation + "</td>";
		var siteNametemp  = siteName;
		siteNametemp  = siteNametemp.replace(" ","_");
		contextvalue += "<td><div id ='status"+siteNametemp+"' class='alarmStatusMarker'></div> </td>";
		contextvalue += "<td><button type='submit' class='btn btn-sm btn-info' onclick='onSiteSelected(" + siteId + ")'>Select</button> " + "</td>";
		contextvalue += "<td><div class='mapIcon' onclick='mapZoom(" + siteId + ")'><img src=\"" + Config.ImageBaseDir + "map_icon.png\"/></div></td>";
		contextvalue += "</tr>";
        		//siterunningdiv='';
	}
	contextvalue += "</tbody></table>";
	$('#table').html(contextvalue);
	for(id in sensorAlertCount){
		if(sensorAlertCount[id]['alert']){
			$('#status' + id).addClass("speed500ms");
			$('#status' + id).html(sensorAlertCount[id]['alert']);
		}
		else if(sensorAlertCount[id]['normal']){
			$('#status' + id).addClass("normalMark");
			//$('#status' + id).html(sensorAlertCount[id]['normal']);
		}
		else{
			$('#status' + id).addClass("idleMark");
			//$('#status' + id).html(sensorAlertCount[id]['idle']);
		}
	}
}

function siteDetails(sitesArray) {
	for (var site in sitesArray) {
		var siteId = sitesArray[site].siteId;
		var dataDash = {
			siteId: siteId,
			groupTag: 'dashboard_site'
		};
		var siteStatusResponse = function(siteName,response) {
				getSiteStatus(response, sitesArray,siteName);
			}
			var siteNametemp  = sitesArray[site].siteName;
			siteNametemp  = siteNametemp.replace(" ","_");
		// making ajax call for each siteid to get data and check status for each site
		var responseCurry = LYFENET.Core.curry(siteStatusResponse, siteNametemp);
		LYFENET.Core.Ajax.request(Config.Dashboard.Views, dataDash, responseCurry);
	}
}
// it method used to get status of each site
function getSiteStatus(response, sitesArray,siteName) {
	return onUpdateDeviceData(sitesArray);;
	
	var dashboarddata = response;
	var sensors = dashboarddata.group[0].views[1];
	var energyMeter = dashboarddata.group[0].views[0];
   differentstatuscheck(sensors,sitesArray,siteName);
   differentstatuscheck(energyMeter,sitesArray,siteName);	
}
function differentstatuscheck(sensors,sitesArray,siteName){
	if(!sensors){
		return false;
	}
	
	Alaramcount=0;	
	Normalcount=0;
	Idlecount=0;
	var tabTitleText = sensors.viewName;
	onUpdateDeviceData(sitesArray);
	for (var childIdx in sensors.children) {
		var child = sensors.children[childIdx];
		var activeTab = (0 == childIdx);
		var viewTypeId = child.viewTypeId;		
		var displayViewName = child.viewName.trim();
		var params = child.params;
			if(viewTypeId == 2) {
				paramvalue(params, viewTypeId, sitesArray,siteName);
			}
			if(viewTypeId ==1 && displayViewName =="DCEM") {
				siterunningstatus(params, viewTypeId, sitesArray);
			}
	}
}
function siterunningstatus(params, viewTypeId, sitesArray){
for (var i = 0; i < params.length; i++) {
		var dataItem = params[i];
		var dataUnit = dataItem["dataUnit"];
		
		var displayType = dataItem.displayType;
		var siteId = dataItem["siteId"];
		console.log("siteId"+siteId);
		if (dataItem["hide"]) {
			continue;
		}
			var ParamDisplayName=dataItem["paramDisplayName"].trim();
			if(ParamDisplayName == "Grid B"){
				var gridBStatus = dataItem["displayValue"];
			}
			if(ParamDisplayName == "Grid Y"){
				var gridYStatus = dataItem["displayValue"];
			}
			if(ParamDisplayName == "Grid R"){
				var gridRStatus = dataItem["displayValue"];
			}
			if(ParamDisplayName == "DG Running Status"){
				var dgStatus = dataItem["displayValue"];
			}
			if(ParamDisplayName == "Power Outage"){
				var powerOutage = dataItem["displayValue"];
			}
		}
	
	siterunningdiv='';
		if(gridBStatus == 1 || gridYStatus ==1 || gridRStatus ==1){
			alarmMarkerClass = "normalMark";			
			siterunningdiv = "<div class='alarmStatusMarker " + alarmMarkerClass + "'></div>";
			console.log("---SiteId--------"+siteId);
			console.log("---siterunningdiv--------"+siterunningdiv);
			$('#status1' + siteId + '').append(siterunningdiv);		
		}
		else if(dgStatus==1){
			alarmMarkerClass = "alertMark speed1000ms";
			siterunningdiv = "<div class='alarmStatusMarker " + alarmMarkerClass + "'></div>";
			$('#status1' + siteId + '').append(siterunningdiv);
		
		}
	    else if(powerOutage==1){
			alarmMarkerClass = "alertMark speed1000ms";
			siterunningdiv = "<div class='alarmStatusMarker " + alarmMarkerClass + "'></div>";
		$('#status1' + siteId + '').append(siterunningdiv);

		}
		else{
		alarmMarkerClass = "alertMark speed1000ms";
			siterunningdiv = "<div class='alarmStatusMarker " + alarmMarkerClass + "'></div>";
		$('#status1' + siteId + '').append(siterunningdiv);
		
		}
}
function paramvalue(params, viewTypeId, sitesArray,siteName) {
	for (var i = 0; i < params.length; i++) {
		var dataItem = params[i];
		var dataUnit = dataItem["dataUnit"];		
		var displayType = dataItem.displayType;
		if (dataItem["hide"]) {
			continue;
		}
		if (2 == viewTypeId) {			
			var dataValue = dataItem["displayValue"];
			var siteId = dataItem["siteId"];
			if(dataValue == 1){
				++Alaramcount;
			}	
			else if(dataValue == 0){
				++Normalcount;
			}	
			else{	
				++Idlecount;
			}	
	}
	}
	var alarmMarkerClass = '';
	sensorAlert[siteName]=Alaramcount;
	if (0<Alaramcount)
		sensorAlertCount[siteName]={'alert':Alaramcount};
	else if(0<Normalcount)
		sensorAlertCount[siteName]={'normal' :Normalcount};
	else if(0<Idlecount)
		sensorAlertCount[siteName]={'idle':Idlecount};
}
function onSiteSelected(siteId) {
	window.location.href = Config.Dashboard.Main + '?siteId=' + siteId;
}

function mapZoom(siteId) {
	marker = markers[siteId];
	map.setCenter(marker.getPosition());
	map.setZoom(Config.Dashboard.MapZoomSize);
	google.maps.event.trigger(marker, 'click');
}

function showLoadingIndicator(){
	$('.loadingIndicator').css({
		'display': 'block'
	});
	$('.deviceDetails').css({
		'display': 'none'
	});
}

function hideLoadingIndicator() {
	$('.loadingIndicator').css({
		'display': 'none'
	});
	$('.deviceDetails').css({
		'display': 'block'
	});
}

function replaceAll(str, find, replace) {
	return str.replace(new RegExp(find, 'g'), replace);
}

function displaySiteDetailsInMap(siteDetails){
	var contentHtml = '';
	for(var idx in siteDetails){
		//var val = "Site Id : " + site.siteName + "<br>";
		contentHtml+=idx+' : '+siteDetails[idx] + "<br>";
	}	
	return contentHtml;
}
function getSensorValues(siteId){
	var data = {
		siteId: siteId,
		groupId: 1
	};
	var sensorDate = LYFENET.Core.Ajax.request(Config.Dashboard.Views, data,sensorResponse);
}
function sensorResponse(response){
	var viewData = response;
	var sensors = viewData.group[0].views[1];
	addView('sensorContainer', sensors);
	$('#sensorContainer').find('.panel').append('<div class="table-responsive  row legend">Legend:<br/><div class="item"><div class="alarmStatusMarker normalMark"></div>Normal</div><div class="item"><div class="alarmStatusMarker alertMark"></div>Alert</div><div class="item"><div class="alarmStatusMarker idleMark"></div>Offline</div></div>');
}