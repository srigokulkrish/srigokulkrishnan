AssetTracker = {};

function addView(targetContainer, dataset) {
	$('#' + targetContainer).html('<div class="panel panel-primary"><div class="panel-heading"><div class="title">Title</div></div><ul class="nav nav-tabs"></ul><div class="paramContent"></div></div>');

	var tabTitle = $('#' + targetContainer).find(".panel-heading .title");
	var tabTitleText = dataset.viewName;
	//var updateTimeDiv ='<div class="lastUpdateTime pull-right"></div>';
	tabTitle.html(tabTitleText);
	for (var childIdx in dataset.children) {
		var child = dataset.children[childIdx];
		var activeTab = (0 == childIdx);
		showDeviceParameters(targetContainer, child, activeTab);
	}
	if (0 == dataset.children.length) {
		showDeviceWindow(targetContainer, dataset);
	}
}


function showDeviceParameters(targetContainer, dataset, activeTab) {
	var tabList = $('#' + targetContainer).find("ul");
	var tabTitleText = dataset.viewName;
	var viewTypeId = dataset.viewTypeId;
	var tabActiveStatus = (activeTab) ? "active" : "";
	var contentHandle = 'tabcontent_' + dataset.viewId;

	var params = dataset.params;
	
	if(0 == params.length){
		contextvalue += "<table class='table'>";
		contextvalue += "<tr></tr>";
		contextvalue += "<tr></tr>";
		contextvalue += "<tr>";
		contextvalue += "<th>No data available</th>";
		contextvalue += "</tr>";
		return false;
	}
	
	var dataItem = params[0];
	var contextvalue = "<div id='" + contentHandle + "'class='tab-content " + tabActiveStatus + "'>";
	if (3 == viewTypeId) {
		contextvalue += getAssetTable(params);
	}else if (4 == viewTypeId) {
		getControlContent(params, contentHandle);
	}else if (5 == viewTypeId) {
		getVideoContent(params, contentHandle);
	}else if (7 == viewTypeId) {
		var chartIntvHandler = LYFENET.Core.curry(getChartContent,params, contentHandle);
		chartIntvHandler();
		setInterval(chartIntvHandler, Config.Dashboard.DataSyncInterval);
	}else {
		contextvalue += getParamTable(params, viewTypeId);
	}
	
	
	
	contextvalue += "</div>";
	var dateTimeString = (dataItem)?dataItem["updatedDT"]:"";
	var dataTime = ((dateTimeString))?Date.parse(dateTimeString).setTimezoneOffset("+0000").toString("yyyy-MM-dd hh:mm tt"):"";
	var lastUpdatedText = "Last Updated: " + dataTime;
	tabList.append('<li class="' + tabActiveStatus + '" title="' + lastUpdatedText + '"><a data-toggle="tab" class="alarm-info" href="#' + contentHandle + '">' + tabTitleText + '</a></li>');
	$('#' + targetContainer).find(".paramContent").append(contextvalue);
}

function showDeviceWindow(targetContainer, dataset) {
	var viewTypeId = dataset.viewTypeId;
	var contentHandle = 'contentblock_' + dataset.viewId;
	var params = dataset.params;
	var dataItem = params[0];
	var contextvalue = "<div id='" + contentHandle + "' >";
	contextvalue += "</div>";
	$('#' + targetContainer).find(".paramContent").append(contextvalue);

	var pContent = '';
	if(0 == params.length){
		pContent += "<table class='table'>";
		pContent += "<tr></tr>";
		pContent += "<tr></tr>";
		pContent += "<tr>";
		pContent += "<th>No data available</th>";
		pContent += "</tr>";
		$('#' + contentHandle).append(pContent);
		return false;
	}
	
	if (3 == viewTypeId) {
		pContent += getAssetTable(params);
	}else if (4 == viewTypeId) {
		getControlContent(params, contentHandle);
	}
	else if (5 == viewTypeId) {
		getVideoContent(params, contentHandle);
	}else if (7 == viewTypeId) {
		var chartIntvHandler = LYFENET.Core.curry(getChartContent,params, contentHandle);
		chartIntvHandler();
		setInterval(chartIntvHandler, Config.Dashboard.DataSyncInterval);
	}else {
		pContent += getParamTable(params, viewTypeId);
	}	
	
	$('#' + contentHandle).append(pContent);
	var dateTimeString = (dataItem)?dataItem["updatedDT"]:"";
	var dataTime = ((dateTimeString))?Date.parse(dateTimeString).setTimezoneOffset("+0000").toString("yyyy-MM-dd hh:mm tt"):"";
	var lastUpdatedText = "Last Updated: " + dataTime;
	$('#' + targetContainer).parent().find(".panel-heading").attr("title", lastUpdatedText);
}

function getAssetTable(params){
	var contextvalue = "";
	for (var i = 0; i < params.length; i++) {
		var dataItem = params[i];
		contextvalue += "<table class='table'>";
		contextvalue += "<tr>";
		contextvalue += "<th>Asset Name</th>";
		contextvalue += "<th>Status</th>";
		contextvalue += "<th>Asset ID</th>";
		contextvalue += "</tr>";
		var configDataJson = dataItem["config"].assets;
		if(dataItem.hasOwnProperty("displayValue")){
			var assetDataJson = JSON.parse(dataItem["displayValue"]);
			for (var idx in configDataJson) {
				var asset = configDataJson[idx];
				
				var assetFound = false;
				for (var aid in assetDataJson) {
					var suspect = assetDataJson[aid];
					if (suspect.MAC == asset.MAC) {
						assetFound = suspect;
						break;
					}
				}
				if ( assetFound && dataItem["dataAge"] < 120 ) {
					AssetTracker[asset.MAC] = 0;
					contextvalue += "<tr>";
					contextvalue += "<td>" + asset.assetName + "</td>";
					contextvalue += "<td class='normalMark'>Present</td>";
					contextvalue += "<td>" + asset.MAC + "</td>";
					contextvalue += "</tr>";
				} else{
					if(AssetTracker.hasOwnProperty(asset.MAC)){
						AssetTracker[asset.MAC]++;
					}
					else{
						AssetTracker[asset.MAC] = 0;
					}
					
					if(3 <= AssetTracker[asset.MAC]){
						contextvalue += "<tr>";
						contextvalue += "<td>" + asset.assetName + "</td>";
						contextvalue += "<td class='alertMark'>Missing</td>";
						contextvalue += "<td>" + asset.MAC + "</td>";
						contextvalue += "</tr>";
					}
					else{
						contextvalue += "<tr>";
						contextvalue += "<td>" + asset.assetName + "</td>";
						contextvalue += "<td class='idleMark'>Scanning</td>";
						contextvalue += "<td>" + asset.MAC + "</td>";
						contextvalue += "</tr>";
					}
				}
			}
		}
		contextvalue += "</table>";
	}
	return contextvalue;
}

function getParamTable(params, viewTypeId){
	var contextvalue = "<table  class='table'>";
	
	for (var i = 0; i < params.length; i++) {
		var dataItem = params[i];
		var dataUnit = dataItem["dataUnit"];
		var displayType = dataItem.displayType;
		var configDataJson = dataItem["config"];
		var displayConfig = dataItem["displayConfig"];
		if(dataItem["hide"]){
			continue;
		}
		contextvalue += "<tr>";
		
		var label = (null == dataItem["displayLabel"])?dataItem["paramDisplayName"] : dataItem["displayLabel"];
		contextvalue += "<td>" + label + "</td>";
		if (1 == viewTypeId && 'BOOLEAN' == dataUnit) {
			var tval = ("1" == dataItem["displayValue"]) ? "YES" : "NO";
			contextvalue += "<td>" + tval + "</td>";
		} else if (1 == viewTypeId && 'BOOLEAN_OKFAULT' == dataUnit) {
			var tval = ("1" == dataItem["displayValue"]) ? "FAULT" : "OK";
			contextvalue += "<td>" + tval + "</td>";
		} else if (1 == viewTypeId && 'BOOLEAN_ONOFF' == dataUnit) {
			var tval = ("1" == dataItem["displayValue"]) ? "ON" : "OFF";
			contextvalue += "<td>" + tval + "</td>";
		} else if (1 == viewTypeId && 'BOOLEAN_OPENCLOSE' == dataUnit) {
			var tval = ("1" == dataItem["displayValue"]) ? "OPEN" : "CLOSED";
			contextvalue += "<td>" + tval + "</td>";
		} else if (1 == viewTypeId && 'BOOLEAN_OPENCLOSE_INV' == dataUnit) {
			var tval = ("1" == dataItem["displayValue"]) ? "CLOSED" : "OPEN";
			contextvalue += "<td>" + tval + "</td>";
		}else if (1 == viewTypeId && displayType == 1 && 'BIT' == dataUnit) {
			var configBitmaps = configDataJson.bitmaps;
			var bitVal = dataItem["displayValue"];
			contextvalue += "<td></td></tr>";
			for (var idx in configBitmaps) {
				var bitItem = configBitmaps[idx];
				var bitName = bitItem.displayName;
				var bitPosition = bitItem.bitPosition;
				var bitRes = bitVal & parseInt(bitPosition,2);
				var bitValue =  (bitRes > 0)?"normalMark":"idleMark";
				contextvalue += "<tr>";
				contextvalue += "<td>" + bitName + "</td>";
				contextvalue += "<td><div class='alarmStatusMarker " + bitValue + "'></div></td>";
				contextvalue += "</tr>";
			}
		}else if (1 == viewTypeId && displayType == 1 && 'BIT_INV' == dataUnit) {
			var configBitmaps = configDataJson.bitmaps;
			var bitVal = dataItem["displayValue"];
			contextvalue += "<td></td></tr>";
			for (var idx in configBitmaps) {
				var bitItem = configBitmaps[idx];
				var bitName = bitItem.displayName;
				var bitPosition = bitItem.bitPosition;
				var bitRes = bitVal & parseInt(bitPosition,2);
				var bitValue =  (bitRes > 0)?"alertMark":"normalMark";
				contextvalue += "<tr>";
				contextvalue += "<td>" + bitName + "</td>";
				contextvalue += "<td><div class='alarmStatusMarker " + bitValue + "'></div></td>";
				contextvalue += "</tr>";
			}
		}else if (1 == viewTypeId && 'BOOLEAN' != dataUnit) {
			if(displayConfig){
				var displayConfigJson = JSON.parse(displayConfig);
				switch(displayConfigJson.format){
					case "hoursmin":
						hours = parseInt(dataItem["displayValue"]);
						mins = parseInt((dataItem["displayValue"] - hours)*60);
						hours = (1 < hours)? hours + " hrs" : hours + "hr";
						mins = (1 < mins)? mins + " mins" : mins + "min";
						contextvalue += "<td>" + hours + " " + mins + "</td>";
					break;
					
					default:
						var floatVal = parseFloat(dataItem["displayValue"]).toFixed(2);
						var displayString = (dataItem["displayValue"])? floatVal + ' ' + dataUnit : "--";
						contextvalue += "<td>" + displayString + "</td>";
				}				
			}else if('STRING'== dataItem["dataFormat"]){
				var displayString = dataItem["displayValue"];
						contextvalue += "<td>" + displayString + "</td>";
			}else{
				var floatVal = parseFloat(dataItem["displayValue"]).toFixed(2);
				var displayString = (dataItem["displayValue"])? floatVal + ' ' + dataUnit : "--";
						contextvalue += "<td>" + displayString + "</td>";
			}
		
			
		}else if (2 == viewTypeId) {
			var alarmMarkerClass = "grey";
			if ('1' == dataItem["displayValue"]) {
				alarmMarkerClass = "alertMark speed1000ms";
			} else if ('0' == dataItem["displayValue"]) {
				alarmMarkerClass = "normalMark";
			} else {
				alarmMarkerClass = "idleMark";
			}
			var siteID = LYFENET.Core.getUrlParam('siteId');
			var siteId = (siteID == 'null')? $('#selectsite').val() : siteID;
			//var chartPath = 'devicestatechartview?siteId='+siteId+'&deviceName='+dataItem["deviceName"]+'&stateName='+dataItem["paramName"];
			//contextvalue += "<td><div class='text-center' onclick=\"redirectUrl('"+chartPath+"',true);\"><i class='glyphicon glyphicon-picture' title='Click to View recent Data'></i></div></td>";
			contextvalue += "<td><div class='alarmStatusMarker " + alarmMarkerClass + "'></div></td>";
		}else if (6 == viewTypeId) {
			var alarmMarkerClass = "grey";
			if ('1' == dataItem["displayValue"]) {
				alarmMarkerClass = "normalMark";
			} else if ('0' == dataItem["displayValue"]) {
				alarmMarkerClass = "idleMark";
			} else {
				alarmMarkerClass = "idleMark";
			}
			contextvalue += "<td><div class='alarmStatusMarker " + alarmMarkerClass + "'></div></td>";
		}else {
			contextvalue += "<td>" + dataItem["displayValue"] + "</td>";
		}
		contextvalue += "</tr>";
	}
	contextvalue += "</tbody></table>";
	return contextvalue;
}

function getControlContent(params, contentHandle){
	for (var i = 0; i < params.length; i++) {
		var dataItem = params[i];
		var paramName = dataItem["paramName"];
		
		var deviceId = dataItem["deviceId"];
		var configDataJson = dataItem["config"].controls;
		for (var idx in configDataJson) {
			var control = configDataJson[idx];
			var action = control.action;
			var btnName = control.displayName;
			//var actionCurry = LYFENET.Core.curry(invokeAction, actionParam);
			var actionCurry = LYFENET.Core.curry(openAuthorizeWindow, control); //for open a window for authorize code
			var controlHandle = "control_" + deviceId + "_" + action + "_" + idx;
			var controlHtml = "<input type='button' id='" + controlHandle + "' value='" + btnName + "' />";
			$('#' + contentHandle).append(controlHtml);
			$('#' + controlHandle).click(actionCurry);
		}
	}
}

function getVideoContent(params, contentHandle){
	for (var i = 0; i < params.length; i++) {
		var videoParam = params[i];
		var paramName = videoParam["paramName"];
		var camName = videoParam["paramDisplayName"];
		var pConfig = videoParam["config"].videos[paramName];
		//var pConfig = JSON.parse(videoParam["displayConfig"]);
		var onVideoLoad = function(markup){
			$('#' + contentHandle).append(markup);
		}
		LYFENET.Core.Ajax.getFile(pConfig.source, {}, onVideoLoad);
	}
}

function getChartContent(params, contentHandle){
	dashBoardChart.data=[];
	if(!$('#' + contentHandle).hasClass('chartHolder'))
	$('#' + contentHandle).addClass('chartHolder');
	for (var i = 0; i < params.length; i++) {
		var paramContent = params[i];
		var datasource = params[i].dataSource;
		var data={
			contentHandle:contentHandle,
			siteId:paramContent.siteId,
			deviceId:paramContent.deviceId,
			deviceName:paramContent.deviceName,
			paramDisplayName:paramContent.paramDisplayName,
			timeLB:Math.floor(Date.now() / 1000) - (60*30),
			timeUB:Math.floor(Date.now() / 1000),
		};
		if(datasource == '1' || datasource == '3'){
			dashBoardChart.currentParam = paramContent.paramName;
			data['paramName']=paramContent.paramName;
			data['interval']=60;
			data['thresholdLB']=0;
			data['thresholdUB']=300;
			var reqCurry = LYFENET.Core.curry(addParameterResponseChart, data);			
			ChartHelper.GetHourlyParamValue(data, reqCurry);
		}else if(datasource == '2' || datasource == '4'){
			dashBoardChart.currentParam = paramContent.paramName;
			data['stateName']=paramContent.paramName;
			data['stateValue']=paramContent[paramContent.paramName];
			var reqCurry = LYFENET.Core.curry(addStateResponseChart, data);
			ChartHelper.GetHourlyStateTimeData(data, reqCurry);
		}
	}

}