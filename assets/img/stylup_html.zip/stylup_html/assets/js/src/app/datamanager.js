/**
* DataManager class helps manage a data store by retriving and synchronizing server data on client side. 
  Other client components and widgets can consume data from this data store.
**/
DataManager = function(){
	console.log('DataManager constructor called.');
	var that = this;
	
	var pm = {
		dataset:{},
		dataChannels:{},
		addChannel:function(config){
			if(!pm.isConfigValid(config)){
				console.log("DataManager: Invalid config. Aborting.");
				return false;
			}
			
			var syncFreq 	= config.syncfrequency ? config.syncfrequency : 30000;			
			var channel 	= {};
			channel.config 	= config;
			channel.parser 	= config.parser;
			var flagNewChannel  = pm.setChannel(config, channel);
			
			if(flagNewChannel){
				var curry = LYFENET.Core.curry(pm.sync, config);
				channel.handle = setInterval( curry, syncFreq);
				curry();
			}
		},
		setChannel: function(config, channel){
			var flagNewChannel = false;
			var key 		= config.channelKey;
			var type 		= config.sourceType;
			var id 			= config.sourceId;
			var label 		= config.label;
			var interval 	= config.interval;
			
			if(!pm.dataChannels.hasOwnProperty(key)){
				pm.dataChannels[key] = {};
				flagNewChannel = true;
			}
			if(!pm.dataChannels[key].hasOwnProperty(type)){
				pm.dataChannels[key][type] = {};
				flagNewChannel = true;
			}
			if(!pm.dataChannels[key][type].hasOwnProperty(id)){
				pm.dataChannels[key][type][id] = {};
				flagNewChannel = true;
			}
			if(!pm.dataChannels[key][type][id].hasOwnProperty(label)){
				pm.dataChannels[key][type][id][label] = {};
				flagNewChannel = true;
			}
			if(!pm.dataChannels[key][type][id][label].hasOwnProperty(interval)){
				pm.dataChannels[key][type][id][label][interval] = {};
				flagNewChannel = true;
			}
			
			pm.dataChannels[key][type][id][label][interval] = channel;
			return flagNewChannel;
		},
		getChannel: function(config){
			var key 		= config.channelKey;
			var type 		= config.sourceType;
			var id 			= config.sourceId;
			var label 		= config.label;
			var interval 	= config.interval;
			
			if(!pm.dataChannels.hasOwnProperty(key)
				|| !pm.dataChannels[key].hasOwnProperty(type)
				|| !pm.dataChannels[key][type].hasOwnProperty(id)
				|| !pm.dataChannels[key][type][id].hasOwnProperty(label)
				|| !pm.dataChannels[key][type][id][label].hasOwnProperty(interval)){
				return null;
			}
			return pm.dataChannels[key][type][id][label][interval];
		},
		deleteChannel: function(config){
			var key 		= config.channelKey;
			var type 		= config.sourceType;
			var id 			= config.sourceId;
			var label 		= config.label;
			var label 		= config.interval;
			
			if(pm.dataChannels.hasOwnProperty(key)
				&& pm.dataChannels[key].hasOwnProperty(type)
				&& pm.dataChannels[key][type].hasOwnProperty(id)
				&& pm.dataChannels[key][type][id].hasOwnProperty(label)
				&& pm.dataChannels[key][type][id][label].hasOwnProperty(interval)){
				delete pm.dataChannels[key][type][id][label][interval];
			}
		},
		pause:function(config){
			var channel = pm.getChannel(config);
			if(channel && channel.handle){
				clearInterval(channel.handle);
			}			
		},
		resume:function(config){
			var syncFreq = config.syncfrequency;			
			var channel = pm.getChannel(config);
			var curry = LYFENET.Core.curry(pm.sync, config);
			channel.handle = setInterval( curry, syncFreq);
			curry();
		},
		clear:function(config){		
			pm.stop(config);
			pm.deleteChannel(config);
		},
		sync:function(config){
			var path = null;
			var params = {};
			
			switch(config.sourceType){
				case 'deviceByName':
					params = {
						deviceName: config.sourceId,
						siteId: ApplicationManager.getSiteId()
					};
					break;
				case 'deviceById':
					params = {
						deviceId: "self" != config.sourceId ? config.sourceId : ApplicationManager.getDeviceId()
					};
					break;
				case 'orgSummary':
					params = {
						type: ApplicationManager.getAppType(),
						id: ApplicationManager.getAppId()
					};
					break;
			}
			
			if('deviceByName' == config.sourceType || 'deviceById' == config.sourceType){
				switch(config.interval){
					case 'lastOne':
						path = Config.Device.GetLastOne;
						break;
					case 'hourly':
						path = Config.Device.GetCurrentHour;
						break;
					case 'daily':
						path = Config.Device.GetCurrentDay;
						break;
					default:
						path = Config.Device.GetCurrentHour;
						break;
				}
			}
			
			if('orgSummary' == config.sourceType){
				switch(config.interval){
					case 'lastOne':
						path = Config.Dashboard.OrgSummary;
						break;
					default:
						path = Config.Dashboard.OrgSummary;
						break;
				}
			}
			
			var channel = pm.getChannel(config);
			if(channel && channel.dataset && channel.dataset.lastIndex && true == config.useLastIndex){
				params.lastDataId = channel.dataset.lastIndex;
			}			
			
			LYFENET.Core.Ajax.request(path, params, LYFENET.Core.curry(pm.onSync, config));
			console.log('DataManager sync call initiated.');
		},
		onSync:function(config, rawdataset){
			var channel = pm.getChannel(config);
			if('function' === typeof channel.parser){
				pm.update( config, channel.parser(rawdataset) );
			}else{
				pm.update( config, rawdataset );
			}			
		},
		update:function(config, dataset){
			var channel = pm.getChannel(config);
			
			if(!channel){
				return false;
			}
			if(!channel.dataset){
				channel.dataset = { version:0, data:{} };
			}
			if('append' == config.mode){
				channel.dataset.data = Object.assign(channel.dataset.data, dataset);
			}else if('overwrite' == config.mode){
				channel.dataset = dataset;
			}
			else{
				channel.dataset = dataset;
			}
			if(true == config.useLastIndex){
				channel.dataset.lastIndex = pm.getLastIndex(dataset);
			}
			
			channel.dataset.version++;
		},
		fetch:function(config){
			var dataset = {};
			var channel = pm.getChannel(config);			
			if(channel){
				dataset = channel.dataset;
			}			
			return dataset;
		},
		isConfigValid: function(config){
			if(!config.channelKey){
				console.log("DataManager: Config Validation Failed. Invalid key");
				return false;
			}
			if(!config.sourceType){
				console.log("DataManager: Config Validation Failed. Invalid type");
				return false;
			}
			if(!config.sourceId){
				console.log("DataManager: Config Validation Failed. Invalid id");
				return false;
			}
			if(!config.label){
				console.log("DataManager: Config Validation Failed. Invalid label");
				return false;
			}
			if(!config.interval){
				console.log("DataManager: Config Validation Failed. Invalid interval");
				return false;
			}
			if('function' !== typeof config.parser){
				console.log("DataManager: Config Validation Failed. Data parser must be a valid function.");
				return false;
			}
			return true;
		},
		getLastIndex:function(dataset){
			var lastIndex = 0;
			for(var idx in dataset){
				lastIndex = Math.max(lastIndex, idx);
			}
			return lastIndex;
		}
	}
	return pm;
};