$(document).ready(function() {        
	$(".loginForm").submit(function(e){
		e.preventDefault();
	});
  
	$('ul.nav li.dropdown').hover(function() {
	  $(this).find('.dropdown-menu').not('.dropdown-submenu .dropdown-menu').stop(true, true).delay(200).fadeIn(200);
	}, function() {
	  $(this).find('.dropdown-menu').not('.dropdown-submenu .dropdown-menu').stop(true, true).delay(100).fadeOut(100);
	});
});
/* function checkRegisterValidation(){
	var name =  $("#name").val();
	var username =  $("#username").val();
	var email =  $("#email").val();
	var password =  $("#password").val();
	var checkbox =  $("#checkbox").is(":checked"); 
	var errormsg = '';
	var invalidmsg = '';
	var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	var letters = /^[A-Za-z]+$/;  
		if(name == ''){
			errormsg+=' Name';
		}
		else if(!name.match(letters))  
		{  
		alert("Letters Only Allowed Name Field");
		} 
		else if(username == ''){
			errormsg+=' UserName';
		}
		else if(email == ''){
			errormsg+=' Email Addres';
		}
		else if(!filter.test(email)){
			invalidmsg='Enter The Valid Email Address';
		}
		else if(password == ''){
			errormsg +=' Password';
		}
		else if((password.length) < 8){
			invalidmsg='Password Minimum Length 8';
		}
		else if(checkbox == false){
			invalidmsg='Please Accept Our Terms & Conditions';
		}
		else{
			$( "#signupForm" ).submit();
		}
		if(errormsg){
			$('.message').html('You cant Leave'+errormsg+' Empty');
		}
		if(invalidmsg){
			$('.message').html(invalidmsg);
		}
}*/
function checkRegisterValidation(formName){
	if ((checkPassword(formName.reg_password)) && (checkPassword(formName.reg_confirmpassword))){
		if (checkPasswordEqual(formName.reg_password,formName.reg_confirmpassword)){
		formName.submit();
		}
	}	
}

function employeeRegisterValidation(formName){
	if ((checkText(formName.emp_name)) && (checkEmail(formName.emp_email)) && (checkSelect(formName.emp_group))){
		formName.submit();
	}
}
function employeeUpdateValidation(formName){
	if ((checkSelect(formName.emp_group))){
		formName.submit();
	}
}
function viewEmployee(selectValue){
	var username =selectValue.value;
	if(username!=''){
	$(".updateShowHide").show();
	$.ajax ( {
		async: true,
		type: 'POST',
		url: 'getuser',
		data:{
			user:username
		},
		success: function(response){
				if(!response){
					console.log("Empty response when making AJAX request");
				}else{
					response = (typeof(response) === "string")?JSON.parse(response):response;
						$('#emp_code').val(response.empCode);
						$('#emp_email').val(response.email);
						$('#sel1').val(response.designationID);
						$('#emp_factorydetails').val(response.empDetails);
						$('#emp_group').val(response.uGroupID);
						if(1==response.receiveReports){
							$("#yes").attr('checked', true);
						}else{
							$("#no").attr('checked', true);
						}
						//console.log(data);
				}
		
		},
		error: function(XMLHttpRequest, textStatus, errorThrown){
			alert('Error : ' + errorThrown+'status: '+textStatus);
		}
	});
	}else{
		$(".updateShowHide").hide();
	}
}

function newUserFormValidation(formName){
	if ((checkText(formName.username)) && (checkEmail(formName.useremail)) && (checkSelect(formName.usergroup))){
		formName.submit();
	}
}

function loginCheck(formName){
	if ((checkEmail(formName.login_email)) && (checkPassword(formName.login_password))){
		formName.submit();
	}
}
function forgotPasswordCheck(formName){
	if (checkEmail(formName.forgot_email)){
		formName.submit();
	}
}
function chagePasswordFormCheck(formName){
	if ((checkPassword(formName.old_password)) && (checkPassword(formName.new_password))  && (checkPassword(formName.confirm_password))){
		if (checkPasswordEqual(formName.new_password,formName.confirm_password)){
		formName.submit();
		}
	}
}
function checkPasswordEqual(newPassword,confirmPassword){
	if (!(newPassword.value===confirmPassword.value)){
		$('.message').html('Both Password Should be Same!.');
		return false;
	}else{
		return true;
	}
}
function goBack(){
	location.href="login";
}
$(document).ready(function () {
    $('.logoutContainer').hover(function () {
		$('.logoutOption').css('display', 'block');
    }, function () {
		$('.logoutOption').css('display', 'none');
    });
});

function checkText(text) {
	text = text.value;
	var letters = /^[A-Za-z]+$/;  
	if (text == null || text == "") {
		$(".message").html('Name must be filled out');
    }
   else if(!text.match(letters))  
     {  
		$(".message").html('Name must Only Letters');
     }  
   else  
     {  
     return true;  
     }   
}

function checkEmail(email) {
	email = email.value;
	var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	if(email == null || email == ""){
			$(".message").html('Enter The Email Address');
	}
	else if(!filter.test(email)){
			$(".message").html('Enter The Valid Email Address');
	}
   else{  
     return true;  
     }   
}

function checkSelect(select) {
	if (select.value == '') {
		$(".message").html('Select User Group');
	}
	else{  
		return true;  
    }   
}

function checkPassword(password) {
password = password.value;
	if (password == null || password == "") {
		$(".message").html('Password Field Empty');
    }
	else{  
     return true;  
     }   
}

/* Messaging System  */
/* Select form type  */
$(document).on('change','#userType',function(e){
	
	var userType = $(this).val();
	if(userType == 1){
		
		$('#rawMessageForm').show();
		$('#MessageForm').hide();
		
	}else if(userType == 2){
		
		$('#MessageForm').show();
		$('#rawMessageForm').hide();
	}else{
        $('#MessageForm').hide();
		$('#rawMessageForm').hide();	
	}
});

/* Select User or Usergroup type  */
$(document).on('change','#user_userGroup',function(e){	
	var userType = $(this).val();
	if(userType == 1){
		$('#users').show();
		$('#userGroup').hide();
	}else if(userType == 2){
		$('#userGroup').show();
		$('#users').hide();
	}else{
	    $('#userGroup').hide();
		$('#users').hide();
	}
});

/* Send raw message form submit  */
$(document).on('submit','#rawMessageForm',function(e){
	e.preventDefault();
	var messageData = $('#rawMessageForm').serialize();
	$.ajax ( {
		async: true,
		type: 'POST',
		url: 'getMessages',
		data:messageData,
		dataType:'json',
		success: function(response){
			console.log(response);
		}
	});
});

/* Send message form submit  */
$(document).on('submit','#MessageForm',function(e){
	e.preventDefault();
	var messageData = $('#MessageForm').serialize();	
	$.ajax ( {
		async: true,
		type: 'POST',
		url: 'getMessages',
		data:messageData,
		dataType:'json',
		success: function(response){
			console.log(response);
		}
	});
});

/* Update Notification  */
$(document).on('click','.webNotify',function(e){
	e.preventDefault();
	var notifyId = $(this).attr('data-notifyId');
	var notifyLink = $(this).attr('data-link');
	var notifyData = "notification_id="+notifyId;	
	$.ajax ( {
		async: true,
		type: 'POST',
		url: 'updateWebNotification',
		data:notifyData,
		dataType:'json',
		success: function(response){
			console.log(response);
			if(response.status == 'success'){
			}
		}
	});
});

/* Request authorization  */
$(document).on('click','.request-btn',function(e){
	e.preventDefault();
	var requestCategory = $(this).attr('data-request');
	var requestUserLevel = $(this).attr('data-level');
	var requestData = "request_categry="+requestCategory+"&request_level="+requestUserLevel;
	$.ajax ({
		async: true,
		type: 'POST',
		url: 'sendRequest',
		data: requestData,
		dataType:'json',
		success: function(response){
			console.log(response);
		}
	});
});


/* Response to request authorization  */
$(document).on('change','.permission-access',function(e){
	e.preventDefault();	
	var requestId = $(this).attr('data-request');
	var requestCategory = $(this).attr('data-category');
	var requestStatus = $(this).val();
	var requestData = "request_id="+requestId+"&request_category="+requestCategory+"&status="+requestStatus;
	console.log(requestData);
	//return false;	
	$.ajax ( {
		async: true,
		type: 'POST',
		url: 'updateRequest',
		data: requestData,
		dataType:'json',
		success: function(response){
			console.log(response);
		}
	});
});

/* Test send email  */
$(document).on('click','#testMail',function(e){
	e.preventDefault();	
	$.ajax ( {
		async: true,
		type: 'GET',
		url: 'testSendEmail',
		dataType:'json',
		success: function(response){
			console.log(response);
		}
	});
});

//*****  Reports *****/
$(document).on('submit','#reportForm',function(ev){
	ev.preventDefault();
	var  data = $('#reportForm').serialize();
	var reportName = $('#report_name').val();
	var reportQuery = $('#report_query').val();
	var dateRequired = $('#date_required').val();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'saveReport',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Report name already exists.');
			}else{
				// $('.hiddenId').val(response.report_id);
				// $('#hidTab2').trigger('click');
				// $('.tab-links li').removeClass('active');
				// $('#columnTab').addClass('active');
				var reportId = response.report_id;
				var newReportRow = '<tr class="odd gradeX"><td id="reportName_'+reportId+'">'+reportName+'</td><td id="reportQuery_'+reportId+'">'+reportQuery+'</td><td id="dateReq_'+reportId+'">'+dateRequired+'</td><td><button id="edit_report" class="btn btn-warning editReport'+reportId+'" onclick="edit_report('+reportId+');">Edit</button><button id="save_report" class="btn btn-success saveReport'+reportId+'" onclick="save_report('+reportId+');" style="display:none;">Save</button>	<button id="remove_report" class="btn btn-danger" onclick="remove_report('+reportId+');">Unlink</button></td></tr>';
				$('#ReportTable tr:last').after(newReportRow);
			}
			console.log(response);
		}
	});
});

$(document).on('submit','#reportEditForm',function(ev){
	ev.preventDefault();
	var  data = $('#reportEditForm').serialize();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'updateReport',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Report name already exists.');
			}else{				
				$('#hidTab2').trigger('click');
				$('.tab-links li').removeClass('active');
				$('#columnTab').addClass('active');				
			}
			console.log(response);			
		}
	});
});

$(document).on('submit','#selectorForm',function(ev){
	ev.preventDefault();
	var  data = $('#selectorForm').serialize();
	var reportId = $('#selReportId').val();
	var selectorName = $('#selector_name').val();
	var selectorDisplayName = $('#selector_display_name').val();
	var selectorFieldName = $('#selector_field_name').val();
	var selectorFieldDisplayName = $('#selector_field_display_name').val();
	var selectorValue = $('#selector_value').val();
	var selectorQuery = $('#selector_query').val();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'saveSelector',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Selector name already exists.');
			}else{
				var selectorId = response.selector_id;				
				var newSelectorRow = '<tr class="odd gradeX"><td id="selReportId_'+selectorId+'">'+reportId+'</td><td id="selectorName_'+selectorId+'">'+selectorName+'</td><td id="selectorDisName_'+selectorId+'">'+selectorDisplayName+'</td><td id="selectorFieldName_'+selectorId+'">'+selectorFieldName+'</td><td id="selectorFieldDisName_'+selectorId+'">'+selectorFieldDisplayName+'</td><td id="selectorValue_'+selectorId+'">'+selectorValue+'</td><td id="selectorQuery_'+selectorId+'">'+selectorQuery+'</td><td><button id="edit_selector" class="btn btn-warning editSelector'+selectorId+'" onclick="edit_selector('+selectorId+');">Edit</button> <button id="save_selector" class="btn btn-success saveSelector'+selectorId+'" onclick="save_selector('+selectorId+');" style="display:none;">Save</button><button id="remove_selector" class="btn btn-danger" onclick="remove_selector('+selectorId+');">Unlink</button></td></tr>';
				$('#selectorTable tr:last').after(newSelectorRow);
			}
		console.log(response);
		}
	});
});

$(document).on('submit','#selectorEditForm',function(ev){
	ev.preventDefault();
	var  data = $('#selectorEditForm').serialize();
	$.ajax({
			async: true,
			type: 'POST',
			url: 'updateSelector',
			data:data,
			dataType:'json',
			success: function(response){
				if(response == false){
					alert('Selector name already exists.');
				}
				console.log(response);			
			}
	});
});

$(document).on('submit','#columnForm',function(ev){
	ev.preventDefault();
	var  data = $('#columnForm').serialize();
	var reportId = $('#ColReportId').val();
	var columnName = $('#column_name').val();
	var displayName = $('#display_name').val();
	var filterValue = $('#filter_value').val();
	var filter = $('#filter').val();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'saveColumn',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Column name already exists.');
			}else{
				
				/* $('#hidTab3').trigger('click');
				$('.tab-links li').removeClass('active');
				$('#selectorTab').addClass('active'); */
				var columnId = response.column_id;
				var newColumnRow = '<tr class="odd gradeX"><td id="colReportName_'+columnId+'">'+reportId+'</td><td id="columnName_'+columnId+'">'+columnName+'</td><td id="displayName_'+columnId+'">'+displayName+'</td><td id="filterValue_'+columnId+'">'+filterValue+'</td><td id="filter_'+columnId+'">'+filter+'</td><td><button id="edit_column" class="btn btn-warning editColumn'+columnId+'" onclick="edit_column('+columnId+');">Edit</button><button id="save_column" class="btn btn-success saveColumn'+columnId+'" onclick="save_column('+columnId+');" style="display:none;">Save</button><button id="remove_column" class="btn btn-danger" onclick="remove_column('+columnId+');">Unlink</button></td></tr>';
				$('#columnTable tr:last').after(newColumnRow);
			}
			console.log(response);
		}
	});
});

$(document).on('submit','#columnEditForm',function(ev){
	ev.preventDefault();
	var  data = $('#columnEditForm').serialize();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'updateColumn',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Column name already exists.');
			}else{
				$('#hidTab3').trigger('click');
				$('.tab-links li').removeClass('active');
				$('#selectorTab').addClass('active');
			}
			console.log(response);
		}
	});
});

$(document).on('change','#selectReport',function(ev){
	ev.preventDefault();
	var  data = 'report_id='+$(this).val();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'getSelector',
		data:data,
		success: function(response){
			$('#selectorsHtml').html(response);
			console.log(response);
		}
	});
});


// $(document).on('submit','#searchReportForm',function(ev){
// ev.preventDefault();

// var  data = $('#searchReportForm').serialize();

	// $.ajax({
			// async: true,
			// type: 'POST',
			// url: 'getSearchResults',
			// data:data,
			// success: function(response){
				
				// console.log(response);
				// $('#reportResult').html(response);
			// },
	// });
// });

$(document).on('change','.selectFilter',function(ev){
	ev.preventDefault();
	var  data = $('#searchReportForm').serialize();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'getFilterSearchResults',
		data:data,
		success: function(response){
			//console.log(response);
			$('#reportResult').html(response);
		}
	});
});

function dateFunction(value,type){	
	if(type == '1'){
		$('#period_type').val('quarters');
		$('#quarter').val(value);
	}else if(type == '2'){
		$('#period_type').val('months');
		$('#month').val(value);
	}
}

$(document).on('click','.panel-title',function(){
	var searchType = $(this).attr('data-type');
	$('#searchType').val(searchType);	
});

function edit_report(reportId){
	var reportName = $('#reportName_'+reportId).text();	
	var reportQuery = $('#reportQuery_'+reportId).text();	
	var reportReq = $('#dateReq_'+reportId).text();
	$('#reportName_'+reportId).html("<input type='text' id='reportName_text"+reportId+"' value='"+reportName+"'>");		
	$('#reportQuery_'+reportId).html("<textarea id='reportQuery_text"+reportId+"'>"+reportQuery+"</textarea>");		
	$('#dateReq_'+reportId).html("<select id='dateReq_text"+reportId+"'><option value=''>Select</option><option "+(reportReq == 'Yes'?'selected':'')+" value='Yes'>Yes</option><option "+(reportReq == 'No'?'selected':'')+" value='No'>No</option></select>");	
	$('.saveReport'+reportId).show();
	$('.editReport'+reportId).hide();
}

function save_report(reportId){
	var reportName = $('#reportName_text'+reportId).val();	
	var reportQuery = $('#reportQuery_text'+reportId).val();	
	var reportReq = $('#dateReq_text'+reportId).val();
	var  data = 'report_id='+reportId+'&report_name='+reportName+'&report_query='+reportQuery+'&date_required='+reportReq;
	$.ajax({
		async: true,
		type: 'POST',
		url: 'updateReport',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Report name already exists.');
			}else{
			$('#reportName_'+reportId).html(reportName);		
			$('#reportQuery_'+reportId).html(reportQuery);		
			$('#dateReq_'+reportId).html(reportReq);	
			$('.saveReport'+reportId).hide();	
			$('.editReport'+reportId).show();		
			}
			console.log(response);
		}
	});
}

function edit_column(columnId){
	var reportName = $('#colReportName_'+columnId).text();	
	var columnName = $('#columnName_'+columnId).text();	
	var displayName = $('#displayName_'+columnId).text();
	var filterValue = $('#filterValue_'+columnId).text();
	var filter = $('#filter_'+columnId).text();
	$('#colReportName_'+columnId).html("<input type='text' id='colReportName_text"+columnId+"' value='"+reportName+"'>");	
	$('#columnName_'+columnId).html("<input type='text' id='columnName_text"+columnId+"' value='"+columnName+"'>");		
	$('#displayName_'+columnId).html("<input type='text' id='displayName_text"+columnId+"' value='"+displayName+"'>");		
	$('#filterValue_'+columnId).html("<input type='text' id='filterValue_text"+columnId+"' value='"+filterValue+"'>");		
	$('#filter_'+columnId).html("<select id='filter_text"+columnId+"'><option value=''>Select</option><option "+(filter == 'Yes'?'selected':'')+" value='Yes'>Yes</option><option "+(filter == 'No'?'selected':'')+" value='No'>No</option></select>");	
	$('.saveColumn'+columnId).show();
	$('.editColumn'+columnId).hide();	
}

function save_column(columnId){
	var reportName = $('#colReportName_text'+columnId).val();	
	var columnName = $('#columnName_text'+columnId).val();	
	var displayName = $('#displayName_text'+columnId).val();
	var filterValue = $('#filterValue_text'+columnId).val();
	var filter = $('#filter_text'+columnId).val();
	var  data = 'report_id='+reportName+'&column_id='+columnId+'&column_name='+columnName+'&display_name='+displayName+'&filter_value='+filterValue+'&filter='+filter;
	$.ajax({
		async: true,
		type: 'POST',
		url: 'updateColumn',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Report name already exists.');
			}else{
			$('#colReportName_'+columnId).html(reportName);		
			$('#columnName_'+columnId).html(columnName);		
			$('#displayName_'+columnId).html(displayName);		
			$('#filterValue_'+columnId).html(filterValue);		
			$('#filter_'+columnId).html(filter);		
			$('.saveColumn'+columnId).hide();	
			$('.editColumn'+columnId).show();		
			}
			console.log(response);
		}
	});	
}

function edit_selector(selectorId){
	var reportId = $('#selReportId_'+selectorId).text();	
	var selectorName = $('#selectorName_'+selectorId).text();	
	var selectorDisName = $('#selectorDisName_'+selectorId).text();
	var selectorFieldName = $('#selectorFieldName_'+selectorId).text();
	var selectorFieldDisName = $('#selectorFieldDisName_'+selectorId).text();
	var selectorValue = $('#selectorValue_'+selectorId).text();
	var selectorQuery = $('#selectorQuery_'+selectorId).text();
	$('#selReportId_'+selectorId).html("<input type='text' id='selReportId_text"+selectorId+"' value='"+reportId+"'>");		
	$('#selectorName_'+selectorId).html("<input type='text' id='selectorName_text"+selectorId+"' value='"+selectorName+"'>");
	$('#selectorDisName_'+selectorId).html("<input type='text' id='selectorDisName_text"+selectorId+"' value='"+selectorDisName+"'>");
	$('#selectorFieldName_'+selectorId).html("<input type='text' id='selectorFieldName_text"+selectorId+"' value='"+selectorFieldName+"'>");
	$('#selectorFieldDisName_'+selectorId).html("<input type='text' id='selectorFieldDisName_text"+selectorId+"' value='"+selectorFieldDisName+"'>");		
	$('#selectorValue_'+selectorId).html("<input type='text' id='selectorValue_text"+selectorId+"' value='"+selectorValue+"'>");
	$('#selectorQuery_'+selectorId).html("<textarea id='selectorQuery_text"+selectorId+"'>"+selectorQuery+"</textarea>");
	$('.saveSelector'+selectorId).show();	
	$('.editSelector'+selectorId).hide();
}

function save_selector(selectorId){
	var reportId = $('#selReportId_text'+selectorId).val();	
	var selectorName = $('#selectorName_text'+selectorId).val();	
	var selectorDisName = $('#selectorDisName_text'+selectorId).val();
	var selectorFieldName = $('#selectorFieldName_text'+selectorId).val();
	var selectorFieldDisName = $('#selectorFieldDisName_text'+selectorId).val();
	var selectorValue = $('#selectorValue_text'+selectorId).val();
	var selectorQuery = $('#selectorQuery_text'+selectorId).val();
	var  data = 'selector_id='+selectorId+'&report_id='+reportId+'&selector_name='+selectorName+'&selector_display_name='+selectorDisName+'&selector_field_name='+selectorFieldName+'&selector_field_display_name='+selectorFieldDisName+'&selector_value='+selectorValue+'&selector_query='+selectorQuery;
	$.ajax({
		async: true,
		type: 'POST',
		url: 'updateSelector',
		data:data,
		dataType:'json',
		success: function(response){
			if(response == false){
				alert('Report name already exists.');
			}else{
				$('#selReportId_'+selectorId).html(reportId);	
				$('#selectorName_'+selectorId).html(selectorName);	
				$('#selectorDisName_'+selectorId).html(selectorDisName);
				$('#selectorFieldName_'+selectorId).html(selectorFieldName);
				$('#selectorFieldDisName_'+selectorId).html(selectorFieldDisName);
				$('#selectorValue_'+selectorId).html(selectorValue);
				$('#selectorQuery_'+selectorId).html(selectorQuery);	
				$('.saveSelector'+selectorId).hide();	
				$('.editSelector'+selectorId).show();		
			}
			console.log(response);
		}
	});	
}

/* Access Control Page Js */
function serviceAjaxProcess(path,data,callback){
	data = (data == '') ? {} : data ;
	if(path == ''){
		alert('Device Command path is Empty!');
	}else{
		$.ajax({
			async: true,
			url: path,
			type: 'GET',
			data: data,
			/* crossDomain:true, */
			success: function(response) {				
				if(!response){
					console.log("Empty response when making AJAX request");
				}else{
					if (callback && typeof callback == "function") {
						response = (typeof(response) === "string")?JSON.parse(response):response;
						callback(response);
					}
				}
			},
			error: function(jqXHR, textStatus, errorThrown) {
				console.log("Error occured when making AJAX request: " + errorThrown);
			}
		});
	}
}

/* ------------ */
$(document).on('click','#showAddReport',function(){
	$('#addReportForm').show();		
});

$(document).on('click','#showAddColumn',function(){
	$('#addColumnForm').show();	
});

$(document).on('click','#showAddSelector',function(){
	$('#addSelectorForm').show();	
});

$(document).on('change','#columnReport',function(){
	var reportId = $(this).val();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'getColumnList',
		data:{reportId:reportId},
		success: function(response){
			$('#columnRow').html(response);
			console.log(response);
		}
	});	
});

$(document).on('change','#selectorReport',function(){
	var reportId = $(this).val();
	$.ajax({
		async: true,
		type: 'POST',
		url: 'getSelectorList',
		data:{reportId:reportId},
		success: function(response){
			$('#selectorRow').html(response);
			console.log(response);
		}
	});	
});