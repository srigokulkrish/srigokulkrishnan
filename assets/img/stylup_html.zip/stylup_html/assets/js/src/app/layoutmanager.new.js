LayoutManager = {};

if (!LayoutManager.elements) {
	LayoutManager.elements = {};
	LayoutManager.elementIndex = 1;
}

LayoutManager.config = {settings: {
		hasHeaders: true,
		constrainDragToContainer: true,
		reorderEnabled: true,
		selectionEnabled: false,
		popoutWholeStack: false,
		blockedPopoutsThrowError: true,
		closePopoutsOnUnload: true,
		showPopoutIcon: false,
		showMaximiseIcon: true,
		showCloseIcon: false
	}
};

$(document).ready(function () {
	LayoutManager.setLayoutHeight();
	$(window).resize(LayoutManager.setLayoutHeight);

	var appType = ApplicationManager.getAppType();
	var appID 	= ApplicationManager.getAppId();
	LayoutManager.getDashboardTemplate(appType, appID);
});

LayoutManager.setLayoutHeight = function () {
	windowWidth = $(window).width();
		if(windowWidth <= 600 ){
			$('#goldenlayoutContainer').height(1600);
			if (LayoutManager.layout) {
				LayoutManager.layout.updateSize();
			}
			return false;
		}
	windowHeight = $(window).height();
	otherHeight = $('.navbarTopMenu').height() + $('.footer').height() + 20;
	$('#goldenlayoutContainer').height(windowHeight - otherHeight);
	
	if (LayoutManager.layout) {
		LayoutManager.layout.updateSize();
	}
}

LayoutManager.getDashboardTemplate = function (appType, appID) {
	var path = '';
	var requestData = {};
	
	switch(appType){
		case "ADMIN":
			requestData.type = appType;
			requestData.orgID = appID;
			path = Config.LayoutTemplate.Admin;
		break;
		
		case "SITE":
			requestData.type = appType;
			requestData.siteId = appID;
			path = Config.LayoutTemplate.Site;
		break;
		
		case "DEVICE":
			requestData.type = appType;
			requestData.deviceId = appID;
			path = Config.LayoutTemplate.Device;
		break;
	}
	
	LYFENET.Core.Ajax.request(path, requestData, LayoutManager.onGetTemplate);
}

LayoutManager.onGetTemplate = function (layoutTemplate) {
	if(layoutTemplate.hasOwnProperty('settings')){
		LayoutManager.config = layoutTemplate;
	}else{
		LayoutManager.config.content = layoutTemplate;
	}
	LayoutManager.layout = new GoldenLayout(LayoutManager.config, $('#goldenlayoutContainer'));
	LayoutManager.layout.on('initialised', LayoutManager.onLayoutInit);
	LayoutManager.layout.on('componentCreated', LayoutManager.onComponentCreated);
	LayoutManager.layout.registerComponent('widget', LayoutManager.createWidget);
	LayoutManager.layout.init();
}

LayoutManager.onComponentCreated = function (component) {
	component.config.componentState;
}

LayoutManager.onLayoutInit = function () {
	var siteId = LYFENET.Core.getUrlParam('siteId');
	var deviceId = LYFENET.Core.getUrlParam('deviceId');
	var type = LYFENET.Core.getUrlParam('type');
	
	console.log('onLayoutInit called.');
	//console.log(LayoutManager.elements);
	for (var elementId in LayoutManager.elements) {
		var element = LayoutManager.elements[elementId];		
		element.componentState.siteId = siteId;
		element.componentState.deviceId = deviceId;
		if(element && element.handle && element.handle.onInit){
			element.handle.onInit(element.context, element.config);
		}
	}

	LayoutManager.updateIntervalHandle = setInterval(LayoutManager.refreshElements, 5000);
	LayoutManager.refreshElements();
}

LayoutManager.refreshElements = function () {
	console.log('refreshElements called.');
	//console.log(LayoutManager.elements);
	for (var elementId in LayoutManager.elements) {
		var element = LayoutManager.elements[elementId];
		if(element && element.handle && element.handle.onUpdate){
			element.handle.onUpdate(element.context, element.config);
		}		
	}
}

LayoutManager.onSaveTemplateConfig = function(){
	var state = JSON.stringify( LayoutManager.layout.toConfig() );
	console.log(state);
	var requestData = {'layout': state};
	LYFENET.Core.Ajax.request(Config.LayoutTemplate.Save, requestData, function (response){
		alert(response.data);
		}
	);
    //localStorage.setItem( 'savedState', state );
}

LayoutManager.createWidget = function (container, componentState) {	
	var elementId = LayoutManager.elementIndex++;
	LayoutManager.elements[elementId] = {};
	LayoutManager.elements[elementId].container = container;
	LayoutManager.elements[elementId].componentState = componentState;
	
	var context 								= {};
	context.elementId 							= elementId;
	context.container							= container.getElement();
	LayoutManager.elements[elementId].context 	= context;
	LayoutManager.elements[elementId].config 	= componentState.config;
	LayoutManager.elements[elementId].handle 	= Widget(context, componentState.config, ApplicationManager.getDataManager());
}