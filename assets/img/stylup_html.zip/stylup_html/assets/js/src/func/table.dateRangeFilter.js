// Step 1: Add Button to buttons
//     tableButtonsObj = addDateRangeFilterButton(tableButtonsObj,IDOfDateRangeButtons)
// Step 2: Add code to buttton
//     addDateRangeFilterToTable(tableHandle,tableID,ColumnNoOfDate,IDOfDateRangeButtons);

// add following scripts and style sheets

{/*
 <script language="javascript" type="text/javascript" src="{{asset("js/src/func/table.dateRangeFilter.js?v=3")}}"></script>
<script src="{{asset('js/libs/daterangepicker/daterangepicker.min.js')}}"></script>
<link rel="stylesheet" type="text/css" href="{{asset('js/libs/daterangepicker/daterangepicker.css')}}"/> 
*/}

function addDateRangeFilterButton(buttons,id) {
    $('head').append('<style type="text/css">.daterangepicker .calendar-table th, .daterangepicker .calendar-table td {border-radius: 0px !important;border: 0px !important;}</style>');
    $('head').append('<style type="text/css">.daterangepicker .calendar-table .next span, .daterangepicker .calendar-table .prev span {color: #fff;border: solid white;border-width: 0 2px 2px 0;border-radius: 0;display: inline-block;padding: 3px;}</style>');
    $('head').append('<style type="text/css"> .drp-selected{display:none !important;}</style>');
    $('head').append('<style type="text/css">.daterangepicker th.available:hover > span {border-color:#0B0B47;}');
    
    dtrgButton = {
                    text: '<span class="oi oi-calendar">&nbsp;</span><span class="d-none d-md-inline">Filter By Date</span>',
                    attr:  {
                        name : 'daterange',
                        title: 'Filter by Date',
                        id: id
                    }
                };
                
    buttons.push(dtrgButton);
    return buttons;
}


function addDateRangeFilterToTable(tableHandle,tableid,dateColNo,id){

    $.fn.dataTable.ext.search.push(
        function( settings, data, dataIndex ) {
            if (settings.nTable.id !== tableid){
                return true;
            }            
            // console.log($('#'+id).val().split(",")[0]=="",$('#'+id).val().split(",")[1]==null);
            if($('#'+id).val().split(",")[0]==""||$('#'+id).val().split(",")[1]=="") return true;
            // console.log($('#'+id).val());
            var min = moment($('#'+id).val().split(",")[0]);
            var max = moment($('#'+id).val().split(",")[1]);    
            var date = new moment(data[dateColNo]);
            // if( min.toString() === "Invalid date" || max.toString() === "Invalid date"){
            //     return true;
            // }
            if( min.isBefore(date) && max.isAfter(date)){
                return true;
            }
            return false;
        }
    );

        $('#'+id).daterangepicker({
            opens: 'right',
            showDropdowns: true,
            // showCustomRangeLabel: false,
            startDate:moment(),
            endDate:null,
            ranges: {
                'All Time' : [moment(),null],
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            
            locale: {
                format: 'DD MMMM YYYY',
                applyLabel: 'Filter',
                invalidDate: 'Not Set' 
            }
        }, 
        function(start, end, label) {
            if(label==='This Month'||label==='Last Month')
                $('#'+id+' span').html(start.format('MMMM'));
            else
                $('#'+id+' span').html(label);
            console.log( $('#'+id+' > .drp-buttons > .drp-selected').html());
            if(label==='All Time'){
                $('#'+id).val([null,null]);
                $('#'+id+' > .drp-buttons > .drp-selected').hide();
            }
            else{
                $('#'+id).val([start.startOf('day').format('DD MMMM YYYY H:mm'),end.endOf('day').format('DD MMMM YYYY H:mm')]);
                $('#'+id+' > .drp-buttons > .drp-selected').show();
            }
            console.log( $('#'+id+' > .drp-buttons > .drp-selected').html());
            tableHandle.draw();
        });
        // $('#'+id).val([null,null]);  
}
