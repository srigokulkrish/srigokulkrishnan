/**
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
**/

if ('undefined' === typeof LN || null === LN) {
    LN = {};
}

if ('undefined' === typeof LN.Defaults || null === LN.Defaults) {
    LN.Defaults = {};
}

LN.Defaults.DataTableButtons = function(tableHandle) {
    
    return [
        'pageLength',
        {
            extend: 'colvis',
            text: '<span class="oi oi-expand-left">&nbsp;</span><span class="d-none d-md-inline">Columns</span>'
        },
        {
            extend: 'copyHtml5',
            text: '<span class="oi oi-clipboard">&nbsp;</span><span class="d-none d-md-inline">Copy</span>',
            titleAttr: 'Copy to Clipboard',
            exportOptions: {
                columns: ".exportable"
            }
        },
        {
            extend: 'excelHtml5',
            text: '<span class="oi oi-document">&nbsp;</span><span class="d-none d-md-inline">Excel</span>',
            titleAttr: 'Export to Excel',
            exportOptions: {
                columns: ".exportable"
            }
        },
        {
            extend: 'csvHtml5',
            text: '<span class="oi oi-spreadsheet">&nbsp;</span><span class="d-none d-md-inline">CSV</span>',
            titleAttr: 'Export to CSV',
            exportOptions: {
                columns: ".exportable"
            }
        },
        {
            extend: 'pdfHtml5',
            text: '<span class="oi oi-file">&nbsp;</span><span class="d-none d-md-inline">PDF</span>',
            titleAttr: 'Export as PDF',
            exportOptions: {
                columns: ".exportable"
            }
        },
        {
            extend: 'print',
            text: '<span class="oi oi-print">&nbsp;</span><span class="d-none d-md-inline">Print</span>',
            titleAttr: 'Print',
            exportOptions: {
                columns: ".exportable"
            }
        },
        {
            text: '<span class="oi oi-magnifying-glass">&nbsp;</span><span class="d-none d-md-inline">Search</span>',
            action: function(e, dt, node, config) {
                var newEl = $('<input type="text" class="btn-search" placeholder="Search"/>');
                node.replaceWith(newEl);
                newEl.on('keyup', () => {
                    dt.search(newEl.val()).draw();
                });
                newEl.focus();
            }
        }
    ]
}
LN.Defaults.DataTableDigitalButtons = function(tableHandle) {
    
    return [
        'pageLength',
        {
            text: '<span class="oi oi-document">&nbsp;</span><span class="d-none d-md-inline">Excel</span>',
            action: function (e, dt, button, config) {
                // Get the current search and order parameters
                var searchData = tableHandle.ajax.params();
                console.log("SSSS",searchData)
                // Add your custom export logic here
                
            }
        },
        {
            extend: 'pdfHtml5',
            text: '<span class="oi oi-file">&nbsp;</span><span class="d-none d-md-inline">PDF</span>',
            titleAttr: 'Export as PDF',
            exportOptions: {
                columns: ".exportable"
            },
            action: function (e, dt, button, config) {
                // Get the current search and order parameters
                var searchData = dataTable.ajax.params();
                console.log("searchData",searchData);
            }
        },
        {
            text: '<span class="oi oi-magnifying-glass">&nbsp;</span><span class="d-none d-md-inline">Search</span>',
            action: function(e, dt, node, config) {
                var newEl = $('<input type="text" class="btn-search" placeholder="Search"/>');
                node.replaceWith(newEl);
                newEl.on('keyup', () => {
                    dt.search(newEl.val()).draw();
                });
                newEl.focus();
            }
        }
    ]
}



LN.Defaults.DataTableButtonsSimple = function(tableHandle) {
    return [{
            extend: 'csvHtml5',
            text: '<span class="oi oi-spreadsheet">&nbsp;</span><span class="d-none d-md-inline">CSV</span>',
            titleAttr: 'Export to CSV',
            exportOptions: {
                columns: ".exportable"
            }
        },
        {
            extend: 'print',
            text: '<span class="oi oi-print">&nbsp;</span><span class="d-none d-md-inline">Print</span>',
            titleAttr: 'Print',
            exportOptions: {
                columns: ".exportable"
            }
        },
        {
            text: '<span class="oi oi-magnifying-glass">&nbsp;</span><span class="d-none d-md-inline">Search</span>',
            action: function(e, dt, node, config) {
                var newEl = $('<input type="text" placeholder="Search"/>');
                node.replaceWith(newEl);
                newEl.on('keyup', () => {
                    dt.search(newEl.val()).draw();
                });
                newEl.focus();
            }
        }
    ]
}

LN.Defaults.GetStepSizeAndMaxSize = function(maxcount, type = 'normal') {
    input = maxcount ? maxcount*2 : 0;
	var index   = input.toString().length;
    var chartjsConfig = {};
    switch (type) {
        case 'hour':
            var seconds = 3600;
            var number  = [1,10,100,1000,10000,100000, 1000000, 10000000];
            var maxChart = Math.ceil(input / number[index - 1]) * number[index - 1];
            var stepSizeOffset = 10;
            var maxChartNew = Math.round(Math.ceil(maxChart/seconds))

            var mod                 = (maxChartNew % stepSizeOffset);
            var maxChartExploded    = (stepSizeOffset+maxChartNew-mod);
            
            chartjsConfig.maxChartCount = Math.round(maxChartExploded ? (Math.ceil(maxChartExploded))*seconds : 1*seconds);
            
            stepsizeCalculation = (chartjsConfig.maxChartCount/(1*seconds));
            if(stepsizeCalculation < 24){
                var stepSizeOffset = 1;
                [2,3,5,7].forEach(element => {
                    if(Number.isInteger(stepsizeCalculation/element)){
                        stepSizeOffset = element;
                        return false;
                    }else if(stepsizeCalculation > 10){
                        stepSizeOffset = 2
                    }
                });
            }
            
            chartjsConfig.stepSize      = stepSizeOffset*seconds;
        break;
    
        default:
            var number  = [1,10,100,1000,10000,100000, 1000000, 10000000];
            var maxChart = Math.ceil(input / number[index - 1]) * number[index - 1];
            chartjsConfig.maxChartCount = (maxChart ? maxChart : 1);
            chartjsConfig.stepSize      = number[index-1];
        break;
    }
    return chartjsConfig;
}