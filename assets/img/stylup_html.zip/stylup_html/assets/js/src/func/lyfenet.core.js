/**
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
**/
if ('undefined' === typeof LN || null === LN) {
	LN = {
	};
}

/**
* LN Core namespace/code
*/
LN.Core = function () {

	var publicMembers = {
		/**
		* Extend, for prototypal inheritance
		* Based on code by Douglas Crockford - http://javascript.crockford.com/prototypal.html
		* @param {Object} parent
		* @alias LN.Core.extend
		*/
		extend: function (parent) {
			function F() { }
			F.prototype = parent;
			return new F();
		},

		/**
		* Is the given object defined - Note, this is a strict test against undefined, and will not check for null
		* @param {Object} obj
		* @alias LN.Core.isDefined
		*/
		isDefined: function (obj) {
			return ('undefined' !== typeof obj);
		},

		/**
		* Is the given object null - Note, this is a strict test against null, and will not test for undefined
		* @param {Object} obj
		* @alias LN.Core.isNotNull
		*/
		isNotNull: function (obj) {
			return (null !== obj);
		},

		/**
		* Does the given object have a value - i.e., is it not null and not undefined and not empty. 
		* Note, a string with value "" will return false in that case
		* Also note, passing an undeclared variable into this function will result in an exception.  
		* If your variable may be undeclared(not undefined)
		* Then you will have to write your own test
		* @param {Object} obj
		* @alias LN.Core.hasValue
		*/
		hasValue: function (obj) {
			return ('undefined' !== typeof obj && null !== obj && "" !== obj);
		},

		/**
		* Return true if the given object is null or undefined.  
		* Don't call this on undeclared values or you will cause an exception
		* Note, a string with value "" will return false in that case
		* @param {Object} obj
		* @alias LN.Core.isNullOrUndefined
		*/
		isNullOrUndefined: function (obj) {
			return ('undefined' === typeof obj || null === obj);
		},

		/**
		* Returns the trimmed form of the string.  The extra \s's trigger an internal regex optimization
		* @param {Object} str
		* @alias LN.Core.trim
		*/
		trim: function (str) {
			return str.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
		},

		/**
		* SafeCallback. A basic implementation of a safe way to callback a function.
		* Additional complexities and optimizations can be added on later, if needed.
		* @param {Object} fnName - The function that needs to be called back.
		* @alias LN.Core.safeCallback
		*/
		safeCallback: function (fnName) {
			var args = Array.prototype.slice.call(arguments, 1);
			if (fnName && 'function' === typeof fnName) {
				try {
					fnName.apply(this, args);
				}
				catch (err) {
					console.log('Error occured when trying to execute callback function. ' + err);
				}
			}
		},
		
		getInstance: function (fn) {
			if (LN.Core.isNullOrUndefined(fn)) {
				return null;
			}
			var slice = Array.prototype.slice;
			var args = slice.apply(arguments, [1]);
			return fn.apply(new Object, args);			
		},
		
		curry: function (fn) {
			var slice = Array.prototype.slice;
			var args = slice.apply(arguments, [1]);
			return function () {
				return fn.apply(null, args.concat(slice.apply(arguments)));
			};
		},
		

		/**
		* Returns the truncated input string with specified number of characters and truncation string 
		* @param {Object} inputStr
		* @param {Object} strLen
		* @param {Object} ellipses
		* @alias LN.Core.truncateString
		*/
		truncateString: function (inputStr, strLen, ellipses) {
			if (LN.Core.isNullOrUndefined(inputStr)) {
				return null;
			}
			
			if (0 > strLen || inputStr.length <= strLen) {
				return inputStr;
			}

			if (0 == strLen) {
				return '';
			}
			var myEllipses = ellipses || '';
			var ellLength = myEllipses.length;

			var truncatedLength = strLen - ellLength;
			//If the desired length is too short, truncate the ellipses and return
			if (truncatedLength <= 0) {
				return myEllipses.substring(0, strLen);
			}
			
			return inputStr.substring(0, truncatedLength) + myEllipses;
		},

		/**
		* Do a URI decode while accounting for + = ' '
		* @param {Object} s
		*/
		decodePercent: function (s) {
			// Handle application/x-www-form-urlencoded, which is defined by
			// http://www.w3.org/TR/html4/interact/forms.html#h-17.13.4.1
			s = s || '';
			s = s.replace(/\+/g, " ");
			return decodeURIComponent(s);
		},

		/**
		* Serialize a dictionary using the specified key-value separator and pair separator 
		* @param {Object} dict
		* @param {Object} keyValSeparator
		* @param {Object} pairSeparator
		* @param {Object} encode - Should keys and values be uri encoded
		*/
		serializeDictionary: function (dict, keyValSeparator, pairSeparator, encode) {
			var result = '';
			if (LN.Core.isNullOrUndefined(dict)) {
				return result;
			}
			var first = true;
			jQuery.each(dict, function (key, value) {
				if (!dict.hasOwnProperty(key)) {
					return true; //continue
				}
				if (!first) {
					result += pairSeparator;
				}
				first = false;

				var finalKey = encode ? encodeURIComponent(key) : key;
				var finalValue = encode ? encodeURIComponent(value) : value;
				result += finalKey + keyValSeparator + finalValue;
			});
			return result;
		},
		
		/**
		*Returns the param in URL.
		* @alias LN.Core.getUrlParam
		*/
		getUrlParam: function(key){
			var a = window.location.search.substr(1).split('&');
			if (a == "") return {};
			var b = {};
			for (var i = 0; i < a.length; ++i){
				var p=a[i].split('=');
				if (p.length != 2) continue;
				b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
			}
			return b[key];
		},	

		/**
		*Returns an object with name-value pairs.
		* @alias LN.Core.getParamList
		*/
		getParamList: function (param, keyValSeparator, pairSeparator) {
			var list = {};
			if (LN.Core.isNullOrUndefined(param)) {
				return list;
			}
			pairSeparator = pairSeparator || '&';
			keyValSeparator = keyValSeparator || '=';

			var nvps = param.split(pairSeparator);
			for (var n = 0; n < nvps.length; ++n) {
				var pair, name = null, value = null, nvp = nvps[n];
				if ("" == nvp) {
					continue;
				}
				var pos = nvp.indexOf(keyValSeparator);
				if (0 >= pos) {
					continue;
				}
				name = nvp.substring(0, pos);
				if (name) {
					name = LN.Core.trim(publicMembers.decodePercent(name));
				}
				pos++;
				value = nvp.substring(pos);
				if (value) {
					value = LN.Core.trim(publicMembers.decodePercent(value));
				}
				list[name] = value;
			}
			return list;
		},

		/**
		* Add parameter to URL
		* @alias LN.Core.addParametersToUrl
		*/
		addParametersToUrl: function (sourceUrl, params) {
			if (LN.Core.isNullOrUndefined(sourceUrl)) {
				return null;
			}

			if (LN.Core.isNullOrUndefined(params)) {
				return sourceUrl;
			}

			var url = sourceUrl;
			var splittedUrl = url.split('?');
			var noParametersFound = (1 == splittedUrl.length);

			var list;
			if (splittedUrl.length > 0) {
				list = LN.Core.getParamList(splittedUrl[1]);
			}
			if (LN.Core.isNullOrUndefined(list)) {
				list = {};
			}

			for (var paramName in params) {
				if (!params.hasOwnProperty(paramName)) {
					continue;
				}

				list[paramName] = params[paramName];
			}

			url = splittedUrl[0] + '?' + LN.Core.serializeDictionary(list, '=', '&', false);

			return url;
		},

		/**
		* Add parameter to URL
		* @alias LN.Core.addParameterToUrl
		*/
		addParameterToUrl: function (sourceUrl, parameterName, parameterValue) {
			if (LN.Core.isNullOrUndefined(sourceUrl)) {
				return null;
			}

			if (LN.Core.isNullOrUndefined(parameterName)) {
				return sourceUrl;
			}

			var url = sourceUrl;
			var splittedUrl = url.split('?');
			var noParametersFound = (1 == splittedUrl.length);
			var list = {};

			if (noParametersFound) {
				/* No parameters found */
				list[parameterName] = parameterValue;
			} else {
				if (splittedUrl.length > 0) {
					list = LN.Core.getParamList(splittedUrl[1]);

					if (!LN.Core.isNullOrUndefined(list)) {
						/* Set parameter value */
						list[parameterName] = parameterValue;
					}
				}
			}

			url = splittedUrl[0] + '?' + LN.Core.serializeDictionary(list, '=', '&', false);

			return url;
		},

		/**
		* Builds a key value pair where the parameter name is the key and the parameter value is the value.
		* @alias LN.Core.getKeyValuePair
		*/
		getKeyValuePair: function (parameterName, parameterValue, encode) {
			var finalKey = encode ? encodeURIComponent(parameterName) : parameterName;
			var finalValue = encode ? encodeURIComponent(parameterValue) : parameterValue;
			var keyValueSeparator = encode ? encodeURIComponent('=') : '=';

			return finalKey + keyValueSeparator + finalValue;
		},

		/**
		* Builds a string representation in key value pairs where the parameter name is the key and the parameter value
		* is the value.
		* @alias LN.Core.getKeyValuePairs
		*/
		getKeyValuePairs: function (params, encode) {
			if (LN.Core.isNullOrUndefined(params)) {
				return '';
			}

			var list = {};
			for (var paramName in params) {
				if (!params.hasOwnProperty(paramName)) {
					continue;
				}

				list[paramName] = params[paramName];
			}

			var keyValueSeparator = encode ? encodeURIComponent('=') : '=';
			var pairSeparator = encode ? encodeURIComponent('&') : '&';

			return LN.Core.serializeDictionary(list, keyValueSeparator, pairSeparator, encode);
		},
		
		/**
		* Replaces tokens in a string template with the data values
		* @alias LN.Core.supplant
		*/
		supplant: function(tokens, template){
			//object to hold replacement values
			var text = '';
			//replace tokens in template
			text = template.replace(
				/\{(.+?)\}/g, function(token, match, number, txt) {
								token = token.replace('{', '');
								token = token.replace('}', '');
								return tokens[token];
							  }
			);
				
			//output text
			return text;

		},
                _keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
 
	// public method for encoding
	encode : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = this._utf8_encode(input);
 
		while (i < input.length) {
 
			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);
 
			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;
 
			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}
 
			output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
 
		}
 
		return output;
	},
 
	// public method for decoding
	decode : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
 
		while (i < input.length) {
 
			enc1 = this._keyStr.indexOf(input.charAt(i++));
			enc2 = this._keyStr.indexOf(input.charAt(i++));
			enc3 = this._keyStr.indexOf(input.charAt(i++));
			enc4 = this._keyStr.indexOf(input.charAt(i++));
 
			chr1 = (enc1 << 2) | (enc2 >> 4);
			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			chr3 = ((enc3 & 3) << 6) | enc4;
 
			output = output + String.fromCharCode(chr1);
 
			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}
 
		}
 
		output = this._utf8_decode(output);
 
		return output;
 
	},
 
	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";
 
		for (var n = 0; n < string.length; n++) {
 
			var c = string.charCodeAt(n);
 
			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}
 
		}
 
		return utftext;
	},
 
	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;
 
		while ( i < utftext.length ) {
 
			c = utftext.charCodeAt(i);
 
			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);
				string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);
				c3 = utftext.charCodeAt(i+2);
				string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
 
		}
 
		return string;
	}
	};
	return publicMembers;
} ();


/**
 * Class for basic LN events
 */
LN.Core.Events = function() {
    var that = this;
    var _debugAllEvents = false;

    var publicMembers = {
        /**
        * Constructor for event controller
        * @alias LN.Core.Events.EventController
        */
        EventController: function() {
            var eventMap = {};
            var publicMembers = {
                registerEventHandler: function(eventName, fn) {
                    if (_debugAllEvents) {
                        LN.LogManager.logInfo("EventController:  registering " + eventName);
                    }

                    if (LN.Core.isNullOrUndefined(eventName) || '' === eventName) {
                        throw "Attempting to register event handler for null/undefined event";
                    }

                    if (LN.Core.isNullOrUndefined(eventMap[eventName])) {
                        eventMap[eventName] = [];
                    }
                    eventMap[eventName].push(fn);
                },

                unregisterEventHandler: function(eventName, fn) {
                    if (_debugAllEvents) {
                        if (LN.Core.isNullOrUndefined(fn)) {
                            LN.LogManager.logInfo("EventController:  unregistering all " + eventName + " handlers");
                        } else {
                            LN.LogManager.logInfo("EventController:  unregistering one " + eventName + " handler");
                        }
                    }

                    if (LN.Core.isNullOrUndefined(eventName) || '' === eventName ||
						LN.Core.isNullOrUndefined(eventMap[eventName])) {
                        if (_debugAllEvents) {
                            LN.LogManager.logInfo("EventController:  no handlers to unregister");
                        }

                        return that;
                    }

                    if (_debugAllEvents) {
                        LN.LogManager.logInfo("EventController:  " + eventMap[eventName].length + " handler(s) present");
                    }

                    if (LN.Core.isNullOrUndefined(fn)) {
                        eventMap[eventName] = [];
                    } else {
                        var listenerList = eventMap[eventName];
                        for (var listenerIndex = 0; listenerIndex < listenerList.length; listenerIndex++) {
                            if (listenerList[listenerIndex] === fn) {
                                break;
                            }
                        }

                        if (listenerIndex < listenerList.length) {
                            listenerList = listenerList.splice(listenerIndex, 1);
                        }
                    }
                },

                unregisterEventHandlers: function(events) {
                    if (!events) {
                        return;
                    }

                    for (var eventIndex in events) {
                        if (events.hasOwnProperty(eventIndex)) {
                            this.unregisterEventHandler(events[eventIndex]);
                        }
                    }
                },

                fireEvent: function(eventName) {
                    if (LN.Core.isNullOrUndefined(eventName)) {
						return;
                    }

                    var handlers = eventMap[eventName];
                    if (handlers) {
                        if (_debugAllEvents) {
                            LN.LogManager.logInfo("EventController:  firing " + eventName + ", " + handlers.length + " handler(s)");
                        }
                        
                        var args = Array.prototype.slice.call(arguments, 1);
                        args.unshift(handlers); //Add handlers array to beginning of args list
                        LN.Core.Functional.executeList.apply(this, args);
                    } else {
                        if (_debugAllEvents) {
                            LN.LogManager.logInfo("EventController:  firing " + eventName + ", no events");
                        }
                    }

                    return that;
                },

                waitForEvents: function(eventsArray, fn) {
                    if (LN.Core.isNullOrUndefined(eventsArray) ||
						LN.Core.isNullOrUndefined(fn) ||
						0 === eventsArray.length) {
                        return;
                    }

                    // We'll squirrel away the event data results in this map.
                    fn.multiplexMap = {};

                    var multiplexHandler = function(eventName, eventData) {
						if (_debugAllEvents) {
							LN.LogManager.logInfo("EventController:  waitForEvents caught a " + eventName + " event");
						}

                        // Store the incoming event data.
                        if ('undefined' === typeof eventData) {
                            fn.multiplexMap[eventName] = null;
                        } else {
                            fn.multiplexMap[eventName] = eventData;
                        }

                        // Have we hit all of the events at least once?
                        for (var arrayIndex = 0; arrayIndex < eventsArray.length; arrayIndex++) {
                            var eventName = eventsArray[arrayIndex];
                            if ('undefined' === typeof fn.multiplexMap[eventName]) {
                                return;
                            }
                        }

                        // We've hit everything at least once, so let's clear the result map
                        // and execute the callback function.
                        var resultMap = LN.Core.Utils.clone(fn.multiplexMap);
                        fn.multiplexMap = {};
                        fn(resultMap);
                    };

                    // Register the multiplex handler for all the listed events.
                    for (var arrayIndex = 0; arrayIndex < eventsArray.length; arrayIndex++) {
                        var eventName = eventsArray[arrayIndex];
                        publicMembers.registerEventHandler(eventName, multiplexHandler.gCurry(eventName));
                    }
                }
                
            };
            return publicMembers;
        }
    };

    return publicMembers;
} ();


/**
 * Simple Timer Class. Specify time in milli seconds
 * Timer can be instantiated in three modes. 
 * 1. Normal timer that counts up from 0 to specified count and then fires a 'TIMER_COMPLETE' event. Set a valid 'counts' (>0) parameter and countDownMode to false.
 * 2. CountDown timer that counts down from the specified count until zero and then fires the 'TIMER_COMPLETE' event. Set a valid 'counts' (>0) parameter and countDownMode to true.
 * 3. Infinite timer (NOT YET IMPLEMENTED) that counts up from 0 and stops only when told to. Set 'counts' to -1 and countDownMode to false.
 *  All the times modes fire a 'TIMER_TICK' event at the set interval until timer is complete.
 * @param {int} counts - REQUIRED - Number of ticks before timer completes. set it to -1 if you want.
 * @param {bool} countDownMode - REQUIRED - Set True if you need a count down timer.
 * @param {int} interval - OPTIONAL - Tick interval. Defaults to 1 second if not specified.
 */
(LN.Core.Timer = function(counts, countDownMode, interval){
	
	// Return if the counts are not set.
	if(LN.Core.isNullOrUndefined(counts)){
		return null;
	}
	
	// Return if the countDownMode is not specified.
	if(LN.Core.isNullOrUndefined(countDownMode)){
		return null;
	}
	
	// Return if the counts are improperly set for countDownMode
	if(countDownMode && 0 >= counts){
		return null;
	}
	
	var that = this;
	var targetCounts = counts, currentCount = 0, _timer = null;
	var infinteMode = (-1 === counts);
	
	if(infinteMode){
		return null;
	}
	
	/**
	 * If interval is not set, default to 1000 milliseconds.
	 */
	interval = interval || 1000;
	
	var eventController = new LN.Core.Events.EventController();
	
	/**
	 * Timer Events.
	 */
	that.TimerEvents = {	
		TIMER_TICK : 'TIMER_TICK',
		TIMER_COMPLETE: 'TIMER_COMPLETE'};
	
	/**
	 * Internal onTick handler.
	 */
	var onTick = function(){
		if(countDownMode){
			// We are in countdown mode, so if current count is over zero continue to decrement it.
			if(0 < currentCount){
				currentCount--;
				eventController.fireEvent(that.TimerEvents.TIMER_TICK, {timerCount: currentCount});
			}
			// Else scream timer's complete.
			else{
				onComplete();			
			}
		}
		else{
			// If infinite mode, fire TIMER_TICK event
			if(-1 === targetCounts) {
				currentCount++;
				eventController.fireEvent(that.TimerEvents.TIMER_TICK, {timerCount: currentCount});
			}
			// Otherwise, if currentCount is less than targetCount, increment it and fire a TIMER_TICK event
			else if(currentCount < targetCounts){				
				currentCount++;
				eventController.fireEvent(that.TimerEvents.TIMER_TICK, {timerCount: currentCount});
			}
			// Else it means timer's complete.
			else{
				onComplete();			
			}
		}
	};
	
	/**
	 * Internal onComplete handler.
	 */
	var onComplete = function(){
		that.reset();
		eventController.fireEvent(that.TimerEvents.TIMER_COMPLETE);
	};
	
	/**
	 * Clears the timer object.
	 */
	var clearTimer = function(){
		if(!_timer){
			return;
		}
		clearInterval(_timer);
	};
	/**
	 * Reset the counter
	 */
	var resetCount = function(){
		if(countDownMode){
			currentCount = targetCounts;
		}
		else{
			currentCount = 0;
		}	
	};
	
	/**
	 * Add a event listener for the timer.
	 * @param {Object} event
	 * @param {Object} handler
	 */
	that.addEventListener = function(event, handler){
		eventController.registerEventHandler(event, handler)
	};
	
	/**
	 * Removed a registered event listener.
	 * @param {Object} event
	 * @param {Object} handler
	 */
	that.removeEventListener = function(event, handler){
		eventController.unregisterEventHandler(event, handler);
	};

	/**
	 * Function to add a onTick event handler.
	 * @param {Object} event
	 * @param {Object} handler
	 */
	that.addOnTickHandler = function(handler){
		eventController.registerEventHandler(that.TimerEvents.TIMER_TICK, handler);
	};

	/**
	 * Function to remove all onTick event handlers.
	 * @param {Object} event
	 * @param {Object} handler
	 */
	that.removeOnTickHandlers = function(){
		eventController.unregisterEventHandler(that.TimerEvents.TIMER_TICK);
	};

	/**
	 * Function to add a onComplete event handler.
	 * @param {Object} event
	 * @param {Object} handler
	 */
	that.addOnCompleteHandler = function(handler){
		eventController.registerEventHandler(that.TimerEvents.TIMER_COMPLETE, handler);
	};

	/**
	 * Function to remove all onComplete event handler.
	 * @param {Object} event
	 * @param {Object} handler
	 */
	that.removeOnCompleteHandlers = function(){
		eventController.unregisterEventHandler(that.TimerEvents.TIMER_COMPLETE);
	};

	/**
	 * Function that starts the timer.
	 */
	that.start = function(){
		_timer = setInterval(onTick, interval);
	};
	
	/**
	 * Function that stops the timer.
	 */
	that.stop = function(){
		clearTimer();
	};	
	
	/**
	 * Function that resets the timer.
	 */
	that.reset = function(){
		resetCount();
		clearTimer();	
	};
	
	/**
	 * Get Timer
	 */
	that.getCount = function(){
		return currentCount;
	};
	
	that.reset();
	return that;
})();


LN.Core.Ajax = function() {
	var that = this;
    
    var publicMembers = {
		getHTTPObject : function(){
			var xmlhttp;
			if (window.XMLHttpRequest){
				// code for IE7+, Firefox, Chrome, Opera, Safari
				xmlhttp=new XMLHttpRequest();
			}
			else{
				// code for IE6, IE5
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function(){
				if (xmlhttp.readyState==4 && xmlhttp.status==200){
					
				}
			}
			return xmlhttp;
		},
		
		getJSON:function(url, data, callback, type){
			// function returns "AJAX" object, depending on web browser
			// this is not native JS function!
			var request = publicMembers.getHTTPObject();
			if(!type){
                            type = "GET";
                        }
			var onResponse = function(){
				//alert ('Executing Callback Function: ' + data);
				// if request object received response
				if(request.readyState == 4)
				{
					// parser.php response
					var JSONtext = request.responseText;
					// convert received string to JavaScript object
					console.log(JSONtext);
					var JSONobject = (JSONtext)? JSON.parse(JSONtext) : null;
					callback(JSONobject);
				}
			}
			
			request.onreadystatechange = onResponse;
			var constructedUrl = LN.Core.addParametersToUrl(url, data);
			request.open(type, constructedUrl, true);
			request.send(null);
		},
		
		getFile:function(url, data, callback){
			// function returns "AJAX" object, depending on web browser
			// this is not native JS function!
			var request = publicMembers.getHTTPObject();
			
			var onResponse = function(){
				//alert ('Executing Callback Function: ' + data);
				// if request object received response
				if(request.readyState == 4)
				{
					callback(request.responseText);
				}
			}
			
			request.onreadystatechange = onResponse;
			var constructedUrl = LN.Core.addParametersToUrl(url, data);
			request.open("GET", constructedUrl, true);
			request.send(null);
		},
		
		request: function(path, data, callback){
			data = (data == '') ? {} : data ;
			if(path == ''){
				console.log('Device Command path is Empty!');
			}else{
				$.ajax({
					async: true,
					url: path,
					type: 'GET',
					data: data,
					crossDomain: true,
					success: function(response) {				
						if(!response){
							console.log("Empty response when making AJAX request");
						}else{
							if (callback && typeof callback == "function") {
								response = (typeof(response) === "string")?JSON.parse(response):response;
								callback(response);
							}
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						console.log("Error occured when making AJAX request: " + errorThrown);
					}
				});
			}
		},
		
		customrequest: function(path, data,callback,typePost,crossDomain){
			data = (data == '') ? {} : data ;
			var typePostValue = (typePost == undefined)? 'GET' : 'POST';
			var crossDomainFlag = (crossDomain == undefined)? false : true;
			if(path == ''){
				console.log('Reuested path is Empty!');
			}else{
				$.ajax({
					async: true,
					url: path,
					type: typePostValue,
					data: data,
					crossDomain: crossDomainFlag,
					success: function(response) {				
						if(!response){
							console.log("Empty response when making AJAX request");
						}else{
							if (callback && typeof callback == "function") {
								response = (typeof(response) === "string")?JSON.parse(response):response;
								callback(response);
							}
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						console.log("Error occured when making AJAX request: " + errorThrown);
					}
				});
			}
		}
	};
	
	return publicMembers;
} ();