
	
	var lastScrollValue;
	$(document).ready(function() {
		if(typeof(editFlag) != 'undefined'){
			$(document).keyup(function(e) {
				/* ESC (27) Button Clicks */
				if (e.keyCode == 27 && editFlag == 1)
					$( ".rowCancelBtn").click();	
			
				/* ENTER (13) Button Clicks */
				if (e.keyCode == 13 && editFlag == 1)
					$( ".rowSaveBtn").click();	
			});
		}
	});
	
	function validate(e) {
		 // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl/cmd+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: Ctrl/cmd+C
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: Ctrl/cmd+X
            (e.keyCode == 88 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
	}
	
	function validateEmailText(email){	
		var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if(email == null || email == "")
			alertMessage('error','Please enter Email Address');
		else if(!filter.test(email))
			alertMessage('error','Please enter Valid Email Address');
		else  
			return true;  
	}
		
	function validateText(text){
		//var letters = /^[A-Za-z]+$/;  
		if(text == null || text == "") 
			alertMessage('error','Name must be filled out');
		/* else if(!text.match(letters))
			alertMessage('error','Name must Only Letters'); */
		else 
		 return true;   
	}
	
	function editJsonContents(jsonContent,editorContainer){
		var options = {
			mode: 'tree',
			modes: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
			onError: function (err) {
			  alert(err.toString());
			},
			onChange: function () {
			  console.log('change');
			},
			indentation: 4,
			escapeUnicode: true
		};
		jsonContent = (jsonContent == '')? {} : jsonContent ;	
		jsonContent = (typeof(jsonContent) == 'string') ? JSON.parse(jsonContent) : jsonContent;
		return new JSONEditor(editorContainer, options, jsonContent);	
	}
	
	function editTblRow(idx,hideContainerIds,showContainerIds,currentConainerId){
		if(0==editFlag){
			hideButtonForEdit(idx);
			addHideClass(hideContainerIds);
			removeHideClass(showContainerIds);
			setSourceValue(currentConainerId,idx);
			editFlag=1;
		}else{
			var message = "Please Cancel one of the row in table is Edit Mode";
			alertMessage('warning',message);
		}
	}

	function redirectUrl(url,newTab){
		if(typeof(editFlag) != 'undefined'){
			if (0 != editFlag){
				return false;
			}
		}
		newTab = (newTab == undefined)?false:true;
		if(newTab)
			window.open(url,'_blank');
		else
			location.href=url;
	}
	
	function getSourceContent(containerId){
		var sourceText = $(containerId).html();
		return (typeof(sourceText) == 'string') ? sourceText.trim():sourceText;
	}
	
	function getSourceValue(containerId){
		var sourceText = $(containerId).val();
		return (typeof(sourceText) == 'string') ? sourceText.trim():sourceText;
	}
	
	function getSourceText(containerId){
		var sourceText = $(containerId).text();
		return (typeof(sourceText) == 'string') ? sourceText.trim():sourceText;
	}
	
	function getSourceOption(containerId,source){
		var sourceVal = $(containerId+" option:selected").val();
		var sourceText = $(containerId+" option:selected").text();
		sourceText = (typeof(sourceText) == 'string') ? sourceText.trim():sourceText;
		sourceVal = (typeof(sourceVal) == 'string') ? sourceVal.trim():sourceVal;
		if ((typeof source != 'undefined') && (source != null)) {
			return data=(source=='text')? sourceText:sourceVal;
		}	
		else{	
			return data={
				content:sourceText,
				value:sourceVal
			};		
		}	
	}	
	
	function getSourceAttribute(containerId,attrName){
		return $(containerId).attr(attrName);
	}
	
	function setSourceContent(containerId,content){
		var sourceText = (typeof(content) == 'string') ? content.trim():content;		
		 $(containerId).html(sourceText);
	}
	
	function appendSourceContent(containerId,content){		
		 $(containerId).append(content);
	}
	
	function setSourceValue(containerId,content){
		var sourceText = (typeof(content) == 'string') ? content.trim():content;
		$(containerId).val(sourceText);
	}
	
	function setSourceText(containerId,content){
		var sourceText = (typeof(content) == 'string') ? content.trim():content;
		$(containerId).text(sourceText);
	}
	
	function setSourceOptionbyValue(containerId,content){
		var sourceValue = (typeof(content) == 'string') ? content.trim():content;
		resetSourceOption(containerId);
		$(containerId+' option[value="'+sourceValue+'"]').prop('selected', true);
		$(containerId+' option[value="'+sourceValue+'"]').attr('selected', true);
	}
	
	function setSourceOptionbyText(containerId,content){
		var sourceText = (typeof(content) == 'string') ? content.trim():content;
		resetSourceOption(containerId);
		$(containerId+' option:contains("'+sourceText+'")').prop('selected', true);		
		$(containerId+' option:contains("'+sourceText+'")').attr('selected', true);		
	}
	
	function resetSourceOption(containerId){
		$(containerId+' option').prop("selected", false);
		$(containerId+' option').removeAttr("selected");
	}
	
	function addSourceAttribute(containerId,attrName,attrValue){
		$(containerId).attr(attrName, attrValue);
	}
	
	function removeSourceAttribute(containerId,attrName){
		$(containerId).removeAttr(attrName);
	}
	
	function removeDuplicates(fixedArray,findArray){
		var updatedLevelArray = new Array();
		if(fixedArray){
			for (i in findArray) {
				 if(fixedArray.indexOf(findArray[i]) == -1){
					updatedLevelArray.push(findArray[i]);
				} 
			}
		}
		else{
			updatedLevelArray = findArray;
		}	
		return 	updatedLevelArray;
	}
	
	
	
	function checkOptionRootAndSelect(currentValue,dpdwnId){
		currentValue = currentValue.trim();
		var dpdwnOption = getSourceOption(dpdwnId);
		var dpdwnText = dpdwnOption.content;
		if(currentValue == "Root")
			setSourceOptionbyValue(dpdwnId,0);
		else
			setSourceOptionbyValue(dpdwnId,dpdwnText);
	}
	
	function checkOptionAndSelectRoot(sourceId,destinationId){
		var sourceIdOption = getSourceOption(sourceId);
		var sourceIdDpdwnText = sourceIdOption.content;
		var sourceIdDpdwn = sourceIdOption.value;
		if(0 < parseInt(sourceIdDpdwn))
			setSourceContent(destinationId,sourceIdDpdwnText);
		else
			setSourceContent(destinationId,"Root");
	}

	function onResponseAjax(response){
		if(response.data){
			alertMessage('success',response.data);
			if(response.reload)
				window.location.href = window.location.href;
		}
		if(response.error){
			alertMessage('error',response.error);
		}
	}
	
	function resetFormFields(containerId){
		containerId = containerId.replace('#', ''); 
		$("#"+containerId)[0].reset();
	}
	
	function hideModalContent(containerId){
		containerId = containerId.replace('#', ''); 
		$('#'+containerId).modal('hide');
	}
	
	function showModalContent(containerId){
		containerId = containerId.replace('#', ''); 
		$('#'+containerId).modal('show');
	}
	
	function addHideClass(hideContainerIds){
	  $(hideContainerIds).addClass('hide');
	  $(hideContainerIds).addClass('hidden');
	}
	
	function removeHideClass(showContainerIds){
	  $(showContainerIds).removeClass('hide');
	  $(showContainerIds).removeClass('hidden');
	}
	
	function hideButtonForEdit(idx){
		var hideIds = "#editBtn"+idx+",#deleteBtn"+idx;
		var showIds = "#saveBtn"+idx+",#cancelBtn"+idx;
		addHideClass(hideIds);
		removeHideClass(showIds);
	}
	
	function showButtonForEdit(idx){
		var hideIds = "#saveBtn"+idx+",#cancelBtn"+idx;
		var showIds = "#editBtn"+idx+",#deleteBtn"+idx;
		addHideClass(hideIds);
		removeHideClass(showIds);	
	}
	
	function removeArrayDuplicatesKeyValue(originalArray, prop) {
		var newArray = [];
		var lookupObject  = {};
		for(var i in originalArray) {
			lookupObject[originalArray[i][prop]] = originalArray[i];
		}
		for(i in lookupObject) {
		 newArray.push(lookupObject[i]);
		}
		return newArray;
	}
	
	var sortByDateAscAndTimeAscDateObj = function (lhs, rhs) {
		var results;

		results = lhs.getYear() > rhs.getYear() ? 
		1 : lhs.getYear() < rhs.getYear() ? -1 : 0;

		if (results === 0)
			results = lhs.getMonth() < rhs.getMonth() ? 
			1 : lhs.getMonth() > rhs.getMonth() ? -1 : 0;

		if (results === 0)
			results = lhs.getDate() < rhs.getDate() ? 
			1 : lhs.getDate() > rhs.getDate() ? -1 : 0;

		if (results === 0)
			results = lhs.getHours() > rhs.getHours() ? 
			1 : lhs.getHours() < rhs.getHours() ? -1 : 0;

		if (results === 0)
			results = lhs.getMinutes() > rhs.getMinutes() ? 
			1 : lhs.getMinutes() < rhs.getMinutes() ? -1 : 0;

		if (results === 0)
			results = lhs.getSeconds() > rhs.getSeconds() ? 
			1 : lhs.getSeconds() < rhs.getSeconds() ? -1 : 0;

		return results;
	};
	
	function getOptions(optionArray, Idx, selectedValue, key, value, container, selectionIndex,index) {
		var searchIndex = (typeof(index) != "undefined" && index !== null) ? index: key;
		if (optionArray) {
			var options = "<div class='hide updateDisplay" + Idx + "' id='" + container + Idx + "'><select  class='form-control' id='" + selectionIndex + Idx + "'>";
			for (var id in optionArray) {
				if (optionArray[id][searchIndex] == selectedValue) {
					options += "<option value='" + optionArray[id][key] + "'selected>" + optionArray[id][value];
				}
				else
					options += "<option value='" + optionArray[id][key] + "'>" + optionArray[id][value];
			}
			options += "</select></div>"
			return options;
		}
	}
	
	function getOptionsValue(optionArray, selectedValue, key, value) {
		if (optionArray) {
			for (var id in optionArray) {
				if (optionArray[id][key] == selectedValue) {
					return(optionArray[id][value]);
				}
			}
		}
		return(optionArray[1][value]);
	}
	
	function addDataTable(containerId) {
		$('#' + containerId).DataTable({
			stateSave: true,
			drawCallback: function () {
				$('.dataTables_paginate > .pagination').addClass('pagination-sm');
			},
		});
	}
	
	function replaceAll(str, find, replace) {
		return str.replace(new RegExp(find, 'g'), replace);
	}
	
	function getDateTimeFromUnixTime(unixtime){
		var a = new Date(unixtime * 1000);
		var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
		//var month = months[a.getMonth()];
		var month = a.getMonth()+1;
		var year = a.getFullYear();
		var date = a.getDate();
		var hour = a.getHours();
		var min = a.getMinutes();
		var sec = a.getSeconds();
		month = (month < 10)? '0'+month : month;
		date = (date < 10)? '0'+date : date;
		hour = (hour < 10)? '0'+hour : hour;
		min = (min < 10)? '0'+min : min;
		sec = (sec < 10)? '0'+sec : sec;  		
	  var time = date + '-' + month + '-' + year + ' ' + hour + ':' + min + ':' + sec ;
	  return time;
	}
	
	function getUnixTimeFromDateTime(datetimeString, format){
		format = (format)?format:'d-M-yyyy HH:mm:ss';
		var dateTime = Date.parseExact(datetimeString, format);
		var unixTime = dateTime.getTime(); // same as above
		return unixTime/1000;
	}
	
	
	
	
/*dataSource based parameter functions*/
	var siteIdOptionAll =false;
	var siteData={};
	siteData.stateName=[];
	function getSiteIdDetails(){
		var requestData = {};
		LYFENET.Core.Ajax.request(Config.Dashboard.allsitedetails, requestData, onSiteIdDetails);
	}
	
	function onSiteIdDetails(sitesArray) {
		var optionHtml=(siteIdOptionAll)? '<option value="all">All</option>' : '<option value="">Select</option>';
		for (var site in sitesArray) {
			var siteId = sitesArray[site].siteId;
			var siteName = sitesArray[site].siteName;
			var siteStatus = sitesArray[site].status;
			var siteid = LYFENET.Core.getUrlParam('siteId');
			var selected = (siteid == siteId)?' selected="selected" ':'';
			if(!siteStatus)
				optionHtml+='<option value="'+siteId+'" disabled>'+siteName+'</option>';		
			else	
				optionHtml+='<option value="'+siteId+'"'+selected+'>'+siteName+'</option>';		
		}
		setSourceContent('#siteIdSelector',optionHtml);
	}
	
	function onSiteIdChange(){
		var siteOption = getSourceOption('#siteIdSelector');
		var siteId = siteOption.value;
		var siteName = siteOption.content;
		if(!(siteId)){
			var msg = 'Please Select Site Id';
			alertMessage('error',msg,'.alertModalMsg',false);
			return false;
		}
		var optionHtml='<option value="">Select</option>';
		setSourceContent('#deviceIdSelector',optionHtml);
		if(siteIdOptionAll){
			siteId = (siteId == 'all') ? '' : siteId;
		}
		getSiteIdDevices(siteId);	
	}
	
	function getSiteIdDevices(siteId){
		var requestData = {};
		requestData['siteId'] = siteId;
		LYFENET.Core.Ajax.request( Config.Dashboard.sitedetails, requestData, onSiteIdDevices);
	}
	
	function onSiteIdDevices(deviceArray) {
		deviceArray = removeArrayDuplicatesKeyValue(deviceArray, 'deviceName');	
		var optionHtml='<option value="">Select</option>';
		for (var id in deviceArray) {
			var siteId = deviceArray[id].siteId;
			var deviceName = deviceArray[id].deviceName;
			var deviceId = deviceArray[id].deviceId;
			if(deviceName)
				optionHtml+='<option value="'+deviceId+'">'+deviceName+'</option>';	
			/* else
				optionHtml+='<option value="'+deviceId+'">'+deviceId+'</option>';	 
				optionHtml+='<option value="'+deviceId+'">'+deviceName+'</option>';	 */
		}
		setSourceContent('#deviceIdSelector',optionHtml);
		editFlag=0;
	}
	
	function onDeviceIdChange(){
		var deviceIdOption = getSourceOption('#deviceIdSelector');
		var deviceId = deviceIdOption.value;
		var deviceName = deviceIdOption.content;
		if(!(deviceId)){
			var msg = 'Please Select device Id';
			alertMessage('error',msg,'.alertModalMsg',false);
			return false;
		}
		var optionHtml='<option value="">Select</option>';
		setSourceContent('#paramNameSelector,#stateNameSelector',optionHtml);
		getDeviceParamName(deviceId,deviceName);
		getDeviceStateName(deviceId,deviceName);	
	}
	
	function getDeviceParamName(deviceId,deviceName){
		var requestData = {};
		requestData['deviceId'] = deviceId;
		requestData['deviceName'] = deviceName;
		LYFENET.Core.Ajax.request( Config.Dashboard.classparam, requestData, onDeviceParamName);
	}
	
	function onDeviceParamName(paramArray) {	
		//var optionHtml='<option value="">Select</option>';
		var optionHtml='';
		var paramOption = getSourceOption('#paramNameSelector');
		var paramNameSelected = paramOption.value;
		for (var id in paramArray) {
			var paramName = paramArray[id];
			if(paramNameSelected != paramName)
				optionHtml+='<option value="'+paramName+'">'+paramName+'</option>';	
		}
		appendSourceContent('#paramNameSelector',optionHtml);
	}
	
	function getDeviceStateName(deviceId,deviceName){
		var paramOption = getSourceOption('#paramNameSelector');
		var paramName = paramOption.value;
		var requestData={
			deviceId:deviceId,
			deviceName:deviceName
		};	
		if(paramName)
			requestData['paramName']=paramName;
		LYFENET.Core.Ajax.request( Config.Dashboard.devicestatedetails, requestData, onDeviceStateName);
	}
	
	function onDeviceStateName(stateNameArray){
		siteData.stateName=stateNameArray;
		//var optionHtml='<option value="">Select</option>';
		var stateOption = getSourceOption('#stateNameSelector');
		var stateNameSelected = stateOption.value;
		var optionHtml='';
		for (var id in stateNameArray) {
			var stateName = stateNameArray[id].stateName;
			if(stateNameSelected != stateName)
				optionHtml+='<option value="'+stateName+'">'+stateName+'</option>';	
		}
		appendSourceContent('#stateNameSelector',optionHtml);
	}
	
	function getParamSourceDetails(){
		var requestData = {};
		LYFENET.Core.Ajax.customrequest(Config.Manage.viewparamsource, requestData, onParamSource);
	}
	
	function onParamSource(paramsourceArray) {
		var optionHtml='<option value="">Select</option>';
		for (var id in paramsourceArray) {
			var sourceId = paramsourceArray[id].sourceId;
			var sourceName = paramsourceArray[id].sourceName;
			if(sourceName)
				optionHtml+='<option value="'+sourceName+'">'+sourceName+'</option>';	
		}
		setSourceContent('#datasourceSelector',optionHtml);
	}
	
	function onParamNameChange(){
		var paramOption = getSourceOption('#paramNameSelector');
		var paramName = paramOption.value;
		if(!paramName){
			var msg = 'Please Select Parameter';
			alertMessage('error',msg,'.alertModalMsg',false);
			return false;
		}	
	}

	function onStateNameChange(){
		var stateOption = getSourceOption('#stateNameSelector');
		var stateName = stateOption.value;
		if(!stateName){
			var msg = 'Please Select StateName';
			alertMessage('error',msg,'.alertModalMsg',false);
			return false;
		}
	}
	
	function onDataSourceChange(hideExtraFields){
		hideExtraFields = (hideExtraFields == undefined)?false:true;
		var sourceOption = getSourceOption('#datasourceSelector');
		var sourceId = sourceOption.value;
		var sourceName = sourceOption.content;
		$('#paramNameSelector,#stateNameSelector').removeAttr('disabled');
		if(hideExtraFields)
			$('#thresholdLb,#thresholdUb,#stateValue').removeAttr('disabled');
		if(sourceName){
			switch(sourceName){
				case "DEVICE_PARAM":
				case "DEVICENAME_PARAM":
					$('#stateNameSelector').attr('disabled',true);
					$('#paramNameSelector').removeAttr('disabled');
					if(hideExtraFields)
						$('#stateNameSelector,#stateValue').attr('disabled',true);
					break;
				case "DEVICE_STATE":
				case "DEVICENAME_STATE":
					$('#stateNameSelector').removeAttr('disabled');
					$('#paramNameSelector').attr('disabled',true);
					if(hideExtraFields)
						$('#paramNameSelector,#thresholdLb,#thresholdUb').attr('disabled',true);
					break;
			}
		}else{			
			var msg = 'Please Select dataSource';
			alertMessage('error',msg,'.alertModalMsg',false);	
		}
	}
	
	function getDataSourceValue(){
		var sourceOption = getSourceOption('#datasourceSelector');
		var sourceId = sourceOption.value;
		var sourceName = sourceOption.content;		
		var param;
		switch(sourceName){
			case "DEVICE_PARAM":
			case "DEVICENAME_PARAM":
				param = getSourceOption("#paramNameSelector");
				break;
			case "DEVICE_STATE":
			case "DEVICENAME_STATE":
				param = getSourceOption("#stateNameSelector");
				break;
		}
		if(param)
		  return param;
		return false;
	}
/*dataSource based parameter functions Ends*/


/*Custom Charts*/
	var chart={};
	var dashBoardChart={};
	dashBoardChart.data=[];
	
	function initGoogleCharts(){
		google.charts.load('current', {packages:['corechart']});
	}
	
	function addParameterResponseChart(reqParams,response){
		console.log(response);
		header = (response.name) ? response.name : reqParams.paramDisplayName;
		addParamToChartArray(response.dataPoints,header,dashBoardChart.data);
		//if(5 == dashBoardChart.data[0].length){	
			drawChart(reqParams.contentHandle,dashBoardChart.data,'dashboard','','',Config.dashBoardChartOptions);
		//}
	}
	
	function addStateResponseChart(reqParams, response){
		console.log(response);
		header = (response.name) ? response.name : reqParams.paramDisplayName;
		addParamToChartArray(response.dataPoints,header,dashBoardChart.data);
		drawChart(reqParams.contentHandle,dashBoardChart.data,'dashboard','','',Config.dashBoardChartOptions);		
	}
	
	function addParamToChartArray(data,header,chartData){
		if(0 < chartData.length){
			/*  console.log('newDataAdded:::');
			console.log(chartData); */
			/* if(-1 < chartData[0].indexOf(header))
				return; */
				chartData[0].push(header);
				var firstElement = 1;
			if(0 < data.length){
				if(chartData[firstElement][0] == 0){
					chartData.splice(firstElement,1);
				}
				for(var i = 0; i < data.length; i++){
					var idx = 0;
					var indexFound = false;
					for(j = 1; j < chartData.length; j++){
						if(Number(chartData[j][0]) == Number(new Date(data[i].label))){
							indexFound = true;
							chartData[j].push(data[i].y);
							/* console.log('found:::' + indexFound); */
							break;
						}
					}
					if(indexFound == false){
						var chartLength = chartData[idx].length;
						/* console.log('i:'+i);
						console.log('chartLength:'+chartData.length);
						console.log('data:'+data[i].label);
						console.log('chartheadLength:'+chartLength); */
						var newData = new Array();
						newData.push(new Date(data[i].label));
						var chartlastLen = chartData.length - 1;
						for(var j = 1; j < chartLength-1; j++){
							var prevVal = (1 < chartlastLen) ? chartData[chartlastLen][j] : 0 ;
							newData.push(prevVal);
						}
						newData.push(data[i].y);
						chartData.push(newData);						
						chartData.sort(function(a,b){return a[0]-b[0];});
					}				
				}
			}
			var previousValue=0;
			for(var i = 1; i < chartData.length; i++){
				if(0 < data.length){
					var idx = 0;
					/* console.log(chartData[i]);
					console.log(chartData[i][idx]); */
					var chartheadLength = chartData[idx].length;
					var chartindexLength = chartData[i].length;
					var prevLength = chartheadLength-1;
					if(0 < prevLength && 1 < i)
						previousValue = chartData[i-1][prevLength];					
/* 					console.log('prelength::'+prevLength);
					console.log('ival::'+i);
					console.log('preVal::'+previousValue); */
					if(chartheadLength != chartindexLength){
						var addEmptyLength = chartheadLength - chartindexLength;
						for(var j =0 ;j < addEmptyLength;j++){	
							chartData[i].push(parseFloat(previousValue));
						}				
					}						
				}else
					chartData[i].push(0);
			}
		}else{
			chartData.push(['Time',header]);
			if(0 < data.length){
				for(var i in data){
					chartData.push([new Date(data[i].label),data[i].y]);			
				}			
			}else
				chartData.push([0,0]);	
		}	
			///console.log(chartData);
	}
	
	function drawChart(containerId,dataChart,header,chartView,exportImgId,options,optionTitle){
		google.charts.setOnLoadCallback(function(){
			defineChartOptions(containerId,dataChart,header,chartView,exportImgId,options,optionTitle);
		});
	}
	
	function defineChartOptions(containerId,data,header,chartView,exportImgId,options,optionTitle){
		if(optionTitle != undefined) {
			options.title = optionTitle;
		}
		if(header === undefined) {
			header = 'dashboard';
		}
		if(options === undefined){		
			options = {
				/* animation:{
					duration: 1000,
					easing: 'linear',
					startup: true
				}, */
				title: header,
				/* width: Config.Charts.width,
				height: Config.Charts.height, */
				chartArea:{
					width:'90%',
					height:'70%'
				},
				legend: { 
					position: 'top',
					maxLines: 2 
				},
				vAxis:{
					/* title:'Percentage(%)', */
					minValue:0,
					format:'##.##'
				},
				hAxis:{
					/* title:'Time', */
					format:'HH:mm',
					gridlines: {
						count: 15,
					},
					slantedText: true,
				},
				explorer: {
					//actions: ['dragToZoom', 'dragToPan', 'rightClickToReset'],
					axis: 'horizontal',
					maxZoomOut:4.0,
					keepInBounds: true
				},
				colors:Config.ChartType.colorList,
			};
			if(chartView == Config.ChartType.column){
				options['bar']= {groupWidth: '75%'};
				options['isStacked']= false;
			}else if(chartView == Config.ChartType.steppedarea){
				options['isStacked']= false;
			}else if(chartView == Config.ChartType.stackedcolumn){
				options['bar']= {groupWidth: '75%'};
				options['isStacked']= true;
			}else if(chartView == Config.ChartType.bar){
				options['annotations']={
					alwaysOutside: true
				};
			}else if(chartView == Config.ChartType.linecurve){
				options['curveType']='function';
			}
		}
		drawChartContent(containerId,header,chartView,data,options,exportImgId);
	}
	
	function drawChartContent(containerId,header,chartView,data,options,exportImgId){
		if(chart[header] != undefined){
			chart[header].clearChart();
		}
		
		if(chartView == Config.ChartType.column || chartView == Config.ChartType.stackedcolumn){
			chart[header] = new google.visualization.ColumnChart(document.getElementById(containerId));
		}else if(chartView == Config.ChartType.bar){
			chart[header] = new google.visualization.BarChart(document.getElementById(containerId));
		}else if(chartView == Config.ChartType.area){
			chart[header] = new google.visualization.AreaChart(document.getElementById(containerId));
		}else if(chartView == Config.ChartType.steppedarea){
			chart[header] = new google.visualization.SteppedAreaChart(document.getElementById(containerId));
		}else if(chartView == Config.ChartType.pie){
			chart[header] = new google.visualization.PieChart(document.getElementById(containerId));
		}else{
			chart[header] = new google.visualization.LineChart(document.getElementById(containerId));
		}
		var chartData = new google.visualization.arrayToDataTable(data); 
		
		//console.log('chartData');
		console.log(chartData);
		console.log('holder::'+chart[header]);
		//return false;
		if(exportImgId != undefined){
			google.visualization.events.addListener(chart[header], 'ready', function () {
				imgUri = chart[header].getImageURI();
				//console.log(imgUri);
				//document.getElementById('dynamicChartImg').src = imgUri;
				
				var headerArray = header.split(' ');
				
				var headerKey =  eval(headerArray.length - 1);
				//alert(headerArrCount);
				//alert('#imgContainer'+headerArray[headerArrCount]);
				var img = '<img class="imgChart" src="'+imgUri+'" />';
				$('#imgContainer'+headerArray[headerKey]).html(img);
				
				$(exportImgId).attr("href", imgUri);
				$(exportImgId).removeAttr('disabled');
			});
		}
		chart[header].draw(chartData, options);	 
		
	}
	
	function drawColumnChart(chartData,containerId,header,colorArray,stacked,Legend) {
		if(stacked === undefined) {
			stacked = false;
		}
		//var colorArray = ["#00cc00","#1ac6ff",'#f4c716'];
		var data = new google.visualization.arrayToDataTable(chartData);  
		console.log(data);
		var LegendOption = (Legend === undefined) ? { position: 'top', maxLines: 2 } : 'none';
		var options = {
			title: header,
			chartArea:{
				width:'90%',
				height:'70%'
			},
			/* width: Config.Charts.width,
			height: Config.Charts.height, */
			legend: LegendOption,
			bar: {groupWidth: '75%'},
			vAxis:{
				/* title:'Percentage(%)', */
				minValue:0,
				format:'##.##'
			},
			hAxis:{
				/* title:'Time', */
				slantedText: true,
			},
			explorer: {
				actions: ['dragToZoom', 'dragToPan', 'rightClickToReset'],
				maxZoomOut:4,
				keepInBounds: true
			},
			isStacked: stacked,
			colors:colorArray
		};
		
		if(chart[header] != undefined)
		chart[header].clearChart();
		chart[header] = new google.visualization.ColumnChart(document.getElementById(containerId));
		google.visualization.events.addListener(chart[header], 'ready', function () {
			var imgUri = chart[header].getImageURI();
			// do something with the image URI, like:
			//document.getElementById('dynamicChartImg').src = imgUri;
			document.getElementById('dynamicChartExport').href = imgUri;
			$('#dynamicChartExport').removeAttr('disabled');
		});
		chart[header].draw(data, options);
	}

	function drawBarChart(charData,containerId,header,colorArray) {
	  var data = google.visualization.arrayToDataTable(charData);
	 var options = {
		title: header,
		chartArea:{
				width:'90%',
				height:'70%'
		},
		/* width: Config.Charts.width,
		height: Config.Charts.height, */
		legend: { position: 'top', maxLines: 2 },
		bar: {groupWidth: '95%'},
		vAxis:{
			/* title:'percentage(%)', */
			minValue:0,
			format:'##'
		},
		hAxis:{
			/* title:'Time', */
			slantedText: true,
		},
		explorer: {
			maxZoomOut:2,
			keepInBounds: true
		},		
		annotations: {
			alwaysOutside: true
		},
	 };
	  if(chart[header] != undefined)
	  chart[header].clearChart();
		chart[header] = new google.visualization.BarChart(document.getElementById(containerId));
		google.visualization.events.addListener(chart[header], 'ready', function () {
			var imgUri = chart[header].getImageURI();
			// do something with the image URI, like:
			//document.getElementById('dynamicChartImg').src = imgUri;
			document.getElementById('dynamicChartExport').href = imgUri;
			$('#dynamicChartExport').removeAttr('disabled');
		});
	  chart[header].draw(data, options);
	}

	function drawLineChart(chartData,containerId,header,colorArray,stacked,Legend) {
		if(stacked === undefined) {
			stacked = true;
		}
		var data = new google.visualization.arrayToDataTable(chartData);  
		console.log(data);
		var LegendOption = (Legend === undefined) ? { position: 'top', maxLines: 2 } : 'none';
		var options = {
			title: header,
			chartArea:{
				width:'90%',
				height:'70%'
			},
			hAxis:{
				/* title:'Time', 
				format: 'MMM dd, yyyy hh:mm a',*/
				gridlines: {
					count: 15,
				},
			},
			/* width: Config.Charts.width,
			height: Config.Charts.height, */
			legend: LegendOption,
			/* bar: {groupWidth: '75%'}, */
			vAxis:{
				/* title:'percentage(%)', */
				minValue:0.00,
				format:'##.##',
				gridlines:{
					count:5
				}
			},
			explorer: {
				actions: ['dragToZoom', 'dragToPan', 'rightClickToReset'],
				maxZoomOut:4,
				keepInBounds: true
			},
		};
		
		if(chart[header] != undefined)
			chart[header].clearChart();
		
		chart[header] = new google.visualization.LineChart(document.getElementById(containerId));
		google.visualization.events.addListener(chart[header], 'ready', function () {
			var imgUri = chart[header].getImageURI();
			//document.getElementById('dynamicChartImg').src = imgUri;
			document.getElementById('dynamicChartExport').href = imgUri;
			$('#dynamicChartExport').removeAttr('disabled');
		});
		chart[header].draw(data, options);
	}
		
	function addPieChart(runHourMonthly){
		if(runHourMonthly){
			runHourMonthly = (typeof(runHourMonthly) == 'string') ? JSON.parse(runHourMonthly):runHourMonthly;
			console.log(runHourMonthly);
			var runHoursHeader = ['Total Run Hours','Percentage'];
			var runHoursData = [];
			var dataArray;
			for(var x in runHourMonthly){
				runHoursData.push(runHoursHeader);
				console.log(runHourMonthly[x]);
				dataArray = ['Grid',runHourMonthly[x].RunHoursGridPercent];
				runHoursData.push(dataArray);
				dataArray = ['DG',runHourMonthly[x].RunHoursDGPercent];
				runHoursData.push(dataArray);
				dataArray = ['Battery',runHourMonthly[x].RunHoursBattPercent];
				runHoursData.push(dataArray);				
				//dataArray = ['Main Failure',runHourMonthly[x].RunHoursMainsFailPercent];
				//runHoursData.push(dataArray);
				var containerId = 'pieChart'+runHourMonthly[x].site_id;
				drawChart(containerId,runHoursData,'Run Hours Monthly '+runHourMonthly[x].site_id,Config.ChartType.pie,'',Config.PieChartOptions);
				runHoursData=[];
			}		
		}		
	}
	
	function addACEMPieChart(runHourMonthly){
		console.log(runHourMonthly);
		if(runHourMonthly){
			runHourMonthly = (typeof(runHourMonthly) == 'string') ? JSON.parse(runHourMonthly):runHourMonthly;
			console.log(runHourMonthly);
			var runHoursHeader = ['kWh','Percentage'];
			var runHoursData = [];
			var dataArray;
			for(var x in runHourMonthly){
				runHoursData.push(runHoursHeader);
				console.log(runHourMonthly[x]);
				dataArray = ['Phase R',parseFloat(runHourMonthly[x].current_R)];
				runHoursData.push(dataArray);
				dataArray = ['Phase Y',parseFloat(runHourMonthly[x].current_Y)];
				runHoursData.push(dataArray);
				dataArray = ['Phase B',parseFloat(runHourMonthly[x].current_B)];
				runHoursData.push(dataArray);
				console.log(runHoursData);				
							
				//dataArray = ['Main Failure',runHourMonthly[x].RunHoursMainsFailPercent];
				//runHoursData.push(dataArray);
				var containerId = 'pieChart'+runHourMonthly[x].deviceId;
				console.log(containerId);
				//Config.PieChartOptions.width = 300;
				//Config.PieChartOptions.height = '100';
				drawChart(containerId,runHoursData,'ACEM Monthly '+runHourMonthly[x].deviceId,Config.ChartType.pie,'',Config.PieChartOptions);
				runHoursData=[];
			}		
		}		
	}
	
	function addDGEMPieChart(runHourMonthly){
		if(runHourMonthly){
			runHourMonthly = (typeof(runHourMonthly) == 'string') ? JSON.parse(runHourMonthly):runHourMonthly;
			console.log(runHourMonthly);
			var runHoursHeader = ['kWh','Percentage'];
			var runHoursData = [];
			var dataArray;
			for(var x in runHourMonthly){
				runHoursData.push(runHoursHeader);
				console.log(runHourMonthly[x]);
				dataArray = ['Phase R',parseFloat(runHourMonthly[x].current_R)];
				runHoursData.push(dataArray);
				dataArray = ['Phase Y',parseFloat(runHourMonthly[x].current_Y)];
				runHoursData.push(dataArray);
				dataArray = ['Phase B',parseFloat(runHourMonthly[x].current_B)];
				runHoursData.push(dataArray);
				console.log(runHoursData);				
							
				//dataArray = ['Main Failure',runHourMonthly[x].RunHoursMainsFailPercent];
				//runHoursData.push(dataArray);
				var containerId = 'pieChart'+runHourMonthly[x].site_id;
				//Config.PieChartOptions.width = 300;
				//Config.PieChartOptions.height = '100';
				drawChart(containerId,runHoursData,'DCEM Monthly '+runHourMonthly[x].site_id,Config.ChartType.pie,'',Config.PieChartOptions);
				runHoursData=[];
			}		
		}		
	}
	
	
	function addLineChartToTable(chartArray,header,monthName){
		Config.LineChartOptions.title = (header == undefined) ? 'DCEM Monthly Report' : header;
		if(chartArray){
			chartArray = (typeof(chartArray) == 'string') ? JSON.parse(chartArray):chartArray;
			console.log(chartArray);
			var chartData = [];
			
			for(var z in chartArray){
				var dataArray = chartArray[z];
				var header = ['Day'];
				for(var x in dataArray.tenantList){
					header.push(dataArray.tenantList[x]);
				}				
				chartData.push(header);
				for(var x in dataArray.data){
					var data=[];
					data.push(x);
					for(var y in dataArray.data[x]){
						var percent = parseFloat(dataArray.data[x][y]);
						data.push(percent);
					}				
					chartData.push(data);
					var containerId = 'lineChartContainer'+dataArray.site_id;
					console.log(containerId);
					console.log(chartData);
					Config.LineChartOptions.hAxis.title = monthName;
					drawChart(containerId,chartData,'DCEM Monthly '+dataArray.site_id,Config.ChartType.line,'',Config.LineChartOptions);
				}
				chartData=[];
			}		
		}		
	}
	
	function addDayWiseLineChart(chartArray,header,monthName){
		Config.LineChartOptions.title = (header == undefined) ? 'DCEM Monthly Report' : header;
		if(chartArray){
			chartArray = (typeof(chartArray) == 'string') ? JSON.parse(chartArray):chartArray;
			//console.log(chartArray);
			var chartData = [];
			//console.log(chartArray); //return false;
			
			
			//for(var z in chartArray){
				var chartDataArray = chartArray.data;
				
				 
				for(dataKey in chartDataArray){
					var header = ['Day'];
					header.push('Total Kwh');
					chartData.push(header);
					//console.log(dataArray);
					for(var x in chartDataArray[dataKey]){
						var data=[];
						var site_id = chartDataArray[dataKey][2];
						//alert(site_id);
						if (x != 0 && x != 1 && x != 2 && x != 3 && x != 4){
							//alert(x);
							data.push(eval(x-4));
							var percent = parseInt(chartDataArray[dataKey][x]);
							data.push(percent);
							chartData.push(data);
							var containerId = 'lineChartContainer'+site_id;
							console.log(containerId);
							console.log(chartData);
							Config.LineChartOptions.hAxis.title = monthName;
							drawChart(containerId,chartData,'ACEM Daily '+site_id,Config.ChartType.line,'',Config.LineChartOptions);
						}
					}
					chartData=[];
				}
				
			//}		
		}		
	}
	
	function addHourlyVoltageChart(chartArray,header,monthName){
		Config.LineChartOptions.title = (header == undefined) ? 'Voltage Chart' : header;
		if(chartArray){
			chartArray = (typeof(chartArray) == 'string') ? JSON.parse(chartArray):chartArray;
			console.log(chartArray);
			var chartData = [];
			
				var dataArray = chartArray.data;
				var siteId = chartArray.siteId;
				var header = ['Hour','voltage_R','voltage_B','voltage_Y'];
				chartData.push(header);
				for(var x in dataArray){
					var data=[];
					key = x <= 9 ? 0+x : x;
					data.push(key);
					var voltage_R = parseFloat(dataArray[x].voltage_R);
						data.push(voltage_R);
					var voltage_B = parseFloat(dataArray[x].voltage_B);
						data.push(voltage_B);
					var voltage_Y = parseFloat(dataArray[x].voltage_Y);
						data.push(voltage_Y);
					chartData.push(data);
					var containerId = 'VoltlineChartContainer'+siteId;
					console.log(containerId);
					console.log(chartData);
					Config.LineChartOptions.hAxis.title = '';
					Config.LineChartOptions.vAxis.title = '';
					drawChart(containerId,chartData,'ACEM HOURLY Voltage '+siteId,Config.ChartType.line,'',Config.LineChartOptions,'Voltage Chart');				
				}
				chartData=[];
				//Config.LineChartOptions = {};
				//delete Config.LineChartOptions.title;
				Config.LineChartOptions.title = '';
		}		
	}
	
	function addHourlyWattChart(chartArray,header,monthName){
		Config.LineChartOptions.title = (header == undefined) ? 'Load Chart' : header;
		if(chartArray){
			chartArray = (typeof(chartArray) == 'string') ? JSON.parse(chartArray):chartArray;
			console.log(chartArray);
			var chartData = [];
			
				var dataArray = chartArray.data;
				var siteId = chartArray.siteId;
				var header = ['Hour','kW_R','kW_B','kW_Y'];
				chartData.push(header);
				for(var x in dataArray){
					var data=[];
					key = x <= 9 ? 0+x : x;
					data.push(key);
					var kwh_R = parseFloat(dataArray[x].kwh_R);
						data.push(kwh_R);
					var kwh_B = parseFloat(dataArray[x].kwh_B);
						data.push(kwh_B);
					var kwh_Y = parseFloat(dataArray[x].kwh_Y);
						data.push(kwh_Y);
					chartData.push(data);
					var containerId = 'WattlineChartContainer'+siteId;
					console.log(containerId);
					console.log(chartData);
					Config.LineChartOptions.hAxis.title = '';
					drawChart(containerId,chartData,'ACEM HOURLY Watts '+siteId,Config.ChartType.line,'',Config.LineChartOptions,'Load Chart');				
				}
				chartData=[];
		}		
	}
	
	function addHourlyMeterChart(chartArray,header,monthName){
		Config.LineChartOptions.title = (header == undefined) ? 'Energy Consumption Chart' : header;
		if(chartArray){
			chartArray = (typeof(chartArray) == 'string') ? JSON.parse(chartArray):chartArray;
			console.log(chartArray);
			var chartData = [];
			
				var dataArray = chartArray.data;
				var siteId = chartArray.siteId;
				var header = ['Hour','kwh Meter'];
				chartData.push(header);
				for(var x in dataArray){
					var data=[];
					key = x <= 9 ? 0+x : x;
					data.push(key);
					var kwh_R = parseFloat(dataArray[x].kwhMeter);
						data.push(kwh_R);
					
					chartData.push(data);
					var containerId = 'KwhMeterlineChartContainer'+siteId;
					console.log(containerId);
					console.log(chartData);
					Config.LineChartOptions.hAxis.title = '';
					drawChart(containerId,chartData,'ACEM HOURLY kWh Meter '+siteId,Config.ChartType.line,'',Config.LineChartOptions,'Energy Consumption Chart');				
				}
				chartData=[];
		}		
	}

	function addRawParameterChart(chartArray,header,monthName){
		Config.LineChartOptions.title = (header == undefined) ? 'Raw Parameter' : header;
		Config.LineChartOptions.width = 1300;
		Config.LineChartOptions.height = 400;
		if(chartArray){
			chartArray = (typeof(chartArray) == 'string') ? JSON.parse(chartArray):chartArray;
			console.log(chartArray);
			var chartData = [];
			
				var dataArray = chartArray.data;
				var siteId = chartArray.siteId;
				//var headTpe = [{type: 'datetime', label: 'Hour'}]
				var header = [{type:'timeofday',label:'Hour'}];
				for(var channelKey in chartArray.data){
					header.push(chartArray.data[channelKey]['displayLabel']);
				}
				console.log(header);
				chartData.push(header);
				
				for(var x in chartArray.chart){
					var data=[];
					for(var y in chartArray.chart[x]){
						if(y == 0){ 
							var paramVal = chartArray.chart[x][y];
						}else{
							var paramVal = parseFloat(chartArray.chart[x][y]); 
						}	
						
						data.push(paramVal);
					}			
					chartData.push(data);
					var containerId = 'ParamChart'+siteId;
					console.log(containerId);
					console.log(chartData);
					Config.LineChartOptions.hAxis.title = '';
					//Config.LineChartOptions.hAxis.format = 'hh:mm';
					Config.LineChartOptions.vAxis.title = '';
					drawChart(containerId,chartData,'ACEM HOURLY Voltage '+siteId,Config.ChartType.line,'',Config.LineChartOptions);				
				}
				chartData=[];
				//Config.LineChartOptions = {};
				//delete Config.LineChartOptions.title;
				Config.LineChartOptions.title = '';
		}		
	}
	
	function addHourlyParameterChart(chartArray,header,monthName,hAxisTitle,vAxisTitle){
		Config.LineChartOptions.title = (header == undefined) ? 'Raw Parameter' : header;
		Config.LineChartOptions.width = 1470;
		Config.LineChartOptions.height = 400;
		if(chartArray){
			chartArray = (typeof(chartArray) == 'string') ? JSON.parse(chartArray):chartArray;
			console.log(chartArray);
			var chartData = [];
			
				var colorCodeArray = chartArray.colorCodes; console.log('colorCodeArray'); console.log(colorCodeArray); 
				Config.LineChartOptions.colors = colorCodeArray;
				var dataArray = chartArray.data;
				var siteId = chartArray.siteId;
				//var headTpe = [{type: 'datetime', label: 'Hour'}]
				var header = ['Hour'];
				for(var channelKey in chartArray.data){
					header.push(chartArray.data[channelKey]['displayLabel']);
				}
				console.log(header);
				chartData.push(header);
				
				console.log(chartArray.chart); //return false;
				
				for(var x in chartArray.chart){
					var data=[];
					for(var y in chartArray.chart[x]){
						//key = x <= 9 ? 0+x : x;
						
						var paramVal = (y == 0)?chartArray.chart[x][y]:parseFloat(chartArray.chart[x][y]); 
						data.push(paramVal);
					}			
					chartData.push(data);
					var containerId = 'ParamChart'+siteId;
					console.log(containerId);
					console.log(chartData);
					Config.LineChartOptions.hAxis.title = hAxisTitle;
					Config.LineChartOptions.vAxis.title = vAxisTitle;
					//Config.LineChartOptions.hAxis.format = 'hh:mm';
					
					drawChart(containerId,chartData,'Parameter Hourly Chart '+siteId,Config.ChartType.line,'',Config.LineChartOptions);				
				}
				chartData=[];
				//Config.LineChartOptions = {};
				//delete Config.LineChartOptions.title;
				Config.LineChartOptions.title = '';
		}		
	}
	
	
/*Custom Charts Ends*/
