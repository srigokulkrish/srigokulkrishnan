/**
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
**/
if ('undefined' === typeof LN || null === LN) {
    LN = {};
}

if ('undefined' === typeof LN.Validation || null === LN.Validation) {
    LN.Validation = {};
}

jQuery.validator.addMethod("smallLetter", function(value, element) {
    return this.optional(element) || /^[a-z]+/.test(value);
}, 'Please use one small letter');

jQuery.validator.addMethod("startsWithLetter", function(value, element) {
    return this.optional(element) || /^[a-zA-Z0-9]+/.test(value);
}, 'First letter must be an alphabet or a number');

jQuery.validator.addMethod("largeLetter", function(value, element) {
    return this.optional(element) || /^(?=.*[A-Z])+/.test(value);
}, 'Please use one capital Letter');

jQuery.validator.addMethod("number", function(value, element) {
    return this.optional(element) || /\d/.test(value);
}, 'Please use one number');  

jQuery.validator.addMethod("specialCharacter", function(value, element) {
    return this.optional(element) || /^(?=.*[$@$!#^%*?&])[A-Za-z\d$@$!#^%*?&]/.test(value);
}, 'use anyone of these special characters @$!#^%*?&');
jQuery.validator.addMethod('noSpecialChars', function(value, element) {
    return /^[a-zA-Z0-9\-]+$/.test(value);
}, 'Special characters are not allowed.');
jQuery.validator.addMethod('onlyLetterSpace', function(value, element) {
    return /^[a-zA-Z\s]+$/.test(value);
}, 'use Only allow letters and spaces.');
jQuery.validator.addMethod('rangeInclusive', function(value, element, params) {
    return parseFloat(value) >= parseFloat(params[0]) && parseFloat(value) <= parseFloat(params[1]);
}, 'Please enter a numbers between {0} and {1}.');
jQuery.validator.addMethod("digitLimit", function(value, element, params) {
    var regex = new RegExp("^[0-9]{"+params[0]+"," + params[1] + "}$"); 
    return regex.test(value); // Check if the value contains 1 to 10 digits
}, "Please enter {0} to {1} digits");
LN.Validation.defineFormValidation = function(formName, validationRules, validationMessages, callback, preventSubmit, ignore = true) {
    
    validationRules = (validationRules == undefined) ? {} : validationRules;   
    validationMessages = (validationMessages == undefined) ? {} : validationMessages;    
    preventSubmit = (preventSubmit == undefined) ? false : true;
    console.log(ignore);
    if(ignore == true){
        $("form[name=" + formName + "]").validate({
            rules: validationRules,    
            ignore: "",   
            messages: validationMessages,
            highlight: function(element) {
                $(element).closest('.form-group').addClass('has-error');            
                if((element.classList.contains('select2-hidden-accessible')) == true) 
                {
                    $(element).addClass("is-invalid").removeClass("is-valid");  
                }       
            },
            unhighlight: function(element) {
                if(!$(element).val()){
                    $(element).closest('.form-group').removeClass('has-error');
                }
                else{
                    $(element).closest('.form-group').removeClass('has-error').addClass('valid');
                }
                
                if((element.classList.contains('select2-hidden-accessible')) == true) 
                {
                    $(element).addClass("is-valid").removeClass("is-invalid");
                }  
                
            },
            errorElement: 'medium',
            errorClass: 'help-block errorValidation',                                        
            errorPlacement: function(error, element) {
                if (element.parent('.input-group').length) {
                    error.insertAfter(element.parent());
                }else if (element.hasClass('select2-hidden-accessible')) {
                    error.insertAfter(element.closest('.has-error').find('.select2'));
                }
                else {
                    error.insertAfter(element);
                }
            },
            invalidHandler: function(form, validator) {
                var errors = validator.numberOfInvalids();
                if (errors) {
                    // Only show alert message about first invalid rule 
                    currentElement = validator.errorList[0].element;
                    currentElementId = $(currentElement).attr('id');
                }
            },
            submitHandler: function(form, event) {
                if (callback == undefined && !preventSubmit)
                    form.submit();
                if (callback == undefined && preventSubmit)
                    event.preventDefault(event);
                if (callback != undefined && typeof(callback) == "function" && preventSubmit)
                    callback();
            }
        });
    }else{
        $("form[name=" + formName + "]").validate({
            rules: validationRules,
            messages: validationMessages,
            highlight: function(element) {
                $(element).closest('.form-group').addClass('has-error');            
                if((element.classList.contains('select2-hidden-accessible')) == true) 
                {
                    $(element).addClass("is-invalid").removeClass("is-valid");  
                }        
            },
            unhighlight: function(element) {
                if(!$(element).val()){
                    $(element).closest('.form-group').removeClass('has-error');
                }
                else{
                    $(element).closest('.form-group').removeClass('has-error').addClass('valid');
                }
                
                if((element.classList.contains('select2-hidden-accessible')) == true) 
                {
                    $(element).addClass("is-valid").removeClass("is-invalid");
                }  
                
            },
            errorElement: 'medium',
            errorClass: 'help-block errorValidation',                                        
            errorPlacement: function(error, element) {
                if (element.parent('.input-group').length) {
                    error.insertAfter(element.parent());
                }else if (element.hasClass('select2-hidden-accessible')) {
                    error.insertAfter(element.closest('.has-error').find('.select2'));
                } else {
                    error.insertAfter(element);
                }
            },
            invalidHandler: function(form, validator) {
                var errors = validator.numberOfInvalids();
                if (errors) {
                    // Only show alert message about first invalid rule 
                    currentElement = validator.errorList[0].element;
                    currentElementId = $(currentElement).attr('id');
                }
            },
            submitHandler: function(form, event) {
                if (callback == undefined && !preventSubmit)
                    form.submit();
                if (callback == undefined && preventSubmit)
                    event.preventDefault(event);
                if (callback != undefined && typeof(callback) == "function" && preventSubmit)
                    callback();
            }
        });
    }
}