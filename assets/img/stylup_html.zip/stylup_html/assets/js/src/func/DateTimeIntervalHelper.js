if ('undefined' === typeof DateTimeIntervalHelper || null === DateTimeIntervalHelper) {
    var DateTimeIntervalHelper = {};
}
//timestamp to Minutes Ago
DateTimeIntervalHelper.calculateMinutesAgo = function(timestamp) {
    var currentTime = Date.now();
    var timestampMillis = timestamp * 1000;
    var difference = currentTime - timestampMillis;
    var minutesAgo = Math.floor(difference / (1000 * 60));
    return minutesAgo;
}

//timestamp to get date time straing
DateTimeIntervalHelper.timestampToDateTime = function(timestamp) {
    var unixTimestamp = timestamp * 1000; 
    var date = new Date(unixTimestamp);
    var formattedDateTime = date.toLocaleString(); 
    return formattedDateTime;
}

//get current date YYYY-MM-DD format
DateTimeIntervalHelper.getCurrentDate = function() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// convert datetime string 24hrs to 12hrs
DateTimeIntervalHelper.convertTo12DateHourFormat = function(dateString) {
    const parts = dateString.split(' ');
    const isoDateString = parts[0] + 'T' + parts[1] + ':00';
    const dateObject = new Date(isoDateString);
    if (isNaN(dateObject.getTime())) {
        return "Invalid date";
    }
    const hour = dateObject.getHours();

    if (hour < 0 || hour > 23) {
        return "Invalid hour";
    }
    const isPM = hour >= 12;
    const formattedHour = (hour % 12) || 12; // Convert 0 to 12 for 12:00 AM
    const period = isPM ? "pm" : "am";
    return `${formattedHour}${period}`;
}

//get last seven days
DateTimeIntervalHelper.getLastSevenDays = function() {
    const today = new Date();
    const lastSevenDays = [];
    for (let i = 6; i >= 0; i--) {
        const currentDate = new Date(today);
        currentDate.setDate(today.getDate() - i);

        const year = currentDate.getFullYear();
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        const day = String(currentDate.getDate()).padStart(2, '0');

        lastSevenDays.push(`${year}-${month}-${day}`);
    }
    return lastSevenDays;
}

//get current week days monday to sunday
DateTimeIntervalHelper.getDayOfWeek = function(){
    var startOfWeek = moment().startOf('isoWeek');
    var endOfWeek = moment().endOf('isoWeek');
    var days = [];
    var day = startOfWeek;
    while (day <= endOfWeek) {
        days[day.format('dddd')] = day.format('YYYY-MM-DD');
        day = day.clone().add(1, 'd');
    }
    return days;
}

//check is isCurrentMonth
DateTimeIntervalHelper.isCurrentMonth = function(dateString) {
    const inputDate = new Date(dateString);
    const currentDate = new Date();
    return (
        inputDate.getFullYear() === currentDate.getFullYear() &&
        inputDate.getMonth() === currentDate.getMonth()
    );
}

//get this month dates
DateTimeIntervalHelper.getThisMonthDates = function() {
    const currentDate     = moment();
    const year            = currentDate.year();
    const month           = currentDate.month();
    const firstDayOfMonth = moment({ year, month, day: 1 });
    const lastDayOfMonth  = moment({ year, month }).endOf('month');
    const monthDates = [];
    for (let day = firstDayOfMonth.date(); day <= lastDayOfMonth.date(); day++) {
        monthDates.push(`${year}-${month + 1}-${day.toString().padStart(2, '0')}`);
    }
    return monthDates;
}

//get current year-months
DateTimeIntervalHelper.getCurrentYearMonth = function(){
    const currentDate   = new Date();
    const year          = currentDate.getFullYear();
    const month         = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Month is zero-based, so we add 1
    const formattedDate = `${year}-${month}`;
    return formattedDate;
}

// get date month string
DateTimeIntervalHelper.getDateMonthText = function(day){
    var inputDate = new Date(day);
    var options = { year: 'numeric', month: 'long', day: 'numeric' };
    var formattedDate = inputDate.toLocaleDateString('en-US', options);
    return formattedDate;
}

//get month names januray to december 
DateTimeIntervalHelper.getMonthText = function(dateString = "2024-03"){
    const [year, month] = dateString.split('-');
    const monthName = new Date(`${year}-${month}-01`).toLocaleString('en-US', { month: 'long' });
    return monthName;
}