if ('undefined' === typeof TextSelectHelper || null === TextSelectHelper) {
	TextSelectHelper = {
	};
}

/**
* TextSelectHelper
*/
TextSelectHelper.init = function (id,dataTable,dataColumns) {

    datavals = dataTable;
	datavals.forEach(listitem => {
        $("#"+id +"list").append($("<option>").attr("value", listitem.key).text(("subvalue" in listitem)?(listitem.subvalue):""));
    });
	if ( $.fn.DataTable.isDataTable("#"+id+"DataTable") ) {
		$("#"+id+"DataTable").DataTable().destroy();
	  }
	$("#"+id+"DataTable").DataTable({
    	columns : dataColumns,
    	data : dataTable,
    	"columnDefs": [
        	{
            	"targets": Object.keys(dataColumns).length,
                "render": function (data, type, row) {
                	selectBtn = '<button type="button" class="btn btn-sm btn-primary" onclick="$(\'#'+id+'\').val(\''+row.key+'\');$(\'#'+id+'\').trigger(\'change\');$(\'#advancedSearchModal'+id+'\').modal(\'toggle\');">Select</button>';
                	return selectBtn;
                }
            }
        ],
	});

	$("#advancedSearchModal"+id).on("show.bs.modal", function(e) {
		var dataID = $(e.relatedTarget).attr("data-id");
		$("#dataID").val(dataID);
	});
  
}

TextSelectHelper.makeStrict = function(id){
	$("#"+id).change(function(){
		val = $("#"+id).val();
		
		if($("#"+id+"list option").filter(function(){
				return this.value === val;
			}).length)
		{
			$("#"+id+"MatchList").hide();
		}else{
			$("#"+id+"MatchList").show();
			$("#"+id).val("");
		}	
	});
}

TextSelectHelper.getReturnValue = function(id,dataTable,returnvalue="key"){
	var retvalue;
	data = dataTable;
	data.forEach(row => {
		if(row.key === $("#"+id).val()){
			retvalue = row[returnvalue];
		}else{
			if(!retvalue){
				retvalue = "";
			}
		}
	});
	return retvalue;
}
TextSelectHelper.getReturnDataValue = function(value,data,returnvalue="key"){
	var retvalue;
	data.forEach(row => {
		if(row.key === value){
			retvalue = row[returnvalue];
		}else{
			if(!retvalue){
				retvalue = "";
			}
		}
	});
	return retvalue;
}
TextSelectHelper.digitToCurrency = function(x) {
    x=x.toString();
    var lastThree = x.substring(x.length-3);
    var otherNumbers = x.substring(0,x.length-3);
    if(otherNumbers != '')
        lastThree = ',' + lastThree;
    var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
    return res;
 }