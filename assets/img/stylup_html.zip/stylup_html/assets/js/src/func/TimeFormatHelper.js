if ('undefined' === typeof TimeFormatHelper || null === TimeFormatHelper) {
	TimeFormatHelper = {
	};
}

TimeFormatHelper.hoursToSeconds = function(hours){
	seconds = hours;
	if(hours){
		$seconds = (hours * 60) * 60;
	}
	return $seconds;
}
TimeFormatHelper.minutesToSeconds = function(hours){
	seconds = hours;
	if(hours){
		$seconds = (hours * 60);
	}
	return $seconds;
}
TimeFormatHelper.secondsToHours = function(seconds){
	if(seconds == 0){
		return "0";
	}
	var date = new Date(null);
	date.setSeconds(seconds);
	// console.log("toISOString",date.toISOString());
	var hhmmssFormat = date.toISOString().substr(11, 5);
	// var hhmmssFormat = date.toISOString();
	return hhmmssFormat;
}