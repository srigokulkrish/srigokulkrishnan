/**
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
**/
if ('undefined' === typeof LN || null === LN) {
    LN = {};
}


/**
 * LN DateTime
 */
LN.DateTime = function() {
    var publicMembers = {
        /**
         * FormatShortTime
         * @param {Object} seconds
         * @alias LN.DateTime.formatShortTime
         */
        formatShortTime: function(seconds) {
            seconds = Math.abs(seconds);
            var formattedTime = '';
            if (0 == seconds) {
                formattedTime = '-';
            }

            var secondsTime = seconds % 60;
            var minutes = Math.floor(seconds / 60);
            var minutesTime = minutes % 60;
            var hours = Math.floor(minutes / 60);
            var hoursTime = hours; // % 24;
            //var days = Math.floor(hours/24);


            //days = (days)? days : 0;
            hoursTime = (hoursTime) ? hoursTime : '0';
            hoursTime = (hoursTime < 10) ? '0' + hoursTime : hoursTime;
            minutesTime = (minutesTime) ? minutesTime : '0';
            minutesTime = (minutesTime < 10) ? '0' + minutesTime : minutesTime;
            secondsTime = (secondsTime) ? secondsTime : '0';
            secondsTime = (secondsTime < 10) ? '0' + secondsTime : secondsTime;
            formattedTime = hoursTime + ':' + minutesTime + ':' + secondsTime;
            //formattedTime = (days)? days + 'd ' + formattedTime : formattedTime; 
            return formattedTime;
        },

        formatTimeData:function(seconds){
            var time = LN.DateTime.formatShortTime(seconds).split(":");
            var sortedTime = [];
            for (let i = 0; i < (time.length)-1; i++) {
                if (time[i] != "00"){
                    var timeData = time[i];
                    sortedTime.push(timeData);
                }else{
                    sortedTime.push("00");
                }
            }
            return sortedTime.join(':');
        },

        formatSeconds : function(seconds, needsExtensions) {
            seconds = Math.abs(parseInt(seconds));
            var time = LN.DateTime.formatShortTime(seconds).split(":");
            var formats = [
                ["hr", "hrs"],
                ["min", "mins"],
                ["sec", "secs"]
            ];
            var sortedTime = [];
            for (let i = 0; i < time.length; i++) {
                var ex = '';
                if (time[i] != "00"){
                    if (time[i] == "01") {
                        ex = formats[i][0];
                    } else {
                        ex = formats[i][1]
                    }
                    if(needsExtensions == true){
                        sortedTime.push(time[i] + ' ' + ex);
                    }else{
                        sortedTime.push(time[i]);
                    }
                }
            }
            if(0 == sortedTime.length){
                if(needsExtensions == true){
                    sortedTime.push("0 hr");
                }else{
                    sortedTime.push("0");
                }
            }
            //console.log('formatSeconds', seconds, sortedTime.join(' '));
            return sortedTime.join(' ');
        },

        modifyFormatSecondsToMinutes: function (seconds) {
            seconds = Math.abs(parseInt(seconds));
            var formattedTime = '';

            var minutes = Math.floor(seconds / 60);
            var minutes = seconds / 60;
            if (seconds > 60) {
                if(Math.floor(minutes) == 1){
                    formattedTime = minutes.toFixed(2)+' mins';
                }else{
                    formattedTime = Math.floor(minutes)+' mins';
                }
            } else {
                formattedTime = minutes.toFixed(2)+' min';
            }
        
            return formattedTime;
        },
        
        modifyFormatSeconds : function(seconds, needsExtensions) {
            seconds = Math.abs(parseInt(seconds));
            var formattedTime = '';
            if (0 == seconds) {
                formattedTime = '-';
            }
            var secondsTime = seconds % 60;
            var minutes = Math.floor(seconds / 60);
            var minutesTime = minutes % 60;
            var hours = Math.floor(minutes / 60);
            var hoursTime = hours; // % 24;

            hoursTime = (hoursTime) ? hoursTime : '';
            hoursTime = (hoursTime < 10) ? '0' + hoursTime : hoursTime;
            minutesTime = (minutesTime) ? minutesTime : '';
            minutesTime = (minutesTime < 10) ? '0' + minutesTime : minutesTime;
            secondsTime = (secondsTime) ? secondsTime : '';
            secondsTime = (secondsTime < 10) ? '0' + secondsTime : parseInt(secondsTime);

            var hrextension = hoursTime == "01" ? 'hr' : 'hrs';
            var minextension = minutesTime == "01" ? 'min' : 'mins';
            var secondextension = secondsTime == "01" ? 'sec' : 'secs';

            if(hoursTime != '0' && minutesTime == '0' && secondsTime == '0'){
                formattedTime = hoursTime +' '+hrextension;
            }else if(hoursTime == '0' && minutesTime != '0' && secondsTime != '0'){
                formattedTime = minutesTime  +' '+ minextension;
            }else if(hoursTime == '0' && minutesTime == '0' && secondsTime != '0'){
                formattedTime = secondsTime  +' '+ secondextension;
            }else if(hoursTime != '0' && minutesTime != '0' && secondsTime != '0'){
                formattedTime = hoursTime  +' '+ hrextension  +' '+ minutesTime  +' '+  minextension;
            }
            return formattedTime;
        },

        formatSecondsMini: function(seconds, needsExtensions) {
            //var time = LN.DateTime.formatShortTime(seconds);
            seconds = Math.abs(parseInt(seconds));
                    var formattedTime = '';
                    if (0 == seconds) {
                        formattedTime = '-';
                    }
        
                    var secondsTime = seconds % 60;
                    var minutes = Math.floor(seconds / 60);
                    var minutesTime = minutes % 60;
                    var hours = Math.floor(minutes / 60);
                    var hoursTime = hours; // % 24;
                    //var days = Math.floor(hours/24);
        
        
                    //days = (days)? days : 0;
                    hoursTime = (hoursTime) ? hoursTime : '0';
                    hoursTime = (hoursTime < 10) ? '0' + hoursTime : hoursTime;
                    minutesTime = (minutesTime) ? minutesTime : '0';
                    minutesTime = (minutesTime < 10) ? '0' + minutesTime : minutesTime;
                    secondsTime = (secondsTime) ? secondsTime : '0';
                    secondsTime = (secondsTime < 10) ? '0' + secondsTime : parseInt(secondsTime);
                    formattedTime = hoursTime + ':' + minutesTime + ':' + secondsTime;
                    //formattedTime = (days)? days + 'd ' + formattedTime : formattedTime; 
                    return formattedTime;
            //return time;
        },

        parseMySqlDT: function(dtString) {
            var t = dtString.split(/[- :]/);
            var d = new Date(Date.UTC(t[0], t[1] - 1, t[2], t[3], t[4], t[5]));
            return d;
        },

        currentTimeString: function() {
            var d = new Date(); // for now
            return d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds();
        },

        getYear: function(d) {
            if (!d) {
                d = new Date();
            }
            return d.getFullYear();
        },

        getMonth: function(d) {
            if (!d) {
                d = new Date();
            }
            var month = (d.getMonth() + 1);
            month = (10 > month) ? '0' + month : month;
            return month;
        },

        getDate: function(d) {
            if (!d) {
                d = new Date();
            }
            var date = d.getDate();
            date = (10 > date) ? '0' + date : date;
            return date;
        },

        /*calculate Time diff b/w two time string return as seconds*/
        calculateTimeDifference: function(fromTime, ToTime) {
            // use a constant date (e.g. 2000-01-01) and the desired time to initialize two dates
            var shiftTimeIn = new Date('2000/01/01 ' + fromTime);
            var shiftTimeOut = new Date('2000/01/01 ' + ToTime);
            if (shiftTimeOut < shiftTimeIn) {
                shiftTimeOut.setDate(shiftTimeIn.getDate() + 1);
            }
            var diff = shiftTimeOut - shiftTimeIn;

            var msec = diff;
            /* 	var hh = Math.floor(msec / 1000 / 60 / 60);
            	msec -= hh * 1000 * 60 * 60;
            	var mm = Math.floor(msec / 1000 / 60);
            	msec -= mm * 1000 * 60; */
            var ss = Math.floor(msec / 1000);
            msec -= ss * 1000;
            //return hh+':'+mm+':'+ss;
            return ss;
        },

        /**
         * Time string(hh:mm:ss) convert to Seconds
         */
        hmsToSecondsOnly: function(str) {
            var p = str.split(':'),
                s = 0,
                m = 1;
            while (p.length > 0) {
                s += m * parseInt(p.pop(), 10);
                m *= 60;
            }
            return s;
        },

        /**
         * Convert Seconds to percentage from total shift time in Seconds
         */
        calculatePercentageOfTime: function(totaltime, seconds) {
            /*if seconds exceeds total shift seconds*/
            if (totaltime < seconds) {
                seconds %= totaltime;
            }
            var timePercentage = (100 * seconds / totaltime).toFixed(2);
            return Math.round(timePercentage) + '%';
        },

        fromUnixTimeStamp: function(unixTimeStamp, displayDateTime = false) {
            var date = new Date(unixTimeStamp * 1000);

            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var day = date.getDate();

            var hours = date.getHours();
            var minutes = "0" + date.getMinutes();
            var seconds = "0" + date.getSeconds();
            if (displayDateTime) {
                var formattedTime = year + '/' + month + '/' + day + ' ' + hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
            } else {
                var formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
            }
            return formattedTime;
        }

    };

    return publicMembers;
}();

function filterObjectByString(targetObj, searchStr, removeOriginal) {
    var filteredStateTable = {};
    for (var stateName in targetObj) {
        if (stateName.indexOf(searchStr) > -1) {
            filteredStateTable[stateName] = targetObj[stateName];
            if (removeOriginal) {
                delete targetObj[stateName];
            }
        }
    }
    return filteredStateTable;
}

function filterObjectBySet(targetObj, searchGroup, removeOriginal) {
    var filteredStateTable = {};
    for (var stateName in searchGroup) {
        if (targetObj.hasOwnProperty(stateName)) {
            filteredStateTable[stateName] = targetObj[stateName];
            if (removeOriginal) {
                delete targetObj[stateName];
            }
        }
    }
    return filteredStateTable;
}

function transformArrayToObject(dataArray, key) {
    var dataObject = {};
    for (var idx in dataArray) {
        var el = dataArray[idx];
        var keyName = el[key];
        dataObject[keyName] = el;
    }
    return dataObject;
}

function transformObjectToKeyVal(dataObject) {
    var keyVal = {};
    for (var idx in dataObject) {
        var el = dataObject[idx];
        var keyName = el["name"];
        var value = el["value"];
        keyVal[keyName] = value;
    }
    return keyVal;
}

function showLoadingIndicator() {
    $('.loadingIndicator').css({
        'display': 'block'
    });
}

function hideLoadingIndicator() {
    $('.loadingIndicator').css({
        'display': 'none'
    });
}

function showDiv($target) {
    $($target).css({
        'display': 'block'
    });
}

function hideDiv($target) {
    $($target).css({
        'display': 'none'
    });
}


function replaceAll(str, find, replace) {
    return str.replace(new RegExp(find, 'g'), replace);
}

function validateStringExist(str) {
   return (LN.Core.isNullOrUndefined(str) ? '' : str);
}

function stringToDigit(str) {
    const num = str;
    const numFor = Intl.NumberFormat('en-US');
    const new_for = numFor.format(num);
    return new_for;
 }

 