var defaultColors = ["#02DFDE", "#fff", "#555", "#00E396", "#775DD0", "#ccc","#FF0000","#00BAEC"];
var DiffchartTypes = ["donut", "pie", "polarArea"];
class apex{
    constructor(){
        try {
            this.Myconfig = {
                chart               : true,
                color               : true,
                series              : true,
                xAxis               : true,
                yAxis               : true,
                noData              : true,
                tooltip             : false,
                grid                : false,
                dataLables          : false,
                fill                : false,
                marker              : false,
                stroke              : false,
                annotation          : false,
                customAnnotation    : false,
                titleXaxis          : false,
                titleYaxis          : false,
                brush               : false,
                ConditionFormatting : false,
                foreColorBool       : false,
                selection           : false,
                title               : false,
                chartConfig: { id:'undefined', name: "undefined", color:[this.getColors(0)], type: 'area', height: 210, foreColor: this.getColors(5), zoom:true, toolbar: false},
                strokeConfig : { width: 3 },
                gridConfig : { borderColor : this.getColors(2), clipMarkers : false, yaxisLine   : false },
                dataLabelsConfig : { enabled : false },
                fillConfig : {
                    colors: {enabled: false, ColorOption: [this.getColors[0], this.getColors[1]]},
                    gradient: { enabled : false, opacityFrom : 0.55, opacityTo: 0 }
                },
                xaxis :{type:'categories',tickPlacement: 'between'},
                markerConfig : { size : 5, colors: [], strokeColor: this.getColors(0), strokeWidth: 3},
                titleConfig: { x:'X-Axis Title', y:'Y-Axis Title', chartTitleOption: {text: "my chart",align: 'left'}},
                zoomConfig : { type: 'x', autoScaleYaxis: true },
                toolConfig : { download: true, selection: true, zoom: true, zoomin: true, zoomout: true, reset: true, autoSelected: 'zoom'},
                brushConfig : { target: 'undefined' },
                selectionConfig: { color: "#fff", opacity:0.5, min: 1,max: 100},
                annotationConfig: { y:false, yValue:0, yText:"Y Axis Annotation", position:'auto', yBorder:this.getColors(4), yBackground:this.getColors(4), ycolor:this.getColors(1), x:false, xValue: 0, xText:"X Axis Annotation", xBorder:this.getColors(4), xBackground:this.getColors(4), xcolor:this.getColors(0)},
                customAnnotationConfig: {},
                tooltipConfig: { enabled:false, x:false, y:false, xPrefix:"" ,yPrefix:"" ,xset:[] , yset:[]},
                ConditionFormattingConfig : {}, //sample [ {value:val1, operator:'operator1', color:'colorcode1'}, {value:val2, operator:'operator2', color:'colorcode2'}]
                yaxisOptions : {show: true, showAlways:true, showForNullSeries:true, setEnable: false, min:0, max:0},
                brushScrollEvent: {enabled: false, externalFunction: function(context, Axis){ console.log(Axis) } },
                noDataConfig: { text:"Data not available", align:"center", verticalAlign:"middle", style: false},
                selectionEventConfig : { enabled: false , externalFunction: function(x) { console.log(x) } },
                zoomEventConfig:{enabled: false, externalFunction: function(x){ console.log(x) } }
            };
            this.MasterConfig = {};
            this.xaxis = [];
            this.dataset = [];
            this.RenderClass;
            this.labels = [];
        }
        catch(err) {
            alert(err.message);
        }
    }

    /*-----------------------------
     ---------Setter---------------
     ----------------------------*/
    setBaseConfig(){
        if(this.Myconfig.chart){
            this.MasterConfig["chart"] = this.getChartConfig();
        }
        if(this.Myconfig.title){
            this.MasterConfig["title"] = this.Myconfig.titleConfig.chartTitleOption;
        }
        if(this.Myconfig.noData){
            this.MasterConfig["noData"] = this.getNoData();
        }
        if(this.Myconfig.color){
            this.MasterConfig["colors"] = this.Myconfig.chartConfig.color;
        }
        if(this.Myconfig.stroke){
            this.MasterConfig["stroke"] = this.getstokeConfig(); 
        }
        if(this.Myconfig.grid){
            this.MasterConfig["grid"] = this.getGridConfig();
        }
        if(this.Myconfig.dataLables){
            this.MasterConfig["dataLabels"] = this.getDataLabelsConfig();
        }
        if(this.Myconfig.series){
            this.MasterConfig["series"] = this.getSeriesConfig();
        }
        if(DiffchartTypes.includes(this.Myconfig.chartConfig.type)){
            this.MasterConfig["labels"] = this.labels;
        }
        if(this.Myconfig.fill && !this.Myconfig.ConditionFormatting){
            this.MasterConfig["fill"] = this.getFillConfig();
        }
        if(this.Myconfig.marker){
            this.MasterConfig["markers"] = this.getMarkerConfig();
        }
        if(this.Myconfig.xAxis){
            this.MasterConfig["xaxis"] = this.getXaxisConfig();
        }
        if(this.Myconfig.yAxis){
            this.MasterConfig["yaxis"] = this.getYaxisConfig();
        }
        if(this.Myconfig.tooltip){
            this.MasterConfig["tooltip"] = this.getToolTipConfig();
        }
        if(this.Myconfig.annotation){
            if(this.Myconfig.customAnnotation){
                this.MasterConfig["annotations"] = this.Myconfig.customAnnotationConfig;
            }else{
                this.MasterConfig["annotations"] = this.getAnnotationConfig();
            }
        }
        return this.MasterConfig;
    }


    /*-----------------------------
     ---------Getter---------------
     ----------------------------*/
    getColors(index = 0){
        if(defaultColors.length > index){
            return defaultColors[index];
        }else{
            return defaultColors[0];
        }
    }
    getBaseConfig(){
        var config = JSON.stringify(this.MasterConfig);
        config = JSON.parse(config)
        
        /*----- Function SetUp -----*/
        //tooltip function
        if(this.Myconfig.tooltip){
            if(this.Myconfig.tooltipConfig.x){
                var xPrefix = this.Myconfig.tooltipConfig.xPrefix;
                var setx     = this.Myconfig.tooltipConfig.xset;
                config.tooltip.x.formatter = function(val) { 
                    if(setx.length > 0){
                        if(setx[val]){
                            return val + xPrefix +setx[val];   
                        }
                        else{
                            return val;
                        }
                    }
                    return val + xPrefix; 
                };
            }
            if(this.Myconfig.tooltipConfig.y){
                var yPrefix = this.Myconfig.tooltipConfig.yPrefix;
                var sety    = this.Myconfig.tooltipConfig.yset;
                config.tooltip.y.formatter = function(val) { 
                    if(sety.length > 0){
                        if(sety[val]){
                            return val + yPrefix +sety[val];   
                        }else{
                            return val;
                        }
                    }
                    return val + yPrefix; 
                };
            }
            if(this.Myconfig.chartConfig.type == "bar"){
                if(this.Myconfig.ConditionFormatting){
                    var formatting = this.Myconfig.ConditionFormattingConfig;
                    if(formatting.length > 0){
                        var formatFunction = "";
                        for(let x in formatting){
                            var ifVar = (x == 0) ? `if` : `else if`;
                            ifVar += `(params.value ${formatting[x].operator} ${formatting[x].value}){ return '${formatting[x].color}';}`;
                            formatFunction += ifVar;
                        } 
                        formatFunction += 'else { return "#00BAEC"; }';

                        //assign colors 
                        config['colors'] = {};
                        config['colors'] = [ new Function('params', formatFunction) ];
                    }
                }
            }
        }

        if(this.Myconfig.brushScrollEvent.enabled){
            var brushScrolledFunction = this.Myconfig.brushScrollEvent["externalFunction"];
            config["chart"].events.brushScrolled = function(chartContext, { xaxis, yaxis }) {
                brushScrolledFunction(chartContext, { xaxis, yaxis });
            };
        }
        
        //Date Time formatter function 
        if(this.Myconfig.xaxis.type === 'datetime'){
            config.xaxis.labels.formatter = function (value, timestamp) {
                const date = new Date(timestamp);
                const formattedDate = `${date.getDate()}:${date.getMonth() + 1}:${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
                return formattedDate;
            };
            config.chart.toolbar.export.csv["dateFormatter"] = function(timestamp){ return new Date(timestamp); };
        }

        //Event selection function
        if(this.Myconfig.selectionEventConfig.enabled === true){
            var selectionFunction = this.Myconfig.selectionEventConfig["externalFunction"];
            config["chart"].events.selection = function (chartContext, { xaxis, yaxis }) {
                selectionFunction(xaxis);
            };
        }

        //Event Zoom function
        if(this.Myconfig.zoomEventConfig.enabled === true){
            var zoomFunction = this.Myconfig.zoomEventConfig["externalFunction"];
            config["chart"].events.zoomed = function (chartContext, { xaxis, yaxis }) {
                zoomFunction(xaxis);
            };
        }
        return config;
    }

    getChartConfig(){
        let chart = {};
        chart['id'] = this.Myconfig.chartConfig.id;
        chart['type'] = this.Myconfig.chartConfig.type;
        chart['height'] = this.Myconfig.chartConfig.height;
        if(this.Myconfig.foreColorBool){
            chart['foreColor'] = this.Myconfig.chartConfig.foreColor;
        }

        if(this.Myconfig.chartConfig.zoom){
            chart['zoom']                   = {};
            chart['zoom']['enabled']        = this.Myconfig.zoom;
            chart['zoom']['type']           = this.Myconfig.zoomConfig.type;
            chart['zoom']['autoScaleYaxis'] = this.Myconfig.zoomConfig.autoScaleYaxis;
        }

        chart["selection"] = {}
        chart["selection"]["enabled"] = this.Myconfig.toolConfig.selection,
        chart["selection"]["fill"] = {}
        chart["selection"]["fill"]["color"] = this.Myconfig.selectionConfig.color,
        chart["selection"]["fill"]["opacity"] = this.Myconfig.selectionConfig.opacity,
        chart["selection"]["xaxis"] = {};
        chart["selection"]["xaxis"]["min"] = this.Myconfig.selectionConfig.min;
        chart["selection"]["xaxis"]["max"] = this.Myconfig.selectionConfig.max;
        
        // toolBar
        chart['toolbar'] = {};
        chart['toolbar']["show"] = this.Myconfig.chartConfig.toolbar;
        chart['toolbar']["offsetX"] = 0;
        chart['toolbar']["offsetY"] = 0;

        //tools
        chart['toolbar']["tools"]   = {}; 
        chart['toolbar']["tools"]["download"] = this.Myconfig.toolConfig.download,
        chart['toolbar']["tools"]["selection"] = this.Myconfig.toolConfig.selection,
        chart['toolbar']["tools"]["zoom"] = this.Myconfig.toolConfig.zoom,
        chart['toolbar']["tools"]["zoomin"] = this.Myconfig.toolConfig.zoomin,
        chart['toolbar']["tools"]["zoomout"] = this.Myconfig.toolConfig.zoomout,
        chart['toolbar']["tools"]["reset"] = this.Myconfig.toolConfig.reset,

        //export option
        chart['toolbar']["export"]   = {}; 
        chart['toolbar']["export"]["csv"] = {};
        chart['toolbar']["export"]["svg"] = {};
        chart['toolbar']["export"]["png"] = {};
        chart['toolbar']["export"]["csv"]["filename"] = this.Myconfig.chartConfig.name;
        chart['toolbar']["export"]["svg"]["filename"] = this.Myconfig.chartConfig.name;
        chart['toolbar']["export"]["png"]["filename"] = this.Myconfig.chartConfig.name;
        chart['toolbar']['autoSelected'] = this.Myconfig.toolConfig.autoSelected;

        if(this.Myconfig.brush){ //brush chart
            chart["brush"] = {}
            chart["brush"]["enabled"] = this.Myconfig.brush,
            chart["brush"]["target"]  = this.Myconfig.brushConfig.target;
        }

        chart['events'] = {};
        if(this.Myconfig.brushScrollEvent.enabled){
            chart["events"]["brushScrolled"] = {};
        }

        chart['events'] = {};
        if(this.Myconfig.selectionEventConfig.enabled === true){ // event function for selection
            chart['events']['selection'] = {};
        }

        if(this.Myconfig.zoomEventConfig.enabled === true){ // event function for zoom
            chart['events']['zoomed'] = {};
        }

        return chart;
    }

    getstokeConfig(){
        let stroke = {};
        stroke['width'] = this.Myconfig.strokeConfig.width;
        return stroke;
    }

    getGridConfig(){
        let grid = {};
        grid['borderColor'] = this.Myconfig.gridConfig.borderColor;
        grid['clipMarkers'] = this.Myconfig.gridConfig.clipMarkers;
        grid['yaxis'] = {};
        grid['yaxis']['lines'] = {};
        grid['yaxis']['lines']['show'] = this.Myconfig.gridConfig.yaxisLine
        return grid;
    }
    getDataLabelsConfig(){
        let dataLabels = {};
        dataLabels['enabled'] = this.Myconfig.dataLabelsConfig.enabled;
        return dataLabels;
    }
    getFillConfig(){
        let fill = {};
        if(this.Myconfig.fillConfig.colors.enabled){
            fill['colors'] = this.Myconfig.fillConfig.colors.ColorOption;
        }
        if(this.Myconfig.fillConfig.gradient.enabled){
            fill['type'] = "gradient";
            fill['gradient'] = {};
            fill['gradient']['enabled'] = this.Myconfig.fillConfig.gradient.enabled;
            fill['gradient']['opacityFrom'] = this.Myconfig.fillConfig.gradient.opacityFrom;
            fill['gradient']['opacityTo'] = this.Myconfig.fillConfig.gradient.opacityTo;
        }
        return fill;
    }
    getMarkerConfig(){
        let marker = {};
        marker['size'] = this.Myconfig.markerConfig.size;
        marker['colors'] = [];
        marker['strokeColor'] = this.Myconfig.markerConfig.strokeColor;
        marker['strokeWidth'] = this.Myconfig.markerConfig.strokeWidth
        return marker;
    }
    getSeriesConfig(){
        const seriesData = this.getSeriesData()
        return seriesData;
    }
    getXaxisConfig(){
        let xaxis = {};
        xaxis['type'] = this.Myconfig.xaxis.type;
        switch(this.Myconfig.xaxis.type){
            case 'categories':
                xaxis['categories'] = this.xaxis;
                break;
            case 'datetime':
                xaxis['labels'] = {};
                xaxis['labels']['formatter'] = {};
                xaxis['labels']['hideOverlappingLabels'] = true;
                xaxis['labels']['showDuplicates'] = false;
                break;

        }
        xaxis['title'] = {};
        if(this.Myconfig.titleXaxis){
            xaxis['title']['text'] = this.Myconfig.titleConfig.x;
            xaxis['title']['offsetX'] = 0;
            xaxis['title']['offsetY'] = 0;
        }
        xaxis['tickPlacement'] = this.Myconfig.xaxis.tickPlacement;
        return xaxis;
    }
    getYaxisConfig(){
        let yaxis = {};
        yaxis['show'] = this.Myconfig.yaxisOptions.show;
        yaxis['showAlways'] = this.Myconfig.yaxisOptions.showAlways;
        yaxis['showForNullSeries'] = this.Myconfig.yaxisOptions.showForNullSeries;
        yaxis['title'] = {};
        if(this.Myconfig.titleYaxis){
            yaxis['title']['text'] = this.Myconfig.titleConfig.y;
        }

        if(this.Myconfig.yaxisOptions.setEnable === true){
            yaxis['min'] = this.Myconfig.yaxisOptions.min;
            yaxis['max'] = this.Myconfig.yaxisOptions.max;          
        }
        // yaxis['tickAmount'] = 4;
        return yaxis;
    }
    getToolTipConfig(){
        let tooltip = {};
        tooltip['enabled'] = this.Myconfig.tooltipConfig.enabled;
        tooltip['theme'] = 'light';
        if(this.Myconfig.tooltipConfig.x){
            tooltip['x'] = {}
            tooltip['x']['show'] = this.Myconfig.tooltipConfig.x;
            tooltip['x']['formatter'] = '';
        }
        if(this.Myconfig.tooltipConfig.y){
            tooltip['y'] = {}
            tooltip['y']['show'] = this.Myconfig.tooltipConfig.y;
            tooltip['y']['formatter'] = '';
        }
        return tooltip;
    }
    getAnnotationConfig(){
        let annotation = {};
        annotation['position'] = this.Myconfig.annotationConfig.position;
        if(this.Myconfig.annotationConfig.y){
            annotation["yaxis"] = [];

            annotation["yaxis"].push({});
            annotation["yaxis"][0]["y"] = this.Myconfig.annotationConfig.yValue;
            annotation["yaxis"][0]["borderColor"] = this.Myconfig.annotationConfig.yBorder;
            annotation["yaxis"][0]["width"] = '100%';
            annotation["yaxis"][0]["label"] = {};
            annotation["yaxis"][0]["label"]["borderColor"] = this.Myconfig.annotationConfig.yBorder;
            annotation["yaxis"][0]["label"]["style"] =  {};
            annotation["yaxis"][0]["label"]["style"]["color"] = this.Myconfig.annotationConfig.ycolor;
            annotation["yaxis"][0]["label"]["style"]["background"] = this.Myconfig.annotationConfig.yBackground;
            annotation["yaxis"][0]["label"]["text"] = this.Myconfig.annotationConfig.yText;
        }
        if(this.Myconfig.annotationConfig.x){
            annotation["xaxis"] = [];
            annotation["xaxis"].push({});
            annotation["xaxis"][0]["x"] = this.Myconfig.annotationConfig.xValue;
            annotation["xaxis"][0]["strokeDashArray"] = 1;
            annotation["xaxis"][0]["borderColor"] = this.Myconfig.annotationConfig.xBorder;
            annotation["xaxis"][0]["label"] = {};
            annotation["xaxis"][0]["label"]["borderColor"] = this.Myconfig.annotationConfig.xBorder;
            annotation["xaxis"][0]["label"]["style"] =  {};
            annotation["xaxis"][0]["label"]["style"]["color"] = this.Myconfig.annotationConfig.xcolor;
            annotation["xaxis"][0]["label"]["style"]["background"] = this.Myconfig.annotationConfig.xBackground;
            annotation["xaxis"][0]["label"]["text"] = this.Myconfig.annotationConfig.xText;
        }
        return annotation;
    }

    getNoData(){
        let noData              = {};
        noData["text"]          = this.Myconfig.noDataConfig.text;
        noData["align"]         = this.Myconfig.noDataConfig.align;
        noData["verticalAlign"] = this.Myconfig.noDataConfig.verticalAlign;
        if(this.Myconfig.noDataConfig.style != false){
            noData["style"] = style;
        }
        return noData;
    }


    /*-----------------------------
     --------LOAD CHART----------
     ----------------------------*/
    renderChart() {
        this.setBaseConfig();
        let chartID = this.Myconfig.chartConfig.id;
        let id = '#'+chartID;
        const config = this.getBaseConfig(); 
        //create object and render
        this.RenderClass = new ApexCharts(document.querySelector(id), config);
        this.RenderClass.render(); 
        return this;
    }

    updateSeries(data){
        this.dataset     = data;
        let dataSeries   = this.getSeriesConfig();
        this.RenderClass.updateSeries(dataSeries);
        return this;
    }

    updateOptions(option){
        this.RenderClass.updateOptions(option);
        return this;
    }

    /*-----------------------------
      ----GET DATA SERIES CHART----
      ----------------------------*/
    getSeriesData(){
        var data = [];
        var series = this.parseDataSet();
        var type = this.Myconfig.chartConfig.type;
        switch(type){
            case 'line':
            case 'scatter':
            case 'area':
            case 'bar':
                if(series){
                    for(const index in series){
                        let set = {name: index,data: series[index]}
                        data.push(set)
                    }        
                }
            break;

            case 'donut':
            case 'pie':
            case 'polarArea':
                this.labels = [];
                Object.values(series).forEach(dynamicData => {
                    dynamicData.forEach(entry => {
                        if (entry && entry.x !== undefined && entry.y !== undefined) {
                            this.labels.push(entry.x);
                            data.push(entry.y);
                        }
                    });
                });
            break;
        }
        return data;
    }

    parseDataSet(){
        const parseData = {};
        const data = this.dataset;
        for (const name in data) {
            if (data.hasOwnProperty(name) && Array.isArray(data[name])) {
                parseData[name] = data[name]
                    .filter(entry => entry.length === 2 && entry[0] !== undefined)
                    .map(entry => {
                        const [x, y] = entry;
                        this.xaxis.push(x); // collect xaxis
                        return { x, y };
                    });
            }
        }
        return parseData;
    }
}

//fullScreen View
function requestFullscreen() {
    const docElement = document.documentElement;
    if (docElement.requestFullscreen) {
        docElement.requestFullscreen();
    } else if (docElement.mozRequestFullScreen) {
        docElement.mozRequestFullScreen();
    } else if (docElement.webkitRequestFullscreen) {
        docElement.webkitRequestFullscreen();
    } else if (docElement.msRequestFullscreen) {
        docElement.msRequestFullscreen();
    }
}

//exit full screen
function exitFullscreen() {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
    }
}

//unix time to date time
function unixToTime(timestamp){
    const date = new Date(timestamp * 1000);
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    const formattedTime = `${hours<10 ? '0'+hours : hours}:${minutes <10 ? '0'+minutes : minutes}:${seconds <10 ? '0'+seconds : seconds}`;
    return formattedTime;
}

/*------------------------------
----------- DownSample ---------
-------------------------------*/
function downsample(data, threshold) {
    const downsampledData = [];
    const step = Math.ceil(data.length / threshold);
    for (let i = 0; i < data.length; i += step) {
        downsampledData.push(data[i]);
    }

    return downsampledData;
}

// function meanSample(data, factor){
//     const decimatedData = [];
//     const step = Math.ceil(data.length / factor);
//     for (let i = 0; i < data.length; i += step) {
//         const chunk    = data.slice(i, i + step);
//         const mean     = chunk.reduce((sum, value) => sum + value[1], 0) / chunk.length; 
//         const closest = chunk.reduce((prev, curr) => (Math.abs(curr[1] - mean) < Math.abs(prev[1] - mean))? curr : prev);
//         decimatedData.push(closest);
//     }
//     return decimatedData;
// }

/*---------------------------------------------
---------- Standard Deviation Sample ----------
---------------------------------------------*/
function stdDevDecimation(data, sampleSize = 5000){
    if(data.length > sampleSize){
        const sampleData = [];
        const step = Math.ceil(data.length / sampleSize);
        for (let i = 0; i < data.length; i += step) {
            const chunk    = data.slice(i, i + step);
            const yValues  = chunk.map(dataPoint => dataPoint[1]);
            const StdDev   = calculateStdDev(yValues);
            const Point    = [chunk[0][0], Math.ceil(StdDev)];
            //console.log(chunk, SD);
            sampleData.push(Point);
        }
        return sampleData;
    }else{
        return data;
    }    
}

/*---------------------------------------------
---------- Standard Deviation ----------------
---------------------------------------------*/
function calculateStdDev(data) {
    const mean = data.reduce((sum, value) => sum + value, 0) / data.length; 
    const squaredDifferences = data.map(value => Math.pow(value - mean, 2));
    const variance = squaredDifferences.reduce((sum, value) => sum + value, 0) / data.length; 
    const stdDev   = Math.sqrt(variance);
    return stdDev;
}

/*--------------------------------------------
-------px calculation by given percentage-----
--------------------------------------------*/
function getPXsizeBypercentage(percentage){
    var pxValue = ($(window).height() /100) * percentage;
    return pxValue;
}