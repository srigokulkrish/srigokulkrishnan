/**
  Copyright (c) 2016, LyfeNet Solutions Private Limited, India.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

  Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

  Neither the name of LyfeNet Solutions nor the names
  of its contributors may be used to endorse or promote products
  derived from this software without specific prior written
  permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.
  
**/
if ('undefined' === typeof LN || null === LN) {
    LN = {};
}

if ('undefined' === typeof LN.UI || null === LN.UI) {
    LN.UI = {};
}

LN.UI.AlertType = {
    "Success": "alert-success",
    "Warning": "alert-warning",
    "Error": "alert-danger"
}

LN.UI.ToastOccurance = 0;

LN.UI.AlertTemplate = '<div id="{id}" class="alert centered text-center col-sm-10 {alertType}" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><h5 class="alert-heading"><span class="oi {icon}">&nbsp;</span>{title}</h5><hr>{message}</div>';

LN.UI.ToastTemplate = '<div id="{toastID}" class="toast" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><span class="oi {toastIcon}">&nbsp;</span><strong class="mr-auto toast-title">{toastTitle}</strong><button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close"><span aria-hidden="true">&times;</span></button></div><div class="toast-body">{toastBody}</div></div>';

LN.UI.ScrollToTop = function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Clear browser back history stack to prevent going back to previously loaded pages
 */
LN.UI.PreventBack = function() {
    setTimeout(() => {
        window.history.forward();
    }, 100);
}


LN.UI.VerticalCenter = function(targetEl) {
    var windowHeight = parseFloat($(window).height());
    var containerHeight = parseFloat($(targetEl).outerHeight());
    var topMenuHeight = parseFloat($(".topMenu").outerHeight());
    var footerHeight = parseFloat($(".footer").outerHeight());
    windowHeight = windowHeight - containerHeight - topMenuHeight - footerHeight;
    var marginTopCalc = parseInt(windowHeight / 2);
    if (5 < marginTopCalc) {
        $(targetEl).css("margin-top", marginTopCalc + "px");
    }
}

LN.UI.FullHeight = function(targetEl, minHeight) {
    if(!minHeight){
        minHeight = 300;
    }
    var windowHeight = parseFloat($(window).height());
    var topMenuHeight = parseFloat($(".topMenu").outerHeight());
    var actionBarHeight = 0;
    //Check if action bar exists and is not inside the targetElement
    var $target = $(".actionBar").filter(function(){
        return $(this).parents(targetEl).length > 0;
    });
    var allfound = $(".actionBar").length;
    var childfound = $target.length;
    var found = allfound - childfound;
    if(found){
        actionBarHeight = parseFloat($(".actionBar ").outerHeight());
    }

    var footerHeight = parseFloat($(".footer").outerHeight());
    var newContainerHeight = windowHeight - topMenuHeight - footerHeight - actionBarHeight;
    newContainerHeight = Math.max(newContainerHeight, minHeight);
    newContainerHeight  = Math.round(newContainerHeight);
    $(targetEl).css("min-height", newContainerHeight + "px");
    $(targetEl).css("height", newContainerHeight + "px");
    $(targetEl).css("overflow-y", "auto");
    
}

/**
 * Show an alert popup
 * options = {
        title:title,
        message:message,
        autoDismiss:autoDismiss,
        dismissTimeout:2000
    }
 */
LN.UI.showAlert = function(alertType, options, container = ".alertsContainer") {
    $(container).empty();
    var timestamp = moment().unix();
    var id = 'alert_' + timestamp;

    options.autoDismiss = (options.hasOwnProperty('autoDismiss')) ? options.autoDismiss : true;
    options.dismissTimeout = (options.hasOwnProperty('dismissTimeout')) ? options.dismissTimeout : 2000;
    options.dismissOnClickOut = (options.hasOwnProperty('dismissOnClickOut')) ? options.dismissOnClickOut : true;

    switch (alertType) {
        case LN.UI.AlertType.Success:
            options.icon = (options.hasOwnProperty('icon')) ? options.icon : 'oi-thumb-up';
            options.title = (options.hasOwnProperty('title')) ? options.title : "Success";
            break;
        case LN.UI.AlertType.Warning:
            options.icon = (options.hasOwnProperty('icon')) ? options.icon : 'oi-warning';
            options.title = (options.hasOwnProperty('title')) ? options.title : "Warning";
            break;
        case LN.UI.AlertType.Information:
            options.icon = (options.hasOwnProperty('icon')) ? options.icon : 'oi-cog';
            options.title = (options.hasOwnProperty('title')) ? options.title : "Information";
            break;
        default:
        case LN.UI.AlertType.Error:
            options.icon = (options.hasOwnProperty('icon')) ? options.icon : 'oi-warning';
            options.title = (options.hasOwnProperty('title')) ? options.title : "Error";
            break;
    }

    var params = {
        id: id,
        alertType: alertType,
        title: options.title,
        message: options.message,
        icon: options.icon
    };

    var alertHtml = LN.Core.supplant(params, LN.UI.AlertTemplate);
    var isJQueryEl = container instanceof jQuery;
    if (isJQueryEl) {
        container.append(alertHtml);
    } else {
        $(container).append(alertHtml);
    }

    alertHandle = $('#' + id);
    //LN.UI.VerticalCenter('#' + id);
    alertHandle.alert();

    if (options.autoDismiss) {
        setTimeout(() => {
            alertHandle.hide("slow");
            alertHandle.remove();
        }, options.dismissTimeout);
    }

    if (options.dismissOnClickOut) {
        $(window).click(function(){
            alertHandle.hide("slow");
            alertHandle.remove();
        });
          
        alertHandle.click(function(event){
            var closeBtn = $(event.target).parent( ".close" );
            if(0 < closeBtn.length){
                return;
            }
            event.stopPropagation();
        });
    }

    return alertHandle;
}

LN.UI.dismissAlert = function(handle) {
    if (!handle) {
        return false;
    }

    handle.hide("slow");
    handle.remove();
}

LN.UI.ShowToast = function(options, container = '.toastsContainer') {
    if (!options.hasOwnProperty('body')) {
        return false;
    }
    if(LN.UI.ToastOccurance == 1){
        return false;
    }

    options.title = (options.hasOwnProperty('title')) ? options.title : "Notification";
    options.animation = (options.hasOwnProperty('animation')) ? options.animation : true;
    options.autohide = (options.hasOwnProperty('autohide')) ? options.autohide : true;
    options.delay = (options.hasOwnProperty('delay')) ? options.delay : 3000;
    options.icon = (options.hasOwnProperty('icon')) ? options.icon : 'oi-bullhorn';

    var timestamp = moment().unix();
    var id = 'toast_' + timestamp;
    var params = {
        toastTitle: options.title,
        toastBody: options.body,
        toastIcon: options.icon,
        toastID: id
    }
    var toastHtml = LN.Core.supplant(params, LN.UI.ToastTemplate);
    var isJQueryEl = container instanceof jQuery;
    if (isJQueryEl) {
        container.append(toastHtml);
    } else {
        $(container).append(toastHtml);
    }

    var toastHandle = $('#' + id);
    var toastOptions = { animation: options.animation, autohide: options.autohide, delay: options.delay }
    $('.toast').toast(toastOptions);
    $('.toast').toast('show');
    LN.UI.ToastOccurance++;
    console.log('Toast occurance:', LN.UI.ToastOccurance);

    setTimeout(() => {
        toastHandle.remove();
        LN.UI.ToastOccurance--;
        console.log('Toast occurance:', LN.UI.ToastOccurance);
    }, options.delay + 500);

    return toastHandle;
}