//console.log(new apiHelper().makeRequest('{{ path("api.v1.ifm.getsensordata") }}','POST',{}, success, error));
class apiRequestHelper {
  makeRequest(endpoint, type, data, successCallback, errorCallback) {
    $.ajax({
      url: endpoint,
      type: type,
      contentType: 'application/json',
      data: data,
      success: (response) => {
        successCallback(response);
      },
      error: (jqXHR, textStatus, errorThrown) => {
        errorCallback(textStatus);
      }
    });
    return data;
  } 
}